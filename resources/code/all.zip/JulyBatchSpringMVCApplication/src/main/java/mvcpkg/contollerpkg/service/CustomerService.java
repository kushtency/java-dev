package mvcpkg.contollerpkg.service;

import mvcpkg.contollerpkg.entity.LMS_Customer;

import java.util.List;

public interface CustomerService {
    public void insert(LMS_Customer customer);
    public void insertt(LMS_Customer customer);
    public boolean updateCustomer(LMS_Customer customer1);   //without check age
    public boolean deleteCustomer(int customerId) ;
    public LMS_Customer getCustomer(int customerId);
    public LMS_Customer getCustomerr(int customerId) ;
    public List<LMS_Customer> getAllCustomers();
    public List<LMS_Customer> getCustomersByName(String custName);

    public List<String> getCustomersName();




    }
