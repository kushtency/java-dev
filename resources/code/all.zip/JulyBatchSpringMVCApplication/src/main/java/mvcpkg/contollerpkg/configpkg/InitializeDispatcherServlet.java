package mvcpkg.contollerpkg.configpkg;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
public class InitializeDispatcherServlet extends AbstractAnnotationConfigDispatcherServletInitializer {

    @Override
    protected Class<?>[] getRootConfigClasses() {
        return new Class[]{DispatcherServlet.class};
    }
    @Override
    protected Class<?>[] getServletConfigClasses() {
        return new Class[]{DispatcherServlet.class};
    }
    @Override
    protected String[] getServletMappings() {
        return new String[]{"*.do"};
    }
}
