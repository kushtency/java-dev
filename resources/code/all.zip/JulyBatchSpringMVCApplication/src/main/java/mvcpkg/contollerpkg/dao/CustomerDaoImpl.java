package mvcpkg.contollerpkg.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import mvcpkg.contollerpkg.Exception.CustomerNotFoundException;
import mvcpkg.contollerpkg.entity.LMS_Customer;
import mvcpkg.contollerpkg.service.CustomerMapper;
import mvcpkg.contollerpkg.service.Getters;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class CustomerDaoImpl implements CustomerDao {
    @Autowired
    JdbcTemplate jdbcTemplate;
    private java.lang.RuntimeException RuntimeException;
    private java.lang.NullPointerException NullPointerException;

    public void saveCustomer(LMS_Customer customer) {
        System.out.println("saving customer");
        String query = "insert into lms_customer_m_17155_1 values(?,?,?,?,?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(query, Getters.getarray(customer));
    }

    public boolean updateCustomer(LMS_Customer customer) {
        System.out.println("updating customer ");
        String query = "update lms_customer_m_17155_1 " +
                "set customer_id = ?," +
                " first_name = ?," +
                " last_name = ?," +
                " gender = ?," +
                " date_of_birth = ?," +
                " Contact_Number = ?," +
                " email_address = ?," +
                " monthly_income = ?," +
                " profession = ?," +
                " total_monthly_expense = ?," +
                " designation = ?," +
                " company_name = ? " +
                "where customer_id = ?";

//        Object[] arr =  Getters.getarray(customer);
//        arr[arr.length] = customer.getId();
//        jdbcTemplate.update(query,arr);
//        return true;

        jdbcTemplate.update(query, new Object[]{customer.getId(),
                customer.getFirstName(), customer.getLastName(),
                String.valueOf(customer.getGender()), customer.getDateOfBirth(),
                customer.getContactNo(), customer.getEmail(),
                customer.getMonthlyIncome(), customer.getProfession(),
                customer.getMonthlyExpense(), customer.getDesignation(),
                customer.getCompanyName(), customer.getId()});
        return true;
    }

    public boolean deleteCustomer(int customerId) {
        String query = "delete from lms_customer_m_17155_1 where customer_id = " + customerId;
        int check = jdbcTemplate.update(query);
        if (check == 1)
            return true;
        else return false;
    }

    public LMS_Customer getCustomer(int customerId) throws CustomerNotFoundException {
        String query = "select * from lms_customer_m_17155_1 where customer_id = " + customerId;
        CustomerMapper mapper = new CustomerMapper();
        List<LMS_Customer> customerList = jdbcTemplate.query(query, mapper);
        if (!customerList.isEmpty())
            return customerList.get(0);
        else {
            throw new CustomerNotFoundException("customer not found");
        }

//        catch (EmptyResultDataAccessException e){
//            throw new CustomerNotFoundException("customer not found");
//        }
    }

    public List<LMS_Customer> getAllCustomers() {
        System.out.println("print all customers");
        String query = "select * from lms_customer_m_17155_1";
        CustomerMapper mapper = new CustomerMapper();
        List<LMS_Customer> customers = jdbcTemplate.query(query, mapper);
        return customers;
    }

    public List<LMS_Customer> getCustomersByName(String custName) throws NullPointerException {
        String query = "select * from lms_customer_m_17155_1 where concat(concat(first_name,' '),last_name) = '" + custName + "'";
        CustomerMapper mapper = new CustomerMapper();
        List<LMS_Customer> customerList = jdbcTemplate.query(query, mapper);
        if (!customerList.isEmpty())
            return customerList;
        else
            System.out.println("no customer");
        throw NullPointerException;

    }

    public List<String> getCustomersName() {
        System.out.println("print all customers");
        String query = "select concat(concat(first_name,' '),last_name) from lms_customer_m_17155_1";
//        CustomerMapper mapper = new CustomerMapper();
        List<String> customersname = jdbcTemplate.query(query, new RowMapper<String>() {
            @Override
            public String mapRow (ResultSet resultSet,int i) throws SQLException {
                LMS_Customer customer1 = new LMS_Customer();
                String name = resultSet.getString(1);
                return name;
            }
        });
        return customersname;
    }
}
