package mvcpkg.contollerpkg.Exception;

public class CustomerNotFoundException extends Throwable {
    public CustomerNotFoundException(String str) {
        super(str);
    }
}
