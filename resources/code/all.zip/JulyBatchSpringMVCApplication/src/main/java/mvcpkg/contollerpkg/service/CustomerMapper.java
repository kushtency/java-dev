package mvcpkg.contollerpkg.service;

import org.springframework.jdbc.core.RowMapper;
import mvcpkg.contollerpkg.entity.LMS_Customer;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerMapper implements RowMapper {
        @Override
        public LMS_Customer mapRow(ResultSet resultSet, int i) throws SQLException {
            LMS_Customer customer1 = new LMS_Customer();
            customer1.setId(resultSet.getString(1));
            customer1.setFirstName(resultSet.getString(2));
            customer1.setLastName(resultSet.getString(3));
            customer1.setGender(resultSet.getString(4).charAt(0));
            customer1.setDateOfBirth(resultSet.getDate(5));
            customer1.setContactNo(resultSet.getString(6));
            customer1.setEmail(resultSet.getString(7));
            customer1.setMonthlyIncome(resultSet.getDouble(8));
            customer1.setProfession(resultSet.getString(9));
            customer1.setMonthlyExpense(resultSet.getDouble(10));
            customer1.setDesignation(resultSet.getString(11));
            customer1.setCompanyName(resultSet.getString(12));
            return customer1;
    }
}
