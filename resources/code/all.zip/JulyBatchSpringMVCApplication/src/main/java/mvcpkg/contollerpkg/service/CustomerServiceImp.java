package mvcpkg.contollerpkg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import mvcpkg.contollerpkg.Exception.CustomerNotFoundException;
import mvcpkg.contollerpkg.dao.CustomerDao;
import mvcpkg.contollerpkg.entity.LMS_Customer;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

@Service
public class CustomerServiceImp implements CustomerService{
    @Autowired
    CustomerDao customerDao;

    public void insert(LMS_Customer customer) {
        LocalDate currentDate = LocalDate.now();
        LocalDate dob = customer.getDateOfBirth().toLocalDate();
        Period period = Period.between(dob, currentDate);
        int age = period.getYears();
        if (age > 21) {
            customerDao.saveCustomer(customer);
            System.out.println("inserted via service");
        } else
            System.out.println("age should be greater than 21");
    }


    public void insertt(LMS_Customer customer) {
       customerDao.saveCustomer(customer);
    }

    public boolean updateCustomer(LMS_Customer customer1) {
        customerDao.updateCustomer(customer1);
        System.out.println("updated! you may check in database");
        return true;
    }

    public boolean deleteCustomer(int customerId) {
        System.out.println("deleting");
        customerDao.deleteCustomer(customerId);
        System.out.println("deleted");
        return true;
    }

    public LMS_Customer getCustomer(int customerId) {
        try {
            return customerDao.getCustomer(customerId);
        } catch (CustomerNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public LMS_Customer getCustomerr(int customerId) {
        try {
            return customerDao.getCustomer(customerId);
        } catch (CustomerNotFoundException e) {
            throw new RuntimeException(e);
        }
    }


            public List<LMS_Customer> getAllCustomers(){
        return customerDao.getAllCustomers();
    }


    public List<LMS_Customer> getCustomersByName(String custName) {
        List<LMS_Customer> customers = customerDao.getCustomersByName(custName);
            if(customers.isEmpty()){
                System.out.println("no such name record found");
            }
            return customers;
    }

    public List<String> getCustomersName() {
        return customerDao.getCustomersName();
    }






    }
