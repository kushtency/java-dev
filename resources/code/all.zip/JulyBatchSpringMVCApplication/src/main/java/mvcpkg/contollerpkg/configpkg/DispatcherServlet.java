package mvcpkg.contollerpkg.configpkg;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;


//managing controller and view both
@Configuration
@ComponentScan({"mvcpkg","springcoreday3ans4","entity"})
@EnableWebMvc
public class DispatcherServlet {
//    @Bean
//    InternalResourceViewResolver InternalViewResolver() {
//        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
//        resolver.setPrefix()
//
//    }
@Bean
public DriverManagerDataSource dataSource(){
    DriverManagerDataSource dataSource = new DriverManagerDataSource();
    dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
    dataSource.setUrl("jdbc:oracle:thin:@10.1.50.198:1535:nsbt19c");
    dataSource.setUsername("training");
    dataSource.setPassword("training");
    return dataSource;
}
    @Bean
    public JdbcTemplate jdbcTemplate(){
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(dataSource());
        return jdbcTemplate;
    }

}
