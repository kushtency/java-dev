package mvcpkg.contollerpkg;

import mvcpkg.contollerpkg.service.Dateformat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import mvcpkg.contollerpkg.entity.LMS_Customer;
import mvcpkg.contollerpkg.service.CustomerServiceImp;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Controller
public class GreetController {
    @Autowired
    CustomerServiceImp customerService;
//    --  1
//    @RequestMapping("greet.do")
//    public String greet(){
//        return "welcome.jsp";
//    }

//    --2
//    @RequestMapping("sayHello.do")
//    public String sayHello(@RequestParam("username") String name ){
//        return "display.jsp";
//    }

//    3---
//    @RequestMapping("sayHello.do")
//    public ModelAndView sayHello(@RequestParam("username") String name) {
//        ModelAndView modelAndView = new ModelAndView();
//        modelAndView.setViewName("display.jsp");
//        modelAndView.addObject("username", name);
//        return modelAndView;
//    }


//    ---4
    @RequestMapping("sayHello.do")
    public String forwardHello(@RequestParam("username") String username) {
        System.out.println("forwarding");
        return "redirect:next.do";
//        return "forward:next.do";
    }

    @RequestMapping("next.do")
    public String processRequest(){
        return "display.jsp";
    }


//    5----
    @RequestMapping("greet.do")
    public String header(@RequestHeader(value = HttpHeaders.REFERER)String refererrr){
        System.out.println("via header");
//        System.out.println(referer);
        System.out.println(HttpHeaders.REFERER);
        if(refererrr != null)
            return "forward:welcome.jsp";
        return  "errors";

    }

//    6----
@InitBinder
public void initBinder(WebDataBinder webDataBinder)
{
    System.out.println("data binder invoked!");
    webDataBinder.registerCustomEditor(LocalDate.class,"dob",new Dateformat());
}

    @ModelAttribute("genderoptions")
    public List<String> getLanguages(){
        return List.of("Male","Female");
    }

    @RequestMapping("showcustspringform.do")
    public String show(Model model){
        model.addAttribute("customer",new LMS_Customer());
        return "custSpringForm.jsp";
    }

    @RequestMapping(value = "registerCustomer.do", method = RequestMethod.POST)
    public String processCustomer(@ModelAttribute("customer")LMS_Customer customer)
    {
        customerService.insert(customer);
        return "success.jsp";
    }
    @RequestMapping(value = "updateCustomer.do", method = RequestMethod.POST)
    public void updateCustomer(@ModelAttribute("customer")LMS_Customer customer)
    {
        customerService.updateCustomer(customer);
    }

    @RequestMapping(value="showcustomernames.do")
    public String  CustNameList(Model model)
    {
        List<String> namelist = customerService.getCustomersName();
        model.addAttribute("namelist", namelist);
        return "NameLinks.jsp";
    }

    @RequestMapping(value="getcustbyName{item}.do")
    public String getcustinfobyName(@PathVariable String item, Model map){
        List<LMS_Customer> customerslist = customerService.getCustomersByName(item);
        map.addAttribute("custlist", customerslist);
        return "list.jsp";
    }

    @RequestMapping(value="emicalc.do")
    public void getemi(@RequestParam("income")){

    }

}
