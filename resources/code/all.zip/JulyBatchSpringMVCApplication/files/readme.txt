
 in redirect---The url in the browser changes to the new url
 in forward===The url in the browser remains the same.

 in redirect--fresh request is sent
 in forward-- request is forward from one servlet to another

 in redirect--parameters are not shown in url
 in forward-- parametrs are  shown in url