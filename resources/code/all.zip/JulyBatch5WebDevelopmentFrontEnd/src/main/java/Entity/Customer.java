package Entity;

import java.time.LocalDate;
import java.util.Arrays;

public class Customer {
    private String  customerName;
    private LocalDate dob;
    private String email;
    private String contactNo;
    private double monthlySalary;
    private char gender;
    private String[] hobbies;
    private String location;

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public String[] getHobbies() {
        return hobbies;
    }

    public void setHobbies(String[] hobbies) {
        this.hobbies = hobbies;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerName='" + customerName + '\'' +
                ", dob=" + dob +
                ", email='" + email + '\'' +
                ", contactNo='" + contactNo + '\'' +
                ", monthlySalary=" + monthlySalary +
                ", gender=" + gender +
                ", hobbies=" + Arrays.toString(hobbies) +
                ", location='" + location + '\'' +
                '}';
    }
}
