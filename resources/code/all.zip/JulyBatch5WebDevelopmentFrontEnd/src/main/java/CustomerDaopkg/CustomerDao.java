package CustomerDaopkg;

import Entity.Customer;

public interface CustomerDao {
    public int register(Customer customer);
}
