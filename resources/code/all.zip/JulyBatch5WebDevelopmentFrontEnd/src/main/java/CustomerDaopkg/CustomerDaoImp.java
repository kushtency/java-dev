package CustomerDaopkg;

import Entity.Customer;

public class CustomerDaoImp implements CustomerDao{

    @Override
    public int register(Customer customer){
        //
        int id = getCustomerId(customer.getEmail());
        return id;

    }

    public int getCustomerId(String email){
        //select customerid from table where email = givem email

        //via resultset return that customerid

        return 0;
    }
}
