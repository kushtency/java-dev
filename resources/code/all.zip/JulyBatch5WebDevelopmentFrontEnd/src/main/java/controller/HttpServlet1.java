package controller;

import CustomerDaopkg.CustomerDaoImp;
import Entity.Customer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@WebServlet(urlPatterns = "/submit")
public class HttpServlet1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Customer customer=new Customer();

        customer.setCustomerName(req.getParameter("cname"));
        customer.setDob(LocalDate.parse(req.getParameter("cdob")));
        customer.setEmail(req.getParameter("cemail"));
        customer.setContactNo(req.getParameter("ccontactno"));
        customer.setMonthlySalary((Double.parseDouble(req.getParameter("cmonthlysalary"))));
        customer.setGender(req.getParameter("cgender").charAt(0));
        customer.setHobbies(new String[]{Arrays.toString(req.getParameterValues("chobbies"))});
        customer.setLocation(req.getParameter("clocation"));


        resp.setContentType("text/html");
        PrintWriter out=resp.getWriter();
        out.println(customer);


        CustomerDaoImp customerDao = new CustomerDaoImp();
        customerDao.register(customer);


    }
}
