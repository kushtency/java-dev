package day4;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;
import springcoreday3ans4.Exception.CustomerNotFoundException;
import springcoreday3ans4.entity.LMS_Customer;
import springcoreday3ans4.service.CustomerService;

import java.time.LocalDate;
import java.time.Period;

//import java.util.logging.Logger;

@Component
@Aspect
@EnableAspectJAutoProxy
public class AOPCrossCuttingConcerns {
    //    @Before("execution (* day4.TesterMethods.*(..))")
//    public void log(){
//        System.out.println("this method via aspect..");
//    }
    public static Logger loggerFile = LogManager.getLogger("FileLogger");

    //1----
    @After("execution (* day4.Calculator.*add*(..))")
    public void logafterAdviceAdd(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        loggerFile.info("Arguments passed in the add method--" + args[0] + " ," + args[1]);
    }

    @Before("execution (* day4.Calculator.*subtract*(..))")
    public void logBeforeAdviceSubtract(JoinPoint joinPoint) {
        Object[] args = joinPoint.getArgs();
        loggerFile.info("Arguments passed in the subtract method--" + args[0] + " ," + args[1]);
    }

    @AfterReturning(value = "execution (* day4.Calculator.*multiply*(..))", returning = "answer")
    public void logAfterReturningAdviceMultiply(JoinPoint joinPoint, Object answer) {
        Object[] args = joinPoint.getArgs();
        loggerFile.info("Arguments passed in the multiply method---" + args[0] + " ," + args[1] + " & ans is--" + answer);
    }

    @AfterThrowing(value = "execution (* day4.Calculator.*divide*(..))", throwing = "exception")
    public void logAfterThrowingAdviceDivide(JoinPoint joinPoint, ArithmeticException exception) {
        Object[] args = joinPoint.getArgs();
        loggerFile.info("Arguments passed in the divide method---" + args[0] + " ," + args[1] + " Exception thrown---" + exception.toString());
    }

//         2----


//    a--
    @Around("execution (* springcoreday3ans4.service.CustomerService.insertt*(..)))")
    public void aroundtestSave(ProceedingJoinPoint joinPoint) {
        System.out.println("inserting via Aop");
        Object[] args = joinPoint.getArgs();
        LMS_Customer customer = (LMS_Customer) args[0];
        CustomerService service = new CustomerService();
        LocalDate currentDate = LocalDate.now();
        LocalDate dob= customer.getDateOfBirth().toLocalDate();
        Period period = Period.between(dob, currentDate);
        int age = period.getYears();
        if (age > 21) {
            try {
                joinPoint.proceed();
            } catch (Throwable e) {
                throw new RuntimeException(e);
            }
            System.out.println("inserted via aop");
        } else
            System.out.println("age should be greater than 21");
    }


//        b--
        @Before("execution (* springcoreday3ans4.service.CustomerService.getAllCustomers*(..)))")
        public void beforeGetAll(JoinPoint joinPoint) {
            System.out.println("printed via Aop");
        }

//        c--
    @After("execution (* springcoreday3ans4.service.CustomerService.updateCustomer*(..)))")
    public void after(JoinPoint joinPoint) {
    }


    //d--
    @AfterThrowing(value = "execution (* springcoreday3ans4.service.CustomerService.getCustomerr*(..)))",  throwing = "exception")
    public void afterThrowinggetCustomer(JoinPoint joinPoint, Exception exception ) {
        Object[] args = joinPoint.getArgs();
        LMS_Customer customer = (LMS_Customer) args[0];
        loggerFile.info("Customer with id " + customer.getId() + "exception---" + exception);
    }


//    e--
    @AfterReturning(value = "execution (* springcoreday3ans4.service.CustomerService.getCustomerr*(..)))" , returning = "customer")
    public void afterReturngetCustomer(JoinPoint joinPoint, LMS_Customer customer) {
        System.out.println("customer fetched via after returning");
        loggerFile.info("Customer with id " + customer.getId() );
    }


//--f

//    @After("execution (* springcoreday3ans4.service.CustomerService.getCustomersByName*(..)))")
//    public void afterbyname(JoinPoint joinPoint) {
//        System.out.println("printed FOR GIVEN CUSTOMER namevia Aop");
//    }
//    @Before("execution (* springcoreday3ans4.service.CustomerService.getCustomersByName*(..)))")
//    public void beforebyname(JoinPoint joinPoint) {
//        System.out.println("printed FOR GIVEN CUSTOMER namevia before Aop");
//    }
    @AfterThrowing(value = "execution (* springcoreday3ans4.service.CustomerService.getCustomersByName*(..)))",  throwing = "exception")
    public void afterThrowingbyname(JoinPoint joinPoint, Exception exception ) {
        System.out.println("customer not available");
        Object[] args = joinPoint.getArgs();
        LMS_Customer customer = (LMS_Customer) args[0];
        loggerFile.info("Customer with " + customer.getFirstName() + "exception---" + exception);
    }

    @AfterReturning(value = "execution (* springcoreday3ans4.service.CustomerService.getCustomersByName*(..)))" , returning = "customer")
    public void afterReturnbyname(JoinPoint joinPoint, LMS_Customer customer) {
        System.out.println("customer fetched via after returning");
        loggerFile.info("Customer with name " + customer.getId());
    }









}

