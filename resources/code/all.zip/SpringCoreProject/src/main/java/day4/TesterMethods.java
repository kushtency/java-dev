package day4;

import org.springframework.stereotype.Component;

@Component("tester")

public class TesterMethods {
    public void show(){
        System.out.println("this is show method");
    }

    public void checkage(int age){
        if (age > 18)
        System.out.println("true");
    }
}
