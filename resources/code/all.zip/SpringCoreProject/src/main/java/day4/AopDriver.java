package day4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import springcoreday3ans4.service.CustomerService;

public class AopDriver {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(springconfigday4.class);
//        TesterMethods testerMethods = (TesterMethods) context.getBean("tester");
//        testerMethods.show();
//        testerMethods.checkage(19);

        Calculator calculator = (Calculator) context.getBean("mycalculator");
        System.out.println(calculator.add(1,2));
        System.out.println(calculator.add("abs","tract"));
        System.out.println(calculator.subtract(121.121,121.0));
        System.out.println(calculator.multiply(12,12));
        System.out.println(calculator.divide(12,6));
        System.out.println(calculator.divide(121.34567, 12.0000));
        System.out.println(calculator.divide(100,0));

//        CustomerService

    }

}
