package day4;

import org.springframework.stereotype.Component;

@Component("mycalculator")
public class Calculator {
        public Calculator(){}
        public int add(int num1, int num2){
            return num1 +num2;
        }
        public double add(double num1, double num2){
            return num1 +num2;
        }
        public String add(String num1, String num2){
            return num1 +num2;
        }
        public int subtract(int num1, int num2) {
            return num1 - num2;
        }
        public double subtract(double num1, double num2) {
            return num1 - num2;
        }
        public int multiply(int num1, int num2){
            return num1*num2;
        }
        public double multiply(double num1, double num2){
            return num1*num2;
        }
        public int divide(int num1, int num2){
            return num1/num2;
        }
        public double divide(double num1, double num2){
            return num1/num2;
        }


}
