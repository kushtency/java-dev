package springcoreday3ans4.dao;

import springcoreday3ans4.Exception.CustomerNotFoundException;
import springcoreday3ans4.entity.LMS_Customer;

import java.util.List;

public interface CustomerDao {
    public  void saveCustomer(LMS_Customer customer);
    public boolean updateCustomer(LMS_Customer customer);
    public boolean deleteCustomer(int customerId);
    public LMS_Customer getCustomer(int customerId) throws CustomerNotFoundException;
    public List<LMS_Customer> getAllCustomers();
    public List<LMS_Customer> getCustomersByName(String custName);



}
