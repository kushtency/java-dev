package springcoreday3ans4.service;

import springcoreday3ans4.entity.LMS_Customer;


public class Getters {

    public static Object[] getarray(LMS_Customer customer){
        return new Object[]{customer.getId(),
                customer.getFirstName(), customer.getLastName(),
                String.valueOf(customer.getGender()), customer.getDateOfBirth(),
                customer.getContactNo(), customer.getEmail(),
                customer.getMonthlyIncome(), customer.getProfession(),
                customer.getMonthlyExpense(), customer.getDesignation(),
                customer.getCompanyName()};
    }

}
