package springcoreday3ans4.Exception;

public class CustomerNotFoundException extends Throwable {
    public CustomerNotFoundException(String str) {
        super(str);
    }
}
