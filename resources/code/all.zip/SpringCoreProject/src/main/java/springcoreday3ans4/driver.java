package springcoreday3ans4;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import springcoreday3ans4.entity.LMS_Customer;
import springcoreday3ans4.service.CustomerService;

import java.sql.Date;

public class driver {
    public static void main(String[] args) {
        ApplicationContext context=new AnnotationConfigApplicationContext(SpringConfigans4.class);
        LMS_Customer customer = (LMS_Customer) context.getBean("lms_customer");

        customer.setId("1");
        customer.setFirstName("Alex");
        customer.setLastName("Anth");
        customer.setGender('M');
        customer.setDateOfBirth(Date.valueOf("2020-11-12"));
        customer.setContactNo("1234567890");
        customer.setEmail("abc@gmail.com");
        customer.setMonthlyIncome(123456);
        customer.setProfession("sde");
        customer.setMonthlyExpense(123);
        customer.setDesignation("sde");
        customer.setCompanyName("nucleus");

        CustomerService customerService = (CustomerService) context.getBean("customerservice");
//        customerService.insert(customer);
//        customerService.updateCustomer(customer);
//        customerService.deleteCustomer(1);


//        System.out.println(customerService.getCustomerr(3));
//
//            try{
//                System.out.println(customerService.getCustomerr(3));
//            }catch (Exception e){
//                e.printStackTrace();
//            }

//        System.out.println(customerService.getAllCustomers());


        System.out.println(customerService.getCustomersByName("Bob Anth"));
    }




}
