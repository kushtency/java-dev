package springcoreday3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class SpringconfiMain {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        Customer cust1 = (Customer)context.getBean("customerBean");
        System.out.println(cust1);
//        Customer cust2 = (Customer)context.getBean("customer");
//        System.out.println(cust2==cust1);
    }
}
