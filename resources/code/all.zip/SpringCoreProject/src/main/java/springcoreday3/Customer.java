package springcoreday3;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import springcoreday3.loanagreement;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
@Component("customerBean")
public class Customer {
    @Autowired
        private Address address;
    @Autowired
        List<loanagreement> loanagreements;
        private LocalDate dateOfBirth;
        private String customerName;
        private int customerId;
        private int moenthlyincome;
        private String profession;
        private String desgination;
        private String companyName;
        List<String> phoneNumbers;
        Set<String> emailAdressSet;

        public Customer(){
        }
        public Customer(String customerName) {
            this.customerName = customerName;
        }

//        public Customer(String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName) {
//            this.customerName = customerName;
//            this.customerId = customerId;
//            this.moenthlyincome = moenthlyincome;
//            this.profession = profession;
//            this.desgination = desgination;
//            this.companyName = companyName;
//        }

        public Customer(String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName, List<String> phoneNumbers, Set<String> emailAdressSet) {
            this.customerName = customerName;
            this.customerId = customerId;
            this.moenthlyincome = moenthlyincome;
            this.profession = profession;
            this.desgination = desgination;
            this.companyName = companyName;
            this.phoneNumbers = phoneNumbers;
            this.emailAdressSet = emailAdressSet;
        }

    public Customer(springcoreday3.Address address, String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName, List<String> phoneNumbers, Set<String> emailAdressSet) {
        this.address = address;
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
        this.phoneNumbers = phoneNumbers;
        this.emailAdressSet = emailAdressSet;

    }


    public Customer(springcoreday3.Address address, List<loanagreement> loanagreements, LocalDate dateOfBirth, String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName, List<String> phoneNumbers, Set<String> emailAdressSet) {
        this.address = address;
        this.loanagreements = loanagreements;
        this.dateOfBirth = dateOfBirth;
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
        this.phoneNumbers = phoneNumbers;
        this.emailAdressSet = emailAdressSet;
    }

    public Customer(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public Customer(LocalDate dateOfBirth, String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName) {
        this.dateOfBirth = dateOfBirth;
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
    }
    public Customer(String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
    }

        public String getCustomerName() {
            return customerName;
        }

        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public int getCustomerId() {
            return customerId;
        }

        public void setCustomerId(int customerId) {
            this.customerId = customerId;
        }

        public int getMoenthlyincome() {
            return moenthlyincome;
        }

        public void setMoenthlyincome(int moenthlyincome) {
            this.moenthlyincome = moenthlyincome;
        }

        public String getProfession() {
            return profession;
        }

        public void setProfession(String profession) {
            this.profession = profession;
        }

        public String getDesgination() {
            return desgination;
        }

        public void setDesgination(String desgination) {
            this.desgination = desgination;
        }

        public String getCompanyName() {
            return companyName;
        }

        public void setCompanyName(String companyName) {
            this.companyName = companyName;
        }


        public List<String> getPhoneNumbers() {
            return phoneNumbers;
        }

        public void setPhoneNumbers(List<String> phoneNumbers) {
            this.phoneNumbers = phoneNumbers;
        }

        public Set<String> getEmailAdressSet() {
            return emailAdressSet;
        }

        public void setEmailAdressSet(Set<String> emailAdressSet) {
            this.emailAdressSet = emailAdressSet;
        }


    public springcoreday3.Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }



    public List<loanagreement> getLoanagreements() {
        return loanagreements;
    }

    public void setLoanagreements(List<loanagreement> loanagreements) {
        this.loanagreements = loanagreements;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "address=" + address +
                ", loanagreements=" + loanagreements +
                ", dateOfBirth=" + dateOfBirth +
                ", customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", moenthlyincome=" + moenthlyincome +
                ", profession='" + profession + '\'' +
                ", desgination='" + desgination + '\'' +
                ", companyName='" + companyName + '\'' +
                ", phoneNumbers=" + phoneNumbers +
                ", emailAdressSet=" + emailAdressSet +
                '}';
    }
}
