package springcoreday3;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan(basePackages = "springcoreday3")
public class SpringConfig {
//    @Bean
//    @Scope("prototype")
//    public Customer customer()
//    {
//        return new Customer("Alex");
//    }
//    @Bean
//        public loanagreement loanagreements(){
//            return new loanagreement(1,1,1,1);
//        }
//        @Bean Address address(){
//            return new Address();
//        }


}
