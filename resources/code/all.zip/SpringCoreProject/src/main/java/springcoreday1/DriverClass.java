package springcoreday1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import springcoreday2.Customer;

public class DriverClass {
    public static void main(String[] args) {
//        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        System.out.println("context ready " );


//        Customer customer1 = (Customer) context.getBean("cust");
//        System.out.println(customer1);
//
//        Customer customer2 = (Customer) context.getBean("cust1");
//        System.out.println(customer2);

//        Customer customer3 = (Customer) context.getBean("cust2");
//        System.out.println(customer3);


//        //singleton
//        Employee employee = (Employee) context.getBean("emp");
//        Employee employee0 = (Employee) context.getBean("emp");
//        System.out.println(employee.equals(employee0));
//
//        //prototype
//        Employee employee1 = (Employee) context.getBean("emp1");
//        Employee employee2 = (Employee) context.getBean("emp1");
//        System.out.println(employee1.equals(employee2));

        //3
        springcoreday2.Customer customer4 = (Customer) context.getBean("cust3");
        System.out.println(customer4);

        context.close();
        System.out.println(customer4);
    }
}
