package springcoreday1;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.util.List;
import java.util.Set;
public class Customer {
    private String customerName;
    private int customerId;
    private int moenthlyincome;
    private String profession;
    private String desgination;
    private String companyName;
    List<String> phoneNumbers;
    Set<String> emailAdressSet;

    public Customer(){
    }

    public Customer(String customerName) {
        this.customerName = customerName;
    }

    public Customer(String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
    }

    public Customer(String customerName, int customerId, int moenthlyincome, String profession, String desgination, String companyName, List<String> phoneNumbers, Set<String> emailAdressSet) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.moenthlyincome = moenthlyincome;
        this.profession = profession;
        this.desgination = desgination;
        this.companyName = companyName;
        this.phoneNumbers = phoneNumbers;
        this.emailAdressSet = emailAdressSet;
    }
    @PostConstruct
    public void init() {
        System.out.println("init method...");
//        for (String number: phoneNumbers) {
//        if(!number.startsWith("+91")) {
//            number.concat("+91");
//        }

        //add condition for empty phoneNumbers list
        for (int i = 0; i < phoneNumbers.size(); i++){
            if(!phoneNumbers.get(i).startsWith("+91")) {;
                phoneNumbers.set(i, "+91" + phoneNumbers.get(i));
            }
        }
    }

    @PreDestroy
    public void destroy(){
        System.out.println("destroy method here...");
//        for (String number: phoneNumbers) {
//            phoneNumbers.remove(number);
//        }
//        for(String email: emailAdressSet){
//            emailAdressSet.remove(email);
//        }
        phoneNumbers.clear();
        emailAdressSet.clear();
    }
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getMoenthlyincome() {
        return moenthlyincome;
    }

    public void setMoenthlyincome(int moenthlyincome) {
        this.moenthlyincome = moenthlyincome;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getDesgination() {
        return desgination;
    }

    public void setDesgination(String desgination) {
        this.desgination = desgination;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }


    public List<String> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<String> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public Set<String> getEmailAdressSet() {
        return emailAdressSet;
    }

    public void setEmailAdressSet(Set<String> emailAdressSet) {
        this.emailAdressSet = emailAdressSet;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", moenthlyincome=" + moenthlyincome +
                ", profession='" + profession + '\'' +
                ", desgination='" + desgination + '\'' +
                ", companyName='" + companyName + '\'' +
                ", phoneNumbers=" + phoneNumbers +
                ", emailAdressSet=" + emailAdressSet +
                '}';
    }
}
