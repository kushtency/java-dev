package springcoreday2;
import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Dateformat extends PropertyEditorSupport {
    @Override
        public void setAsText(String value)
        {
            setValue(LocalDate.parse(value, DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        }
}
