package springcoreday2;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class driver {
    public static void main(String[] args) {
//        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("config2.xml");
        System.out.println("context ready ");

//        springcoreday2.Customer customer4 = (Customer) context.getBean("cust5");
//        System.out.println(customer4);
//
//        springcoreday2.Customer customer5 = (Customer) context.getBean("cust4");
//        System.out.println(customer5);

//        springcoreday2.Customer customerdob = (Customer) context.getBean("custdob");
//        System.out.println(customerdob);

        springcoreday2.DemoApp demo1 = (DemoApp) context.getBean("demo1");
        System.out.println(demo1);
        context.close();
//        System.out.println(customer4);

    }

}