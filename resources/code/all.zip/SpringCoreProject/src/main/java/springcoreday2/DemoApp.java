package springcoreday2;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class DemoApp {
        private int demoId;
        private String demoTask;

    public DemoApp(int demoId, String demoTask) {
        this.demoId = demoId;
        this.demoTask = demoTask;
        System.out.println("constructor of demoapp class...");
    }

    public DemoApp() {
    }

    @PostConstruct
        public void init() {
            System.out.println("PostConstruct method is called..");
        }

        @PreDestroy
        public void destroy() {
            System.out.println("PreDestroy method is called.");
        }

    public int getDemoId() {
        System.out.println("getter of demoid");
        return demoId;

    }

    public void setDemoId(int demoId) {
        System.out.println("setter of demoid");
        this.demoId = demoId;
    }

    public String getDemoTask() {
        System.out.println("getter of demotask");
        return demoTask;
    }

    public void setDemoTask(String demoTask) {
        System.out.println("setter of demotask");
        this.demoTask = demoTask;
    }

    @Override
    public String toString() {
        return "DemoApp{" +
                "demoId=" + demoId +
                ", demoTask='" + demoTask + '\'' +
                '}';
    }
}
