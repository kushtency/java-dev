package day17;

import java.io.*;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Ans1 {
    public static void main(String[] args) {
//        try {
//            FileOutputStream f = new FileOutputStream("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
//            f.write("Hello , I'm writer from FileOutputStream".getBytes());
//
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }


        try(
            FileWriter writer = new FileWriter("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
            ){
            writer.write("Hello , I'm writer from FileWriter ");
            //3
            writer.append("and modified too");
            }
         catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }

        try {
            FileReader f = new FileReader("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
            int ch;
            while ((ch=f.read())!= -1) {

                System.out.print((char)ch);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }




    }
}
