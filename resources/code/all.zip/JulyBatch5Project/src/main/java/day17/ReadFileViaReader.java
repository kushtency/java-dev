package day17;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileViaReader {
    public static void main(String[] args) {
        try {
            FileReader fileReader=new FileReader("C:\\Users\\avni.jain\\Documents\\password.txt");

            int ch;

            while((ch=fileReader.read())!=-1)
            {
                // business logic
                System.out.println(ch);
                System.out.print((char)ch);
            }
            System.out.println(ch);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

}
}
