package day17;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriteViaWriter {
    public static void main(String[] args) {
        try (
            FileWriter fileWriter = new FileWriter("C:\\Users\\avni.jain\\Documents\\password.txt");
            )
        {
            fileWriter.write("hello how r u?8888 ");
//            fileWriter.flush();
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }
}
