package day17;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class IODemo {
    public static void main(String[] args) {

//File file=new File("");
        try {
            FileInputStream fileInputStream=new FileInputStream("C:\\Users\\avni.jain\\Documents\\password.txt");
            System.out.println("file available :  "+fileInputStream.available());
            System.out.println( (char)(fileInputStream.read()));
            System.out.println( (char)(fileInputStream.read()));
            System.out.println("file available :  "+fileInputStream.available());

            while(fileInputStream.available()!=0)
            {
                System.out.print((char)(fileInputStream.read()));
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
