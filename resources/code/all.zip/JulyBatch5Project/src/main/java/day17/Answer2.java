package day17;

import java.io.*;
import java.util.Scanner;

public class Answer2 {
    public static void main(String[] args) {
//        try {
//            FileInputStream f = new FileInputStream("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
//            while (f.available()!= 0) {
//                System.out.print((char) f.read());
//            }
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

//        try {
//            FileReader f = new FileReader("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
//            int ch;
//            while ((ch=f.read())!= -1) {
//                System.out.print((char)ch);
//            }
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

        //4
//        Scanner sc = new Scanner(System.in);
//
//        System.out.println("enter integer");
//        int intvalue = sc.nextInt();
//
//        System.out.println("enter String");
//        String strvalue = sc.next();
//
//        System.out.println("enter double ");
//        double doubleValue = sc.nextDouble();
//        sc.close();
//        try {
//            PrintWriter writer = new PrintWriter("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\data.txt");
//            writer.println("Integer: " + intvalue);
//            writer.println("Double: " + doubleValue);
//            writer.println("String: " + strvalue);
//            writer.close();
//            System.out.println("Data written to data.txt.");
//        } catch (IOException e) {
//            System.err.println();
//        }
//
//        try {
//            FileReader f = new FileReader("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\data.txt");
//            int ch;
//            while ((ch=f.read())!= -1) {
//                System.out.print((char)ch);
//            }
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

        Scanner sc = new Scanner(System.in);
        char toFind = sc.next().charAt(0);
        sc.close();
        int count = 0;
        try { FileReader f = new FileReader("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");
        int ch;
        while ((ch=f.read())!= -1) {
            if(ch == toFind) {
                count++;
            }
        }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("The char appears count is " + count);

}
}
