package brd;
import java.util.Date;
public class CustomerMaster {
    private int customerId;
    public String customerCode;
    private String customerName;
    private String address1;
    private String Address2;
    private int pincode;
    private String email;
    private long contactno;
    private String primaryContactPerson;
    private status recordstatus;
    public enum status{
        N, //new
        M, //modified
        D, //deleted
        A,   //authorized
        R  //rejected
    };

    private flag flag;
    public enum flag{
        A,
        I
    };
    private Date createDate;
    private String createdBy;
    private Date modifiedDate;
    private String modifiedBy;
    private Date authorizedDate;
    private String authorizeddBy;

    @Override
    public String toString() {
        return "CustomerMaster{" +
                "customerId=" + customerId +
                ", customerCode='" + customerCode + '\'' +
                ", customerName='" + customerName + '\'' +
                ", address1='" + address1 + '\'' +
                ", Address2='" + Address2 + '\'' +
                ", pincode=" + pincode +
                ", email='" + email + '\'' +
                ", contactno=" + contactno +
                ", primaryContactPerson='" + primaryContactPerson + '\'' +
                ", recordstatus=" + recordstatus +
                ", flag=" + flag +
                ", createDate=" + createDate +
                ", createdBy='" + createdBy + '\'' +
                ", modifiedDate=" + modifiedDate +
                ", modifiedBy='" + modifiedBy + '\'' +
                ", authorizedDate=" + authorizedDate +
                ", authorizeddBy='" + authorizeddBy + '\'' +
                '}';
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public void setAddress2(String address2) {
        Address2 = address2;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setContactno(long contactno) {
        this.contactno = contactno;
    }

    public void setPrimaryContactPerson(String primaryContactPerson) {
        this.primaryContactPerson = primaryContactPerson;
    }

    public void setRecordstatus(status recordstatus) {
        this.recordstatus = recordstatus;
    }

    public void setFlag(CustomerMaster.flag flag) {
        this.flag = flag;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public void setAuthorizedDate(Date authorizedDate) {
        this.authorizedDate = authorizedDate;
    }

    public void setAuthorizeddBy(String authorizeddBy) {
        this.authorizeddBy = authorizeddBy;
    }


    public int getCustomerId() {
        return customerId;
    }
    public String getCustomerCode() {
        return customerCode;
    }
    public String getCustomerName() {
        return customerName;
    }

    public String getAddress1() {
        return address1;
    }

    public String getAddress2() {
        return Address2;
    }

    public int getPincode() {
        return pincode;
    }

    public String getEmail() {
        return email;
    }

    public long getContactno() {
        return contactno;
    }

    public String getPrimaryContactPerson() {
        return primaryContactPerson;
    }

    public status getRecordstatus() {
        return recordstatus;
    }

    public CustomerMaster.flag getFlag() {
        return flag;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public Date getAuthorizedDate() {
        return authorizedDate;
    }

    public String getAuthorizeddBy() {
        return authorizeddBy;
    }
}

