package brd;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class JDBCconnection {
    public  static Connection getConnection(){
        Connection connection = null;
        try {
            FileInputStream fileInputStream=new FileInputStream("src/main/resources/database-config.properties");
            Properties properties=new Properties();
            properties.load(fileInputStream);

            Class.forName(properties.getProperty("driver"));

            connection= DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"), properties.getProperty("password"));
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return connection;
    }
}
