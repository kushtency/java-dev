package brd;

public class SystemParameter {

    private String path;
    private String fileName;
    private String rejectionLevel;
    public String getPath() {
        return path;
    }

    public void setPath(String path) {

        this.path = path;

    }
    public String getFilename() {

        return fileName;

    }
    public void setFilename(String filrname) {

        this.fileName = fileName;

    }

    public String getRejectionLevel() {

        return rejectionLevel;

    }
    public void setRejectionlevel(String rejectionLevel) {

        this.rejectionLevel = rejectionLevel;

    }

}

