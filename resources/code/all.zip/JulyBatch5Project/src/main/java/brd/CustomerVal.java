package brd;

import validate.DataValidation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
public class CustomerVal {
    private static final Logger logger = LogManager.getLogger(CustomerVal.class);
    public static Connection connection= JDBCconnection.getConnection();
    PreparedStatement preparedStatement= null;
    public static List<CustomerMaster>  validateAndFillData(String path) {
        List<CustomerMaster> customerList = new ArrayList<>();
        List<String> data = new ArrayList<>();
        DataValidation dataValidation = new DataValidation();
        data = FileRead.read(path);
        for (String d : data) {
        int count = 0;
            String[] strings = d.split("~", 16);
            CustomerMaster c = new CustomerMaster();

            //customer code
            if (!strings[0].isEmpty()) {
                if (dataValidation.DataLength(strings[0].trim(), 10)) {
                    if (dataValidation.DataTypeValidation(strings[0].trim(), String.class)) {
                       if (DataValidation.SpecialCharacters(strings[0].trim(), "@")) {
                            c.setCustomerCode(strings[0].trim());
                            count++;
                       } else {
                            logger.info("Customer Code contains Special Characters");
                        }
                    } else {
                        logger.info("customer code Datatype doesnot match");
                    }
                }
                else
                    logger.info("customer code Data length exceeds");
            }
            else {
                logger.info("Customer code was mandatory to fill");

            }

            //customer Name
            if (!strings[1].isEmpty()) {
                if (dataValidation.DataLength(strings[1], 30)) {
                    if (dataValidation.DataTypeValidation(strings[1], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[1], "@")) {
                            c.setCustomerName(strings[1]);
                            count++;
                        } else {
                            logger.info("Customer Name contains Special Characters");
                        }
                    } else {
                        logger.info("Customer Name Datatype doesnot match");
                    }
                }
                else
                    logger.info("Customer name Data length exceeds");
            }
            else {
                    logger.info("Customer Name was mandatory to fill");

            }

            //customer add1
            if (!strings[2].isEmpty()) {
                if (dataValidation.DataLength(strings[2], 100)) {
                    if (dataValidation.DataTypeValidation(strings[2], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[2], "@")) {
                            c.setAddress1(strings[2]);
                            count++;
                        } else {
                            logger.info("Address1 contains Special Characters");
                        }
                    } else {
                        logger.info("Address1 Datatype doesnot match");
                    }
                }
                else
                    logger.info("Address1 Data length exceeds");
            }
            else {
                logger.info("Customer address was mandatory to fill");

            }

            // add2

            if (!strings[3].isEmpty()) {
                if (dataValidation.DataLength(strings[3], 100)) {
                    if (dataValidation.DataTypeValidation(strings[3], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[3], "@")) {
                            c.setAddress1(strings[3]);

                        } else {
                            logger.info("Address2 contains Special Characters");
                            break;
                        }
                    } else {
                        logger.info("Address2 Datatype doesnot match");
                        break;
                    }
                }
                else{
                    logger.info("Address2 Data length exceeds");
                    break;
                }
            }



            // pincode
            if (!strings[4].isEmpty()) {
                if (dataValidation.DataLength(strings[4], 6)) {
                    if (dataValidation.DataTypeValidation(strings[4], int.class)) {
                        if (DataValidation.SpecialCharacters(strings[4], "@")) {
                            c.setPincode(Integer.parseInt(strings[4]));
                            count++;
                        } else {
                            logger.info("Pincode contains Special Characters");
                        }
                    } else {
                        logger.info("Pincode Datatype doesnot match");
                    }
                }
                else
                    logger.info("Pincode Data length exceeds");
            }
            else {
                logger.info("pincode was mandatory to fill");

            }

//          email address
            if (!strings[5].isEmpty()) {
                if (dataValidation.DataLength(strings[5], 100)) {
                    if (dataValidation.DataTypeValidation(strings[5], String.class)) {
                        if (dataValidation.validateEmail(strings[5])) {
                            c.setEmail(strings[5]);
                            count++;
                        } else {
                            logger.info("email is not validated");
                        }
                    } else {
                        logger.info("Email Datatype doesnot match");
                    }
                }
                else
                    logger.info("Email Data length exceeds");
            }
            else {
                logger.info("email was mandatory to fill");
            }

//          contact number
            if (!strings[6].isEmpty()) {
                if (dataValidation.DataLength(strings[6], 20)) {
                    if (dataValidation.DataTypeValidation(strings[6], Integer.class)) {
                        if (DataValidation.SpecialCharacters(strings[6], "@")) {
                            c.setContactno(Long.parseLong(strings[6]));

                        } else {
                            logger.info("Contact number contains Special Characters");
                            break;
                        }
                    } else {
                        logger.info("Contact number Datatype doesnot match");
                        break;
                    }
                }
                else{
                    logger.info("contact number Data length exceeds");
                    break;
                }
            }

            //primary contact person
            if (!strings[7].isEmpty()) {
                if (dataValidation.DataLength(strings[7], 100)) {
                    if (dataValidation.DataTypeValidation(strings[7], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[7], "@")) {
                            c.setPrimaryContactPerson(strings[7]);
                            count++;
                        } else {
                            logger.info("Contact Person contains Special Characters");
                        }
                    } else {
                        logger.info("Contact Person Datatype doesnot match");
                    }
                }
                else
                    logger.info("Contact Person Data length exceeds");
            }
            else {
                logger.info("primary contact person was mandatory to fill");

            }

            // Setting record status enum
            if (!strings[8].isEmpty()) {
                if (dataValidation.DataLength(strings[8], 1)) {
                    if (dataValidation.DataTypeValidation(strings[8], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[8], "#")) {
                            c.setRecordstatus(CustomerMaster.status.valueOf(strings[8]));
                            count++;
                        } else {
                            logger.info("Record status enum contains Special Characters");
                        }
                    } else {
                        logger.info("Record status enum doesnot match");
                    }
                }
                else
                    logger.info("Record status Data length exceeds");
            }
            else {
                logger.info("record was mandatory to fill");

            }

            // setting flag enum

            if (!strings[9].isEmpty()) {
                if (dataValidation.DataLength(strings[9], 10)) {
                    if (dataValidation.DataTypeValidation(strings[9], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[9], "@")) {
                            c.setFlag(CustomerMaster.flag.valueOf(strings[9]));
                            count++;
                        } else {
                            logger.info("Flag contains Special Characters");
                        }
                    } else {
                        logger.info("flag Datatype doesnot match");
                    }
                }
                else
                    logger.info("flag Data length exceeds");
            }
            else {
                logger.info("flag was mandatory to fill");

            }
                try {
                    if (strings[10] != null) {
                        c.setCreateDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[10]));
                        count++;
                    }
                    if (!strings[12].isEmpty()) {
                        c.setModifiedDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[12]));
                    }
                    if (!strings[14].isEmpty()) {
                        c.setAuthorizedDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[14]));
                    }
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

                //created by
            if (!strings[11].isEmpty()) {
                if (dataValidation.DataLength(strings[11], 30)) {
                    if (dataValidation.DataTypeValidation(strings[11], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[11], "@")) {
                            c.setCreatedBy(strings[11]);
                            count++;
                        } else {
                            logger.info("created by contains Special Characters");
                        }
                    } else {
                        logger.info("created by Datatype doesnot match");
                    }
                }
                else
                    logger.info("created by Data length exceeds");
            }
            else {
                logger.info("created by was mandatory to fill");

            }
            // modified by
            if (!strings[13].isEmpty()) {
                if (dataValidation.DataLength(strings[13], 30)) {
                    if (dataValidation.DataTypeValidation(strings[13], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[13], "@")) {
                            c.setModifiedBy(strings[13]);

                        } else {
                            logger.info("It contains Special Characters");
                            break;
                        }
                    } else {
                        logger.info("Datatype doesnot match");
                        break;
                    }
                }
                else{
                    logger.info("Data length");
                break;}
            }

            // authorized by
            if (!strings[15].isEmpty()) {
                if (dataValidation.DataLength(strings[15], 30)) {
                    if (dataValidation.DataTypeValidation(strings[15], String.class)) {
                        if (DataValidation.SpecialCharacters(strings[15], "@")) {
                            c.setModifiedBy(strings[15]);

                        } else {
                            logger.info("It contains Special Characters");
                            break;
                        }
                    } else {
                        logger.info("Datatype doesnot match");
                        break;
                    }
                }
                else{
                    logger.info("Data length");
                    break;
                }
            }

            if(count==10){
                customerList.add(c);}

            }

            for (int i = 0; i < customerList.size(); i++) {
                logger.info(customerList.get(i));
            }

            return customerList;
        }
}
