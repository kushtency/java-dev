package brd;

public class DriverMain {

    public static void main(String[] args) {
        FileRead.read("C:\\Users\\avni.jain\\IdeaProjects\\JulyBatch5Project\\src\\main\\java\\day17\\MyFile.txt");

    }
}
