//package day5;
//
//import day6inheri_comps.EducationLoan;
//
//public class Driver {
//    public static void main(String[] args) {
//
////        Childd ch1 = new Childd();
////        Parentt p1 = new Parentt();
////
////        ch1.ch_m();
//////        p1.p_m();    as method is delcared private so it wilol compln error
//        //3
//
////          Child c = new Child(2, 4);  // this will call it parent first and parent will call c's grandparent
////          Parent p = new Parent();
////          Grandparent g = new Grandparent(2);
//
//        ///4
////        Parent p = new Parent();
////        p.message();
////
////        Child subclass1 = new Child();
////        subclass1.message();
////
////        Child2 subclass2 = new Child2();
////        subclass2.message();
//
//        ///5
////        Parent parent1 = new Child();  //upcasting
////        parent1.message();
////
//////        Child par1 = (Child) parent;  //downcasting
//////        par1.message();
////
////        Parent parent2 = new Child2();  //upcasting
////        parent2.message();
//
////    Student s = new Student("s", "cds","dw", 6, 3333);
////        System.out.println(s.toString());
//
//        //7--
//        LoanProduct Homeprod = new HomeLoan();
//        System.out.println(Homeprod.LTVCalculationAsPerCollatoralType(12000, 120,
//                120, 12));
//
//        LoanProduct Educationprod = new EducationLoan();
//        System.out.println(Educationprod.LTVCalculationAsPerCollatoralType(12000, 120,
//                120, 12));
//
//        LoanProduct Consumerprod = new ConsumerVehicle();
//        System.out.println(Consumerprod.LTVCalculationAsPerCollatoralType(12000, 120,
//                120, 12));
//
////        prod1.LTVCalculationAsPerCollatoralType(1200000);
////
////        LoanProduct prod2 = new EducationLoan(350, 2300);
////        prod2.LTVCalculationAsPerCollatoralType(1200000);
////
////        LoanProduct prod3 = new ConsumerVehicle(350, 280);
////        prod3.LTVCalculationAsPerCollatoralType(1200);
//
//    }
//}