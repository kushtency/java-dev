package day5;

public class Child extends Parent {

    public Child() {

    }
    @Override
    public void message(){
        System.out.println("This is subclass 1");
    }
}
