package day5;

public class Parentt {
    private void p_m(){
        System.out.println("This is parent class");
    }
}
