package day5;
public class LoanProduct {
    private String loanProduct;
    private String loanProductName;
    private boolean assetBased;
    private String loanSecurity;
    private double minTenure;
    private double maxTenure;
    private double minLoanAmount;
    private double maxLoanAmount;
    private double roi;
    private double LTV;
    public double getLTV()
    {
        return LTV;
    }
    public LoanProduct(double ltv)
    {this.LTV = LTV;}
    public LoanProduct() {
    }
    public double calculatePropertyValue( double maxLoanAmount,
                                          double minLoanAmount, double roi) {
//        System.out.println((minLoanAmount + maxLoanAmount) / roi);
        return (minLoanAmount + maxLoanAmount) / roi;
    }
    public double LTVCalculationAsPerCollatoralType(double loanAmountAsked, double maxLoanAmount,
                                                    double minLoanAmount, double roi){
        LTV = loanAmountAsked / calculatePropertyValue(maxLoanAmount, minLoanAmount, roi);

        if (LTV <= 80) {
            System.out.println("LTV from is " + Math.round(LTV));
        } else {
            System.out.println("LoanProducClass[LTV can be maximum 80%]");
        }
        return LTV;
    }

//    protected void setLTV(double ltv) {
//        this.LTV = ltv;
//    }
}
