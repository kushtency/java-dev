package day5;

public abstract class Parent  {

//    int varp ;
    public Parent() {


    }

    public abstract void message();

}
