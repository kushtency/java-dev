package day5;

public class Childd extends Parentt {
    public void ch_m(){
        System.out.println("This is child class");
    }
}
