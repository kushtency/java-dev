package day5;

public class Child2 extends Parent{

    public Child2() {

    }

    @Override
    public void message()
    {
        System.out.println("This is subclass 2");
    }
}
