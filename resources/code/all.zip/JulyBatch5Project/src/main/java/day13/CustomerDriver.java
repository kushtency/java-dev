package day13;

import java.time.LocalDate;
import java.util.*;

public class CustomerDriver {
    public static void main(String[] args) {
        Bank1 bank = new Bank1();
        Customer c1 = new Customer("TCS", 67, "abc", 67890);
        Customer c2 = new Customer("IBM", 68, "bcd", 6780);
        Customer c3 = new Customer("Nucleus", 69, "def", 5000);
        Customer c4 = new Customer("Sopra", 70, "fgh", 6000);
        bank.registerCustomer(c1);
        bank.registerCustomer(c2);
        bank.printAllCustomers();
        bank.findCustomer(67);
        bank.deleteCustomer(68);
        bank.printAllCustomers();

        loanagreement l1 = new loanagreement(15000, LocalDate.of(2003,01,01), loanagreement.loanStatus.PENDING);
        loanagreement l2 = new loanagreement(13000, LocalDate.of(2001, 03,03), loanagreement.loanStatus.PENDING);
        loanagreement l3 = new loanagreement(19000, LocalDate.of(1999, 04,04), loanagreement.loanStatus.ACTIVE);
        loanagreement l5 = new loanagreement(20000, LocalDate.of(2001, 03,03), loanagreement.loanStatus.CLOSED);
        loanagreement l4 = new loanagreement(30000, LocalDate.of(1990, 02, 21), loanagreement.loanStatus.ACTIVE);
        c1.getLoan_list().add(l1);
        c1.getLoan_list().add(l2);
        c2.getLoan_list().add(l3);
        c2.getLoan_list().add(l4);
        c1.getLoan_list().add(l5);
        System.out.println(c1);
        //a--
        Comparator<loanagreement> loan_amount_comp = new Comparator<loanagreement>() {
            @Override
            public int compare(loanagreement o1, loanagreement o2) {
                return (int) ((int) o1.getLoanAmount() - o2.getLoanAmount());
            };
        };
        System.out.println("After sorting acc to date");
        Collections.sort(c1.getLoan_list(),loan_amount_comp);
        System.out.println(c1);



        //b--
//        Comparator<loanagreement> loan_disb_date_comp = new Comparator<loanagreement>() {
//            @Override
//            public int compare(loanagreement o1, loanagreement o2) {
//                return o1.getLoanDisbursalDate().compareTo(o2.getLoanDisbursalDate());
//            }
//
//            ;
//        };
//        System.out.println("After sorting acc to date");
//        Collections.sort(c1.getLoan_list(), loan_disb_date_comp);
//        System.out.println(c1);


        RepaymentSchedule schedule1 = new RepaymentSchedule(LocalDate.of(2024, 05, 05), 12000, RepaymentSchedule.status.PENDING);
        RepaymentSchedule schedule2 = new RepaymentSchedule(LocalDate.of(2000, 05, 05), 12000, RepaymentSchedule.status.REJECTED);
        RepaymentSchedule schedule3 = new RepaymentSchedule(LocalDate.of(2000, 05, 05), 12000, RepaymentSchedule.status.PENDING);

        ArrayList<RepaymentSchedule> loan_list = new ArrayList<>();
        loan_list.add(schedule1);
        loan_list.add(schedule2);
        loan_list.add(schedule3);
        l1.setRepay_list(loan_list);
        List<loanagreement> pending_loan_list = new ArrayList<>();
        System.out.println("Pending laons are----");
        for (RepaymentSchedule loan: loan_list){
            if (loan.getStatus().equals(RepaymentSchedule.status.PENDING)){
                System.out.println(loan);
            }
        }
//        long duration = Period.between(currdate, schedule1.getEmiDueDate()).getDays();
////        long diff = Math.abs(duration.toDays());



        //d--
        LocalDate currdate = LocalDate.now();
        System.out.println("loans whose emi date is less than current date");
        for (RepaymentSchedule loan: loan_list){
            if (loan.getEmiDueDate().isBefore(currdate)){
                System.out.println( loan);
                System.out.println(loan.getPenaltyCharges());
            }
        }


        //e--
//        System.out.println("Loan status that are closed");

//      for(loanagreement loan: c1.getLoan_list()){
//          if(loan.getLoanStatus().equals(loanagreement.loanStatus.CLOSED)){
//              c1.getLoan_list().remove(loan);
//          }
//      }

        //e--
        List<loanagreement> list = c1.getLoan_list();
        System.out.println("Loan status that are closed");
        list.removeIf(loanagreement -> loanagreement.getLoanStatus().equals(day13.loanagreement.loanStatus.CLOSED));
//        System.out.println(c1.getLoan_list());
        System.out.println(list);


        List<Customer> customers = new ArrayList<>() ;
        customers.add(c1);
        customers.add(c2);
        customers.add(c3);

        customers.parallelStream()
                .forEach(customer -> {
                    int loanCount = customer.getLoan_list().size();
                    System.out.println("Customer with id " + customer.getCustomerID() +" has " + loanCount + " loans.");
                });


    }
}
