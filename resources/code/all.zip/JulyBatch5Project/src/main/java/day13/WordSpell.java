package day13;
import java.util.HashMap;
import java.util.Map;

public class WordSpell {
    public static void main(String[] args) {

        Map<Integer, String> wordmap = new HashMap<>();
        wordmap.put(1, "one");
        wordmap.put(2, "two");
        wordmap.put(3, "three");
        wordmap.put(4, "four");
        wordmap.put(5, "five");
       //testing
        int[] numbersToTest = {2, 4, 5};
        System.out.println("Testing the number to word ");
        for (int number : numbersToTest) {
            String word = wordmap.get(number);
            System.out.println(number + " - " + word);
        }
    }
}


