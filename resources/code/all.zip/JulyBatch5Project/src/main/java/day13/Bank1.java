package day13;
import day6inheri_comps.*;
import day6inheri_comps.LoanProduct;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class Bank1  {
     HashSet<day13.Customer> customers_hashset = new HashSet<>();
    private LoanProduct[] loanproducts = new LoanProduct[10];
    public static  int cust_count = 0;
    public int loanprod_count = 0;
    public Bank1() {
    }
    @Override
    public String toString() {
        for (day13.Customer cust: customers_hashset) {
            System.out.println("Bank{" + "customers=" + cust);
        }
        for (int j = 0; j < loanprod_count; j++) {
            System.out.println("Bank{" + "loanproduct=" + loanproducts[j]);
        }
        return "end";
    }
    public void printAllLoanProducts() {
        for (int j = 0; j < loanprod_count; j++) {
            System.out.println("Bank{" + "loanproduct " + j + "=" + loanproducts[j]);
        }
    }

    public boolean addNewLoanProduct() {
        if (loanprod_count < loanproducts.length) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter 1 for Home loan '\n' ,2 for cinsumer vehicle loan and 3 for education loan");
            int type = sc.nextInt();
            System.out.println("Enter loan name");
            String loanname = sc.next();
            System.out.println("Enter roi");
            double roi = sc.nextDouble();
            LoanProduct loan;
            if (type == 1) {
                loan = new HomeLoan(loanname, roi);
            } else if (type == 2) {
                loan = new ConsumerVehicle(loanname, roi);
            } else {
                loan = new EducationLoan(loanname, roi);
            }
            loanproducts[loanprod_count] = loan;
            loanprod_count++;
            return true;
        } else
            System.out.println("NO more space");
        return false;
    }

    public boolean addLoanProduct(String loanname, double roi) {
        if (loanprod_count < loanproducts.length) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter 1 for Home loan '\n' ,2 for consumer vehicle loan and 3 for education loan");
            int type = sc.nextInt();
            LoanProduct loan;
            if (type == 1) {
                loan = new HomeLoan(loanname, roi);
            } else if (type == 2) {
                loan = new ConsumerVehicle(loanname, roi);
            } else {
                loan = new EducationLoan(loanname, roi);
            }
            loanproducts[loanprod_count] = loan;
            loanprod_count++;
            return true;
        } else
            System.out.println("NO more space");
        return false;
    }

    public LoanProduct printLoanProductdetails(String name) {
        for (int i = 0; i < loanprod_count; i++) {
            if (name.equals(loanproducts[i].getLoanProductName())) {
                return loanproducts[i];
            }
        }
        return null;
    }

    public boolean removeLoanProduct(String name) {
        for (int i = 0; i < loanprod_count; i++) {
            if (name == loanproducts[i].getLoanProductName()) {
                for (int j = i; j < loanprod_count; j++) {
                    loanproducts[j] = loanproducts[j + 1];
                }
                loanprod_count--;
                return true;
            }
        }
        return false;
    }


    public boolean registerCustomer(day13.Customer customer) {
        customers_hashset.add(customer);
        return true;
    }
    public day13.Customer findCustomer(int custid) {
        for (day13.Customer cust: customers_hashset){
            if (cust.getCustomerID() == custid){
                return cust;
            }
        }
        return null;
    }
    public void printAllCustomers() {
        for (day13.Customer cust : customers_hashset) {
            System.out.println("Bank{ Customer " + " detail: " +
                    cust);
        }
    }
    public boolean findCustomer(day13.Customer customer) {
        for (day13.Customer cust : customers_hashset) {
            if (cust.getCustomerID() == customer.getCustomerID()) {
                return true;
            }
        }
        return false;
    }

    public void deleteCustomer(int id) {
        Iterator<day13.Customer> itr =  customers_hashset.iterator();
        while(itr.hasNext()){
            if (itr.next().getCustomerID() == id){
                itr.remove();
            }
        }
    }
    public HashSet<day13.Customer> getCustomers_hashset() {
        return customers_hashset;
    }

    public void setCustomers_hashset(HashSet<Customer> customers_hashset) {
        this.customers_hashset = customers_hashset;
    }

    public LoanProduct[] getLoanproducts() {
        return loanproducts;
    }

    public LoanProduct getLoanproduct(int i) {
        return loanproducts[i];
    }

    public void setLoanproducts(LoanProduct[] loanproducts) {
        this.loanproducts = loanproducts;
    }

    public double calculatePropertyValue(double maxLoanAmount,
                                         double minLoanAmount, double roi) {
        return (minLoanAmount + maxLoanAmount) / roi;
    }

    public void LTVCalculationAsPerCollatoralType(double loanAmountAsked, LoanProduct loanProduct) {
        double maxLoanAmount = loanProduct.getMaxLoanAmount();
        double minLoanAmount = loanProduct.getMinLoanAmount();
        double roi = loanProduct.getRoi();
        double ltv;
        loanProduct.setLTV(loanAmountAsked / calculatePropertyValue(maxLoanAmount, minLoanAmount, roi));
        ltv = loanProduct.getLTV();
        if (loanProduct.getLTV() <= 80) {
            System.out.println("LTV is " + Math.round(ltv));
        } else {
//            System.out.println("LTV is " + Math.round(ltv));
            System.out.println("LoanProductClass[LTV can be maximum 80%]");
        }
//        return ltv;
    }



    public static int getCust_count() {
        return cust_count;
    }






}