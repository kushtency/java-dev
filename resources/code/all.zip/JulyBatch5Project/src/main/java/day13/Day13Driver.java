package day13;

import java.util.*;
public class Day13Driver {


    public static void main(String[] args) {

//        Set<Employee> employeets = new TreeSet<>(Comparator.comparing(Employee::getEmpName));
        TreeSet<HashsetEmployee> employeets= new TreeSet<>();
        employeets.add(new HashsetEmployee(5, "Alex", 12000));
        employeets.add(new HashsetEmployee(2, "Sansa", 1200));
        employeets.add(new HashsetEmployee(3, "Bobb", 13000));
        for (HashsetEmployee elem : employeets) {
            System.out.println(elem);
        }
//        employeets.remove(new Employee(4, "Alex", 12000)); //robb
//        System.out.println("After removing");
//        for(Employee elem: employeets){
//            System.out.println(elem.toString());
//        }

        //iterator traversing
//        System.out.println("Iterator traversing");
//        Iterator<Employee> itr = employeets.iterator();
//           while (itr.hasNext()){
//               System.out.println(itr.next());
//        }

//        backward print not poss

        //remove with less salary
//        System.out.println("Employee with salary less than 10000 will be removed");
//        Iterator<Employee> salaryIterator = employeets.iterator();
//        while (salaryIterator.hasNext()) {
//            if (salaryIterator.next().getSalary() < 10000) {
//                salaryIterator.remove();
//            }
//        }


//        boolean check = employeets.contains(new Employee(4, "Alex", 12000));
//        System.out.println(check);
//
//        employeets.remove(new Employee(4, "Alex", 12000));
//        System.out.println(employeets.size());

//        System.out.println("After comparator");
//        for (Employee elem : employeets) {
//            System.out.println(elem);
//        }


        Iterator<HashsetEmployee> descendingIterator = employeets.descendingIterator();
        while (descendingIterator.hasNext()) {
            HashsetEmployee employee = descendingIterator.next();
            System.out.println(employee.getEmpId() + " - " + employee.getEmpName() + " - "
                    + employee.getSalary());
        }




    }
}