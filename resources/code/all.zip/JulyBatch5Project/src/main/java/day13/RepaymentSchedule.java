package day13;

import java.time.LocalDate;
public class RepaymentSchedule {
    private double emiAmount;
    private LocalDate emiDueDate;
    private status Status;

    public status getStatus() {
        return Status;
    }

    public void setStatus(status status) {
        Status = status;
    }

    enum status{
        PENDING,
        Active,
        REJECTED
    }
    private double principalComponent;
    private double interestAmount;
    private  double balancePrincipalComponent;
    private double penaltyCharges;


    @Override
    public String toString() {
        return "RepaymentSchedule{" +

                ", emiDueDate=" + emiDueDate +
                ", Status=" + Status +
                ", penaltyCharges=" + penaltyCharges +
                '}';
    }

    public RepaymentSchedule(LocalDate emiDueDate, double penaltyCharges, status Status) {
        this.emiDueDate = emiDueDate;
        this.penaltyCharges = penaltyCharges;
        this.Status = Status;
    }


    public double getEmiAmount() {
        return emiAmount;
    }

    public void setEmiAmount(double emiAmount) {
        this.emiAmount = emiAmount;
    }

    public LocalDate getEmiDueDate() {
        return emiDueDate;
    }

    public void setEmiDueDate(LocalDate emiDueDate) {
        this.emiDueDate = emiDueDate;
    }

    public double getPrincipalComponent() {
        return principalComponent;
    }

    public void setPrincipalComponent(double principalComponent) {
        this.principalComponent = principalComponent;
    }

    public double getInterestAmount() {
        return interestAmount;
    }

    public void setInterestAmount(double interestAmount) {
        this.interestAmount = interestAmount;
    }

    public double getBalancePrincipalComponent() {
        return balancePrincipalComponent;
    }

    public void setBalancePrincipalComponent(double balancePrincipalComponent) {
        this.balancePrincipalComponent = balancePrincipalComponent;
    }

    public double getPenaltyCharges() {
        return penaltyCharges;
    }

    public void setPenaltyCharges(double penaltyCharges) {
        this.penaltyCharges = penaltyCharges;
    }


}
