package day13;
import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;

public class loanagreement {
    public LocalDate getLoanDisbursalDate() {
        return loanDisbursalDate;
    }
    public void setLoanDisbursalDate(LocalDate loanDisbursalDate) {
        this.loanDisbursalDate = loanDisbursalDate;
    }
    ArrayList<RepaymentSchedule> repay_list = new ArrayList<>();
    private int loanAgreementId;
    public static int idGenrator = 1;
    private double loanAmount;
    private int tenure;
    private double roi;
    private double emipermonth;
    private loanStatus loanStatus;

    public loanagreement.loanStatus getLoanStatus() {
        return loanStatus;
    }

    public void setLoanStatus(loanagreement.loanStatus loanStatus) {
        this.loanStatus = loanStatus;
    }

    enum loanStatus{
        PENDING,
        ACTIVE,
        APPROVED,
        CLOSED,
        REJECTED};
    private int repaymentFreq;

    public loanagreement(double loanAmount, LocalDate loanDisbursalDate, loanStatus loanStatus) {
        this.loanAmount = loanAmount;
        this.loanDisbursalDate = loanDisbursalDate;
        this.loanStatus = loanStatus;
    }

    private LocalDate loanDisbursalDate;

    public void setLoanAgreementId(int loanAgreementId) {
        this.loanAgreementId = loanAgreementId;
    }

    public static int getIdGenrator() {
        return idGenrator;
    }

    public static void setIdGenrator(int idGenrator) {
        loanagreement.idGenrator = idGenrator;
    }

    public int getTenure() {
        return tenure;
    }

    public void setTenure(int tenure) {
        this.tenure = tenure;
    }

    public double getRoi() {
        return roi;
    }

    public void setRoi(double roi) {
        this.roi = roi;
    }

    public double getEmipermonth() {
        return emipermonth;
    }

    public void setEmipermonth(double emipermonth) {
        this.emipermonth = emipermonth;
    }

    public int getRepaymentFreq() {
        return repaymentFreq;
    }

    public void setRepaymentFreq(int repaymentFreq) {
        this.repaymentFreq = repaymentFreq;
    }

    public ArrayList<RepaymentSchedule> getRepay_list() {
        return repay_list;
    }

    public void setRepay_list(ArrayList<RepaymentSchedule> repay_list) {
        this.repay_list = repay_list;
    }



    @Override
    public String toString() {
        return "loanagreement{" +
                "repay_list=" + repay_list +
                ", loanAmount=" + loanAmount +
                ", loanDisbursalDate=" + loanDisbursalDate +
                " loan status is " + loanStatus +
                '}';
    }
//    --calcul emi

    public loanagreement(){
    }

    public double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public int getLoanAgreementId() {
        this.loanAgreementId = idGenrator++;
        return loanAgreementId;
    }

    public void calEMI(){
        roi = (roi/100)*0.083;
        tenure = tenure*12;
        emipermonth = loanAmount*roi * Math.pow((roi
        +1), tenure)/(Math.pow((roi+1), tenure) -1);
    }
//    generat-repaymentschedule
    public void generateRepaymentSchedule(){
        System.out.println("Agreement ID " + loanAgreementId);
        System.out.println("Loan Amount " + loanAmount);
        System.out.println("tenure " + tenure/12);
        System.out.println("ROI is " + roi*1200);
//        System.out.println("Loan status " + loanStatus.valueOf());
        System.out.println("EMI IS " + emipermonth);
        System.out.println("Loan disbrsal date is " + loanDisbursalDate);
        System.out.println("Repayment freq is " + repaymentFreq);
    }
    public double calculateLatepenalty(LocalDate currentDate){
        Duration duration = Duration.between(currentDate, loanDisbursalDate);
        long diff = Math.abs(duration.toDays());
        return diff*1000;
    }
    public double calculateLoanToValueRatio(double value){
        return loanAmount/value;
    }


}
