//package pack1;
//
//public class driver4 {
//    public static void main(String[] args) {
//        int i = 0;
//        Implementation imp = new Implementation();
//        System.out.println(imp.hasNext());
//        System.out.println(imp.next());
//
//    }
//
//}
