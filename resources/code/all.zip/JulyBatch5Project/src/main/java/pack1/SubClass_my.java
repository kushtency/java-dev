package pack1;

public class SubClass_my extends MyClass{



    public static void main(String[] args) {

        SubClass_my s = new SubClass_my();
        System.out.println(s.protected_method(6));
        System.out.println(s.public_method("abcd"));
        System.out.println(s.default_method("dfgh"));

    }
}
