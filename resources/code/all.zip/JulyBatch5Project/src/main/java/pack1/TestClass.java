package pack1;

public class TestClass {

    public static void main(String[] args) {
        MyClass m = new MyClass();

        //in same pakg all  ethods are accessible except private
        System.out.println(m.default_method("abcd"));

        System.out.println(m.public_method("sdfg"));
        System.out.println(m.protected_method(8));

    }
}
