package pack1.subpack1;

import pack1.MyClass;
import pack1.SubClass_my;

public class SubPack1Class  {


    public static void main(String[] args) {

        MyClass s = new MyClass();
//        System.out.println(s.protected_method(6));   not accessible
        System.out.println(s.public_method("abcd"));
//        System.out.println(s.default_method("dfgh"));  not accessible

    }
}
