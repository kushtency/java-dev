package pack1;

public class MyClass {
    private int private_method (int i){
        return i;
    }
    public String public_method (String s){
        return s;
    }
    protected int protected_method (int i){
        return i;
    }
    String default_method (String s){
        return s;
    }

}
