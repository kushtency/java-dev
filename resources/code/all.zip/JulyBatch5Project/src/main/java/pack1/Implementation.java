//package pack1;
//public class Implementation implements MyIterator{
//    private int index = 1;
//    private Customer[] customers = new Customer[10];
//    public boolean hasNext(){
//            if (( (index + 1) < customers.length) && customers[index+1] == null ) {
//                return true;
//            }
//            return false;
//    }
//    public Object next() {
//        this.index = this.index + 1;
//        if (hasNext() == true && customers[index] != null) {
//            return customers[index];
//        }
//        return customers[index];
//    }
//    public void remove(){
//        if((index > -1 && index < customers.length) && customers[index] != null){
//            customers[index]  = null;
//        }
//    }



//}

