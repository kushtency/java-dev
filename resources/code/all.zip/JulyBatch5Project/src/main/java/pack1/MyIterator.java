package pack1;

public interface MyIterator {
    public boolean hasNext();
    Object next();
    void remove();

}


