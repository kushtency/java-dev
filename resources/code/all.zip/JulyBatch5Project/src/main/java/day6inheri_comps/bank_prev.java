//package day6inheri_comps;
//import java.util.Arrays;
//public class Bank {
//    private Customer[] customers = new Customer[10];
//    public int cust_count = 0;

//    public Bank() {  }
//    @Override
//    public String toString() {
//        for (int i = 0;i<cust_count;i++) {
//            System.out.println("Bank{" + "customers=" + customers[i]);
//        }
//        return "end"; }
//    public boolean registerCustomer(Customer customer){
////         if (customers[0]==null){
////             System.out.println("for first");
////             customers[0] = customer;
////             count = 1;
////             return true; }
////         for(int i = 0; i< count;i++){
////             if(customer.getCustomerID() == customers[i].getCustomerID() || count > 10 ) {
////                return false;
////             }  }
////        for (int i = count; i < customers.length; i++){
////            if (customers[i] == null) {
////                System.out.println("for second");
////                customers[i] = customer;
////                count++;
////                return true;
////            }    }
////            return true;
////register
//        if (cust_count < customers.length) {
//            customers[cust_count] = customer;
//            cust_count++;
//            return true;
//        } else {
//            System.out.println("Maximum number of customers reached.");
//            return  false;
//        }
//    }
//    public Customer findCustomer(int custid){
//        int j;
//        for(int i = 0; i< cust_count;i++){
//            if(custid == customers[i].getCustomerID() ) {
//                return customers[i];
//            }  }
//        return null;
//    }
//    public void printAllCustomers() {
//        for (int i = 0;i<cust_count;i++) {
//            System.out.println("Bank{ Customer " + i + " detail: " +  customers[i]);
//        }
//    }
//    public void deleteCustomer(int id){
//        for(int i = 0; i< cust_count;i++){
//            if(id == customers[i].getCustomerID() ) {
////                System.out.println("from here");
//                for (int j = i;j<cust_count;j++){
//                    customers[j] = customers[j+1];
//                }
//                cust_count--;
//            }}}
//    public Customer[] getCustomers() {
//        return customers;
//    }
//    public void setCustomers(Customer[] customers) {
//        this.customers = customers;
//    } }
//
//
