package day6inheri_comps;
public class HomeLoan extends LoanProduct {
    private String properType;
    private String NatureofProperty;
    private String propertyPurpose;
    private String propertyOwnership;
    private double marketValue;
    private double builtUpArea;
    private double carpetArea;
    private int propertyAge;
//    public double calculatePropertyValue() {
//        return (marketValue * (builtUpArea + carpetArea));
//    }
    public HomeLoan(){
    }
    public HomeLoan(String loanProductName, double roi) {
        super(loanProductName,roi);
    }
    public HomeLoan(double marketValue, double builtUpArea,
                    double carpetArea) {
       super();
        this.marketValue = marketValue;
        this.builtUpArea = builtUpArea;
        this.carpetArea = carpetArea;
    }
    //    @Override
//    public double LTVCalculationAsPerCollatoralType(double loanAmountAsked) {
//        super.setLTV((loanAmountAsked / calculatePropertyValue()));
//        double ltv = getLTV();
//        if (getLTV() <= 80) {
//            System.out.println("LTV from Homeloanclass is " + Math.round(ltv));
//        } else {
//            System.out.println("LTV can be maximum 80%");
//        }
     public double LTVCalculationAsPerCollatoralType(double loanAmountAsked,  double maxLoanAmount,
                                                     double minLoanAmount, double roi) {
         return super.LTVCalculationAsPerCollatoralType(loanAmountAsked,  maxLoanAmount,
          minLoanAmount, roi);
     }



}
