//package day6inheri_comps;
////import pack1.Implementation;
//
//import pack1.MyIterator;
//
//public class driverday6 {
//    public static void main(String[] args) {
////        MyIterator inter = new MyIterator();
////        System.out.println(imp.hasNext());
////        System.out.println(imp.next());
//
//        Customer c1 = new Customer("TCS", 67, "abc", 67890);
//        Customer c2 = new Customer("IBM", 68, "bcd", 6780);
//        Customer c3 = new Customer("Nucleus", 69, "def", 5000);
//        Customer c4 = new Customer("Sopra", 70, "fgh", 6000);
//
//       Bank b = new Bank();
//       b.registerCustomer(c1);
//       b.registerCustomer(c2);
//       b.registerCustomer(c3);
//       b.printAllCustomers();
//
//
//       //4
////       Bank.Implementation obj = b.new Implementation();
////       while (obj.hasNext()) {
////           obj.remove();
////       }
////        System.out.println("after removing");
////       b.printAllCustomers();
//
//
//        //5
//        MyIterator localinnerclassinstance = b.methodForInner();
//        localinnerclassinstance.hasNext();
//
//
//
//
//
//
//
////        b.printAllLoanProducts();
//
//        //output for findcustomer
////        System.out.println("for the id 68:  customer details are " +  b.findCustomer(68));
//
//        //output for printall
////        b.registerCustomer(c3);
////        b.printAllCustomers();
//
//        //delete customer at this id
////        b.deleteCustomer(68);
////        System.out.println("after deleting");
////        b.printAllCustomers();
//
////        2 by passing fixed values and one by taking input from scannner
////        b.addLoanProduct("loan-a", 4);
////        b.addLoanProduct("loan-b", 2);
////        b.addNewLoanProduct();
////        System.out.println(b);
////        b.toString();
////        System.out.println("details of loanproducts with the given name is : " + b.printLoanProductdetails("loan-c"));
//
////        b.LTVCalculationAsPerCollatoralType(150000, b.getLoanproduct(1));
//
//
////        Bank b_instance = new Bank();
////
////        Maker m = b_instance;
////        m.registerCustomer(c1);
////        m.registerCustomer(c4);
////        m.addNewLoanProduct();
////
////
////        Operator o = b_instance;
////        System.out.println("for this id customer is" + o.findCustomer(67));
////        o.printAllCustomers();
////        o.printAllLoanProducts();
//    }
//
//
//    //in bank
//   // Bank instance;
//
////    public Bank returninstance(){
////        return instance;
////    }
//
//
////in driver
////    Maker m1 = new Bank();
////    Operator op = new Bank();
//
//}
