package day6inheri_comps;

public class EducationLoan extends day6inheri_comps.LoanProduct {
    private String courseName;
    private String collegeName;
    private String CourseType;
    private String degreeType;
    private String educationStream;
    private double totalFees;
//    double propertyValue = totalFees * 2.5; // assumption on given attr
    public EducationLoan(double ltv, double totalFees) {
        super(ltv);
        this.totalFees = totalFees;
    }

    public EducationLoan(String loanProductName, double roi) {
        super(loanProductName,roi);
    }


    public EducationLoan(){
    }
    //    @Overridden
//    public double LTVCalculationAsPerCollatoralType(double loanAmountAsked) {
//        super.setLTV(loanAmountAsked / propertyValue);
//        double ltv = getLTV();
//        if (getLTV() <= 80) {
//            System.out.println("LTV from educationLoanvalue class is " + Math.round(ltv));
//        } else {
//            System.out.println("LTV can be maximum 80%");
//        }
//
//        return ltv;
//    }

    public double LTVCalculationAsPerCollatoralType(double loanAmountAsked,  double maxLoanAmount,
                                                    double minLoanAmount, double roi) {
        return super.LTVCalculationAsPerCollatoralType(loanAmountAsked,  maxLoanAmount,
                minLoanAmount, roi);
    }

}
