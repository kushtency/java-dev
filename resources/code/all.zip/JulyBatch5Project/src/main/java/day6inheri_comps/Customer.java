package day6inheri_comps;
import java.time.LocalDate;
public class Customer {

//        public static int count = 0;
        private int customerID ;
//        public static int IDGenerate = 1;
        private String customerName;
        private LocalDate dateOfBirth;
        private String contactNumber;
        private String email;
        private double monthlyIncome;
        private String profession;
        private double totalMonthlyExpenses;
        private double maxEligibleLoanAmount;
        private String designation;
        private String companyName ;

        public double calDBR(double totalMonthlyExpenses, double monthlyIncome ){
            double dbr = (totalMonthlyExpenses/monthlyIncome);
            return dbr;
        }
        public double calMaxEligibleEMI(double totalMonthlyExpenses, double monthlyIncome){
            double dbr = calDBR(totalMonthlyExpenses, monthlyIncome);
            double emi = 0.5 * (monthlyIncome - (0.2 * dbr));
            return emi;
        }
        public double calEligibleLoanAmount(double totalMonthlyExpenses, double monthlyIncome, double monthly_rate, double tenure){
            double emi = calMaxEligibleEMI(totalMonthlyExpenses, monthlyIncome);
            double max_loan = (emi * ((Math.pow(1 + monthly_rate, tenure)) - 1)) /
                    (monthly_rate * (Math.pow(1 + monthly_rate, tenure)));
//            System.out.println("Maximum loan amount is " + max_loan);
            return max_loan;
        }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public double getTotalMonthlyExpenses() {
        return totalMonthlyExpenses;
    }

    public void setTotalMonthlyExpenses(double totalMonthlyExpenses) {
        this.totalMonthlyExpenses = totalMonthlyExpenses;
    }

    public double getMaxEligibleLoanAmount() {
        return maxEligibleLoanAmount;
    }

    public void setMaxEligibleLoanAmount(double maxEligibleLoanAmount) {
        this.maxEligibleLoanAmount = maxEligibleLoanAmount;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    public Customer(){

    }

        public Customer(String companyName, int customerID , String customerName, double monthlyIncome){
            this.companyName = companyName;
            this.customerID  = customerID;
            this.customerName = customerName;
            this.monthlyIncome = monthlyIncome;
        }
//        public Customer(String companyName){
//            this.companyName = companyName;
//            count++;
//            this.customerID = IDGenerate++;
//        }

//        public static int display(){
//            return count;
//        }
//    public Customer(int customerID){
//            this.customerID = IDGenerate++;
//    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerID=" + customerID +
                ", customerName='" + customerName + '\'' +
                ", companyName='" + companyName + '\'' +
                '}';
    }
}
