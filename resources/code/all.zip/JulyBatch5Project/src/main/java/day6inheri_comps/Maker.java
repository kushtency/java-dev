package day6inheri_comps;

public interface Maker {
     boolean registerCustomer(Customer customer);

     boolean addNewLoanProduct();
     void  deleteCustomer(int id);
     boolean removeLoanProduct(String loanname);



}
