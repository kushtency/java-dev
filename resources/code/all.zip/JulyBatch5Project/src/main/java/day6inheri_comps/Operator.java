package day6inheri_comps;

public interface Operator {
    void printAllLoanProducts();
    LoanProduct printLoanProductdetails(String name);
    void printAllCustomers();
    void LTVCalculationAsPerCollatoralType(double loanamountasked, LoanProduct loanProduct);

    Customer findCustomer(int id);
    boolean findCustomer(Customer customer);



}
