package Day14;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Day14 {
    public static Logger logger = LogManager.getLogger("ConsoleLogger");
    public static void main(String[] args) {
//        Stream<String> stringStream = ("a", "b", "c");

//        logger.info("me");

      List l = new ArrayList();
        l.add(1);
        l.add(2);
        l.add(3);
        l.add(3);

        l.stream().distinct().forEach(System.out::println);

//        l.stream().

        List<Employee> employeeList = new ArrayList<>();
        employeeList.add(new Employee(4, "Alex", 12000));
        employeeList.add(new Employee(2, "Sansa", 1200));
        employeeList.add(new Employee(2, "Sansa", 1200));

        Employee e = new Employee(3, "Robb", 13000);

        employeeList.add(e);
        employeeList.add(e);

//        for(Employee elem: employeeList){
//            System.out.println(elem);
//        }


//        employeeList.stream().distinct().forEach(System.out::println);


        employeeList.stream()
                .forEach((emp) ->
                {
                    emp.setEmail(emp.getEmpName().concat("@nucleussoftware.com"));
                    System.out.println(emp);
                });

//        employeeList

//        employeeList.stream().filter((empl) -> empl.getEmpName().substring(0,1).contains("A"))
//                .filter(emplo -> emplo.getSalary() > 2500)
//                .forEach(System.out::println);

        employeeList.stream().filter((empl) -> empl.getEmpName().startsWith("R"))
                .filter(emplo -> emplo.getSalary() > 2500 && emplo.getSalary() < 50000)
                .forEach(System.out::println);









    }


}
