package Day14;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Streamapi {
    public static void main(String[] args) {
        List<Integer> l = new ArrayList<>();
        l.add(1);
        l.add(2);
        l.add(6);
        l.add(3);
        l.add(5);
        l.add(4);

        l.stream().distinct().forEach(System.out::println);


        //2
        int sum = l.stream().mapToInt(i->1).sum();
        System.out.println("sum is : " + sum);

        //3
        List<Integer> cube = l.stream().map(i->i*i*i).filter(i->i>50).collect(Collectors.toList());
        System.out.println(cube);

        //4
        List<String> string_list = new ArrayList<>();
        string_list.add("guitar");
        string_list.add("piano");
        string_list.add("tabla");
        string_list.add("sitar");
        string_list.add("strings");
//        string_list.stream().filter(strings -> strings.length()>5).forEach(System.out::println);

        //5
//        string_list.stream().filter(strings -> strings.length()>5).count();

        //6
        int max = l.stream().mapToInt(Integer::intValue).max().getAsInt();
        System.out.println(max);

        //7
        System.out.println("First element is : " + string_list.stream().findFirst().get());




    }
}
