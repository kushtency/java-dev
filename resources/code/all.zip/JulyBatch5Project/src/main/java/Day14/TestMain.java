package Day14;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestMain {
    public static void main(String[] args) {
        Customer[] cust = new Customer[10000];

        long start1 = System.nanoTime();
        Arrays.stream(cust)
                .sequential()
                .forEach((t) -> {
                    for(int i = 0;i<10000;i++){
                        cust[i] = new Customer();
                    }
        });
        long end1 = System.nanoTime();

        System.out.println("Processiing time for sequantual: " + (end1-start1));

        long start2 = System.nanoTime();
        Arrays.stream(cust)
                .parallel()
                .forEach((t) -> {
                    for(int i = 0;i<10000;i++){
                        cust[i] = new Customer();
                    }
                });
        long end2 = System.nanoTime();
        System.out.println("Processiing time for parallel: " + (end2-start2));


        // day 13 ke customer driver m
//        List<day13.Customer> customers = new ArrayList<>() ;
//        customers.add(c1);
//        customers.add(c2);
//        customers.add(c3);
//
//        customers.parallelStream()
//                .forEach(customer -> {
//                    int loanCount = customer.getLoan_list().size();
//                    System.out.println("Customer with id " + customer.getCustomerID() +" has " + loanCount + " loans.");
//                });


    }
}
