package Loan.loanProducts;

import day6inheri_comps.LoanProduct;

public class ConsumerVehicle extends LoanProduct {
        private String assetCategory;
        private String assetVariant;
        private String assetModel;
        private String manufacturer;
        private int yearOfManufacture;
        private double assetCost;
        private double downPayment;
//        public ConsumerVehicle(double assetCost, double downPayment) {
//            super();
//            this.assetCost = assetCost;
//            this.downPayment = downPayment;
//        }
        public ConsumerVehicle(String loanProductName, double roi) {
            super(loanProductName,roi);
        }

        public ConsumerVehicle(){
        }
        //    public double calculatePropertyValue() {
//        double propertyValue = assetCost - downPayment; // Assuming
//        return propertyValue;
//    }
        //    @Override
//    public double LTVCalculationAsPerCollatoralType(double loanAmountAsked) {
//        super.setLTV((loanAmountAsked / calculatePropertyValue()));
//        double ltv = getLTV();
//        if (getLTV() <= 80) {
//            System.out.println("LTV from ConsumerVehicle loan is  " + Math.round(ltv));
//        } else {
//            System.out.println("LTV can be maximum 80%");
//        }
//        return ltv;
//    }
        public double LTVCalculationAsPerCollatoralType(double loanAmountAsked,  double maxLoanAmount,
                                                        double minLoanAmount, double roi) {
            return super.LTVCalculationAsPerCollatoralType(loanAmountAsked,  maxLoanAmount,
                    minLoanAmount, roi);
        }

    }


