package Loan.bank;
import day6inheri_comps.*;
import pack1.MyIterator;

import java.util.Scanner;

public class Bank implements Maker, Operator {
    private static Customer[] customers = new Customer[10];
    private LoanProduct[] loanproducts = new LoanProduct[10];
    public static  int cust_count = 0;
    public int loanprod_count = 0;

    public Bank() {
    }

    @Override
    public String toString() {
        for (int i = 0; i < cust_count; i++) {
            System.out.println("Bank{" + "customers=" + customers[i]);
        }
        for (int j = 0; j < loanprod_count; j++) {
            System.out.println("Bank{" + "loanproduct=" + loanproducts[j]);
        }
        return "end";
    }

    public void printAllLoanProducts() {
        for (int j = 0; j < loanprod_count; j++) {
            System.out.println("Bank{" + "loanproduct " + j + "=" + loanproducts[j]);
        }
    }

    public boolean registerCustomer(Customer customer) {
//         if (customers[0]==null){
//             System.out.println("for first");
//             customers[0] = customer;
//             count = 1;
//             return true; }
//         for(int i = 0; i< count;i++){
//             if(customer.getCustomerID() == customers[i].getCustomerID() || count > 10 ) {
//                return false;
//             }  }
//        for (int i = count; i < customers.length; i++){
//            if (customers[i] == null) {
//                System.out.println("for second");
//                customers[i] = customer;
//                count++;
//                return true;
//            }    }
//            return true;
//register
        if (cust_count < customers.length) {
            customers[cust_count] = customer;
            cust_count++;
            return true;
        } else {
            System.out.println("Maximum number of customers reached.");
            return false;
        }
    }

    public boolean addNewLoanProduct() {
        if (loanprod_count < loanproducts.length) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter 1 for Home loan '\n' ,2 for cinsumer vehicle loan and 3 for education loan");
            int type = sc.nextInt();
            System.out.println("Enter loan name");
            String loanname = sc.next();
            System.out.println("Enter roi");
            double roi = sc.nextDouble();
            LoanProduct loan;
            if (type == 1) {
                loan = new HomeLoan(loanname, roi);
            } else if (type == 2) {
                loan = new ConsumerVehicle(loanname, roi);
            } else {
                loan = new EducationLoan(loanname, roi);
            }
            loanproducts[loanprod_count] = loan;
            loanprod_count++;
            return true;
        } else
            System.out.println("NO more space");
        return false;
    }

    public boolean addLoanProduct(String loanname, double roi) {
        if (loanprod_count < loanproducts.length) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter 1 for Home loan '\n' ,2 for consumer vehicle loan and 3 for education loan");
            int type = sc.nextInt();
            LoanProduct loan;
            if (type == 1) {
                loan = new HomeLoan(loanname, roi);
            } else if (type == 2) {
                loan = new ConsumerVehicle(loanname, roi);
            } else {
                loan = new EducationLoan(loanname, roi);
            }
            loanproducts[loanprod_count] = loan;
            loanprod_count++;
            return true;
        } else
            System.out.println("NO more space");
        return false;
    }

    public Customer findCustomer(int custid) {
        for (int i = 0; i < customers.length; i++) {
            if (customers[i] != null && custid == customers[i].getCustomerID()) {
                return customers[i];
            }
        }
        return null;
    }

    public LoanProduct printLoanProductdetails(String name) {
        for (int i = 0; i < loanprod_count; i++) {
            if (name.equals(loanproducts[i].getLoanProductName())) {
                return loanproducts[i];
            }
        }
        return null;
    }
    public void printAllCustomers() {
        for (int i = 0; i < cust_count; i++) {
            System.out.println("Bank{ Customer " + i + " detail: " + customers[i]);
        }
    }

    public void deleteCustomer(int id) {
        for (int i = 0; i < cust_count; i++) {
            if (id == customers[i].getCustomerID()) {
//                System.out.println("from here");
                for (int j = i; j < cust_count; j++) {
                    customers[j] = customers[j + 1];
                }
                cust_count--;
            }
        }
    }

    public boolean removeLoanProduct(String name) {
        for (int i = 0; i < loanprod_count; i++) {
            if (name == loanproducts[i].getLoanProductName()) {
                for (int j = i; j < loanprod_count; j++) {
                    loanproducts[j] = loanproducts[j + 1];
                }
                loanprod_count--;
                return true;
            }
        }
        return false;
    }

    public Customer[] getCustomers() {
        return customers;
    }

    public void setCustomers(Customer[] customers) {
        this.customers = customers;
    }

    public LoanProduct[] getLoanproducts() {
        return loanproducts;
    }

    public LoanProduct getLoanproduct(int i) {
        return loanproducts[i];
    }

    public void setLoanproducts(LoanProduct[] loanproducts) {
        this.loanproducts = loanproducts;
    }

    public double calculatePropertyValue(double maxLoanAmount,
                                         double minLoanAmount, double roi) {
        return (minLoanAmount + maxLoanAmount) / roi;
    }

    public void LTVCalculationAsPerCollatoralType(double loanAmountAsked, LoanProduct loanProduct) {
        double maxLoanAmount = loanProduct.getMaxLoanAmount();
        double minLoanAmount = loanProduct.getMinLoanAmount();
        double roi = loanProduct.getRoi();
        double ltv;
//        loanProduct.setLTV(loanAmountAsked / calculatePropertyValue(maxLoanAmount, minLoanAmount, roi));
        ltv = loanProduct.getLTV();
        if (loanProduct.getLTV() <= 80) {
            System.out.println("LTV is " + Math.round(ltv));
        } else {
//            System.out.println("LTV is " + Math.round(ltv));
            System.out.println("LoanProductClass[LTV can be maximum 80%]");
        }
//        return ltv;
    }

    public boolean findCustomer(Customer customer) {
//       for (int i = 0; i < cust_count; i++) {
////            if (customers[i]= customer){
//            return true;
//             }
//         }
        return false;
    }
    public static int getCust_count() {
        return cust_count;
    }
    public static Customer[] getCustomerarr(){
        return customers;
    }
//      return findCustomer(customer.getCustomerID());

         static class Implementation implements MyIterator {

            int cust_count = getCust_count();
            Customer[] customers = getCustomerarr();
            private int current = 0;
            public boolean hasNext() {
                return current < cust_count;
            }
            public Object next() {
                if (hasNext()) {
                    return customers[current++];
                }
                return null;
            }
            public void remove() {
                if (current >= 0 && current <= cust_count) {
                    if (customers[current].getMonthlyIncome() < 500000) {
                        for (int i = current; i < cust_count - 1; i++) {
                            customers[i] = customers[i + 1];
                        }
                        customers[cust_count - 1] = null;
                        cust_count--;
                    }
                }
            }
    }


}