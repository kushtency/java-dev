package Loan.loanProducts;
    public class LoanProduct {
        private String loanProduct;
        private String loanProductName;
        private boolean assetBased;
        private String loanSecurity;
        private double minTenure;
        private double maxTenure;
        private double minLoanAmount;
        private double maxLoanAmount;
        private double roi;

        public String getLoanProductName() {
            return loanProductName;
        }

        private double LTV;

        public LoanProduct(String loanProductName, double roi) {
            this.loanProductName = loanProductName;
            this.roi =roi;
        }

        public double getLTV()
        {
            return LTV;
        }
        public LoanProduct(double ltv)
        {
            this.LTV = LTV;
        }
        public LoanProduct() {
        }

        public double getRoi() {
            return roi;
        }

        public void setRoi(double roi) {
            this.roi = roi;
        }

        public double calculatePropertyValue(double maxLoanAmount,
                                             double minLoanAmount, double roi) {
//        System.out.println((minLoanAmount + maxLoanAmount) / roi);
            return (minLoanAmount + maxLoanAmount) / roi;
        }
        public double getMaxTenure() {
            return maxTenure;
        }

        public void setMaxTenure(double maxTenure) {
            this.maxTenure = maxTenure;
        }
        public double getMinLoanAmount() {
            return minLoanAmount;
        }
        public void setMinLoanAmount(double minLoanAmount) {
            this.minLoanAmount = minLoanAmount;
        }

        public double getMaxLoanAmount() {
            return maxLoanAmount;
        }

        public void setMaxLoanAmount(double maxLoanAmount) {
            this.maxLoanAmount = maxLoanAmount;
        }

        public double LTVCalculationAsPerCollatoralType(double loanAmountAsked, double maxLoanAmount,
                                                        double minLoanAmount, double roi){
            LTV = loanAmountAsked / calculatePropertyValue(maxLoanAmount, minLoanAmount, roi);

            if (LTV <= 80) {
                System.out.println("LTV from is " + Math.round(LTV));
            } else {
                System.out.println("LoanProducClass[LTV can be maximum 80%]");
            }
            return LTV;
        }

//        @Override
        public String toString() {
            return "LoanProduct{" +
                    "loanProductName='" + loanProductName + '\'' + " and roi is" + roi +
                    '}';
        }

    protected void setLTV(double ltv) {
        this.LTV = ltv;
    }


}
