package Loan.bank;

import day6inheri_comps.Customer;

public interface Maker {
     boolean registerCustomer(Customer customer);

     boolean addNewLoanProduct();
     void  deleteCustomer(int id);
     boolean removeLoanProduct(String loanname);



}
