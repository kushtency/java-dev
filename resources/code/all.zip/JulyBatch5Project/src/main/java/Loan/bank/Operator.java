package Loan.bank;

import day6inheri_comps.Customer;
import day6inheri_comps.LoanProduct;

public interface Operator {
    void printAllLoanProducts();
    LoanProduct printLoanProductdetails(String name);
    void printAllCustomers();
    void LTVCalculationAsPerCollatoralType(double loanamountasked, LoanProduct loanProduct);

    Customer findCustomer(int id);
    boolean findCustomer(Customer customer);



}
