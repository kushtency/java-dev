package Loan.customerAndAgreementDetails;
import java.time.Duration;
import java.time.LocalDate;

public class loanagreement {
    private int loanAgreementId;
    public static int idGenrator = 1;
    private double loanAmount;
    private int tenure;
    private double roi;
    private double emipermonth;
    private LocalDate loanDisbursalDate;
    private enum loanStatus{
        PENDING,
        ACTIVE,
        APPROVED};
    private int repaymentFreq;
//    --calcul emi

    public loanagreement(){
    }

    public int getLoanAgreementId() {
        this.loanAgreementId = idGenrator++;
        return loanAgreementId;
    }

    public void calEMI(){
        roi = (roi/100)*0.083;
        tenure = tenure*12;
        emipermonth = loanAmount*roi * Math.pow((roi
        +1), tenure)/(Math.pow((roi+1), tenure) -1);
    }
//    generat-repaymentschedule
    public void generateRepaymentSchedule(){
        System.out.println("Agreement ID " + loanAgreementId);
        System.out.println("Loan Amount " + loanAmount);
        System.out.println("tenure " + tenure/12);
        System.out.println("ROI is " + roi*1200);
//        System.out.println("Loan status " + loanStatus.valueOf());
        System.out.println("EMI IS " + emipermonth);
        System.out.println("Loan disbrsal date is " + loanDisbursalDate);
        System.out.println("Repayment freq is " + repaymentFreq);
    }
    public double calculateLatepenalty(LocalDate currentDate){
        Duration duration = Duration.between(currentDate, loanDisbursalDate);
        long diff = Math.abs(duration.toDays());
        return diff*1000;
    }
    public double calculateLoanToValueRatio(double value){
        return loanAmount/value;
    }


}
