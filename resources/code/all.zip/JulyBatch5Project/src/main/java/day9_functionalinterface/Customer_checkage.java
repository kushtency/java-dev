package day9_functionalinterface;
import day3_assi.Customer;
import java.time.LocalDate;

public interface Customer_checkage {
    boolean customer_checkage_method(Customer customer);

    public static void main(String[] args) {
        Customer[] customers = new Customer[4];
        customers[0] = new Customer("nucleus", 11, "abc", 8000, LocalDate.of(2001, 5, 15));
        customers[1] = new Customer("tcs", 12, "def", 6000000, LocalDate.of(2001, 5, 15));
        customers[2] = new Customer("IBM", 13, "efg", 70000, LocalDate.of(2003, 5, 15));
        customers[3] = new Customer("IHS", 14, "fgh", 20000, LocalDate.of(1999, 5, 15));


        Customer_checkage cust_18 = customer ->
                customer.calculateAge(customer.getDateOfBirth()) > 18;
        Customer_checkage cust_25 = customer ->
                customer.calculateAge(customer.getDateOfBirth()) < 25;


        for (Customer customer : customers) {
            if (cust_18.customer_checkage_method(customer) && (cust_25.customer_checkage_method(customer))) {
                System.out.println("Customer with id= " + customer.getCustomerID() + " and with name = : " + customer.getCustomerName() +
                        "have income " +  customer.getMonthlyIncome() + " and afe is between 18 and 25 that is " + customer.calculateAge(customer.getDateOfBirth()));
            }
        }

    }
}
