package day9_functionalinterface;

import day3_assi.loanagreement;
import java.util.function.Predicate;
import static day3_assi.loanagreement.loanStatus.ACTIVE;
import static day3_assi.loanagreement.loanStatus.PENDING;

public class LoanAccount_check {

    public static void main(String[] args) {
        loanagreement[] arr = new loanagreement[4];
        arr[0] = new loanagreement(12, 4000000, ACTIVE);
        arr[1] = new loanagreement(12, 4000000, ACTIVE);
        arr[2] = new loanagreement(12, 4000000, ACTIVE);
        arr[3] = new loanagreement(12, 4000000, ACTIVE);

        Predicate<loanagreement> emi_pending = loanagreement -> loanagreement.calEMI() > 0;
        Predicate<loanagreement> loan_status = loanagreement -> loanagreement.getStatus() == ACTIVE;
        System.out.println((emi_pending.and(loan_status).test(arr[0])));
    }

}
