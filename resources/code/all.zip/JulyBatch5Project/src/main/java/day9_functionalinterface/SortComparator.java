package day9_functionalinterface;
import day3_assi.loanagreement;
import java.util.Arrays;
import java.util.Comparator;
import static day3_assi.loanagreement.loanStatus.ACTIVE;

public class SortComparator {
    public static void main(String[] args) {
        loanagreement[] arr = new loanagreement[4];
        arr[0] = new loanagreement(12, 4000000, ACTIVE);
        arr[1] = new loanagreement(12, 400000, ACTIVE);
        arr[2] = new loanagreement(12, 5000000, ACTIVE);
        arr[3] = new loanagreement(12, 60000, ACTIVE);
        Comparator<loanagreement> loanAmountComparator = new Comparator<loanagreement>() {
            public int compare(loanagreement e1, loanagreement e2) {
                return (int) (e1.getLoanAmount() - e2.getLoanAmount());
            }
        };

        Arrays.sort(arr, loanAmountComparator);
        System.out.println("loan amount in sequence");
        for (loanagreement loan : arr) {
            System.out.println("Loan Amount " + loan.getLoanAmount());
        }





    }
}
