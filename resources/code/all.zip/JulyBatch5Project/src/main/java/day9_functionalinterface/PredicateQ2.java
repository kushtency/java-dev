package day9_functionalinterface;

import java.util.function.Predicate;

public interface PredicateQ2 {
    public static void main(String[] args) {
        Predicate<Integer> divby2 = i -> i % 2 == 0;
        Predicate<Integer> divby5 = i -> i % 5 == 0;

        System.out.println(divby5.or(divby2).test(4));
    }
}
