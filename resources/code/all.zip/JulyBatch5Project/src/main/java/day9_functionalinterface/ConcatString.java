package day9_functionalinterface;

public interface ConcatString {
    String ConcatString(String str1, String str2);

    public static void main(String[] args) {
        ConcatString concat = (x,y) -> (x+y);
        System.out.println(concat.ConcatString("abc", "def"));
    }
}