//package brd_n;
//import java.util.Date;
//public class Customer {
//    private int customerId;
//    private String customerCode;
//    private String customerName;
//    private String customerAddress1;
//    private String customerAddress2;
//    private int customerPinCode;
//    private String emailAddress;
//    private long contactNumber;
//    private String primaryContactPerson;
//    private Enums.RecordStatus status;
//    private Enums.Flag flag;
//
//    private Date createDate;
//    private String createdBy;
//    private Date modifiedDate;
//    private  String modifiedBy;
//    private Date authorizedDate;
//    private  String authorizeddBy;
//
//
////    public Customer(int customerId, String customerCode, String customerName, String customerAddress1, String customerAddress2, int customerPinCode, String emailAddress, long contactNumber, String primaryContactPerson, Enums.RecordStatus status, Enums.Flag flag, Date createDate, String createdBy, Date modifiedDate, String modifiedBy, Date authorizedDate, String authorizeddBy) {
////        this.customerId = customerId;
////        this.customerCode = customerCode;
////        this.customerName = customerName;
////        this.customerAddress1 = customerAddress1;
////        this.customerAddress2 = customerAddress2;
////        this.customerPinCode = customerPinCode;
////        this.emailAddress = emailAddress;
////        this.contactNumber = contactNumber;
////        this.primaryContactPerson = primaryContactPerson;
////        this.status = status;
////        this.flag = flag;
////        this.createDate = createDate;
////        this.createdBy = createdBy;
////        this.modifiedDate = modifiedDate;
////        this.modifiedBy = modifiedBy;
////        this.authorizedDate = authorizedDate;
////        this.authorizeddBy = authorizeddBy;
////    }
//
//
//    public Customer() {
//    }
//
//    public Customer(int customerId, String customerCode, String customerName, String customerAddress1) {
//        this.customerId = customerId;
//        this.customerCode = customerCode;
//        this.customerName = customerName;
//        this.customerAddress1 = customerAddress1;
//    }
//
//
//    public int getCustomerId() {
//        return customerId;
//    }
//
//    public void setCustomerId(int customerId) {
//        this.customerId = customerId;
//    }
//
//    public String getCustomerCode() {
//        return customerCode;
//    }
//
//    public void setCustomerCode(String customerCode) {
//        this.customerCode = customerCode;
//    }
//
//    public String getCustomerName() {
//        return customerName;
//    }
//
//    public void setCustomerName(String customerName) {
//        this.customerName = customerName;
//    }
//
//    public String getCustomerAddress1() {
//        return customerAddress1;
//    }
//
//    public void setCustomerAddress1(String customerAddress1) {
//        this.customerAddress1 = customerAddress1;
//    }
//
//    public String getCustomerAddress2() {
//        return customerAddress2;
//    }
//
//    public void setCustomerAddress2(String customerAddress2) {
//        this.customerAddress2 = customerAddress2;
//    }
//
//    public int getCustomerPinCode() {
//        return customerPinCode;
//    }
//
//    public void setCustomerPinCode(int customerPinCode) {
//        this.customerPinCode = customerPinCode;
//    }
//
//    public String getEmailAddress() {
//        return emailAddress;
//    }
//
//    public void setEmailAddress(String emailAddress) {
//        this.emailAddress = emailAddress;
//    }
//
//    public long getContactNumber() {
//        return contactNumber;
//    }
//
//    public void setContactNumber(long contactNumber) {
//        this.contactNumber = contactNumber;
//    }
//
//    public String getPrimaryContactPerson() {
//        return primaryContactPerson;
//    }
//
//    public void setPrimaryContactPerson(String primaryContactPerson) {
//        this.primaryContactPerson = primaryContactPerson;
//    }
//
//    public Enums.RecordStatus getStatus() {
//        return status;
//    }
//
//    public void setStatus(Enums.RecordStatus status) {
//        this.status = status;
//    }
//
//    public Enums.Flag getFlag() {
//        return flag;
//    }
//
//    public void setFlag(Enums.Flag flag) {
//        this.flag = flag;
//    }
//
//    public Date getCreateDate() {
//        return createDate;
//    }
//
//    public void setCreateDate(Date createDate) {
//        this.createDate = createDate;
//    }
//
//    public String getCreatedBy() {
//        return createdBy;
//    }
//
//    public void setCreatedBy(String createdBy) {
//        this.createdBy = createdBy;
//    }
//
//    public Date getModifiedDate() {
//        return modifiedDate;
//    }
//
//    public void setModifiedDate(Date modifiedDate) {
//        this.modifiedDate = modifiedDate;
//    }
//
//    public String getModifiedBy() {
//        return modifiedBy;
//    }
//
//    public void setModifiedBy(String modifiedBy) {
//        this.modifiedBy = modifiedBy;
//    }
//
//    public Date getAuthorizedDate() {
//        return authorizedDate;
//    }
//
//    public void setAuthorizedDate(Date authorizedDate) {
//        this.authorizedDate = authorizedDate;
//    }
//
//    public String getAuthorizeddBy() {
//        return authorizeddBy;
//    }
//
//    public void setAuthorizeddBy(String authorizeddBy) {
//        this.authorizeddBy = authorizeddBy;
//    }
//
//    @Override
//    public String toString() {
//        return "Customer{" +
//                "customerId=" + customerId +
//                ", customerCode='" + customerCode + '\'' +
//                ", customerName='" + customerName + '\'' +
//                ", customerAddress1='" + customerAddress1 + '\'' +
//                ", customerAddress2='" + customerAddress2 + '\'' +
//                ", customerPinCode=" + customerPinCode +
//                ", emailAddress='" + emailAddress + '\'' +
//                ", contactNumber=" + contactNumber +
//                ", primaryContactPerson='" + primaryContactPerson + '\'' +
//                ", status=" + status +
//                ", flag=" + flag +
//                ", createDate=" + createDate +
//                ", createdBy='" + createdBy + '\'' +
//                ", modifiedDate=" + modifiedDate +
//                ", modifiedBy='" + modifiedBy + '\'' +
//                ", authorizedDate=" + authorizedDate +
//                ", authorizeddBy='" + authorizeddBy + '\'' +
//                '}';
//    }
//}
