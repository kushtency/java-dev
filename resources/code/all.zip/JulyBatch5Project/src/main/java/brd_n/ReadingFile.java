package brd_n;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadingFile {

    public static List<String> read(String path){
        List<String> dataList=new ArrayList<>();

        try(FileReader fileReader=new FileReader(path);
            BufferedReader bufferedReader=new BufferedReader(fileReader);) {
            String statement=null;
            while ((statement=bufferedReader.readLine())!=null){
                dataList.add(statement);
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return dataList;
    }

}
