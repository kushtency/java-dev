package brd_n;

public class CreateDataBase {


    public static void createDirectoryTable(){

    }
    public static void createCustomerTable(){

    }
}
