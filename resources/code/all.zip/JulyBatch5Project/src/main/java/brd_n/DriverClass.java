//package brd_n;
//
//import trial.CustomerDAO;
//
//public class DriverClass {
//    public static void main(String[] args) {
//
//
//          Service.addFileLocationAndFileName("D:/Onedrive/OneDrive - nucleusonline/Desktop/TestInput.txt","TestInput.txt");
//          Service.addFileLocationAndFileName("D:/Onedrive/OneDrive - nucleusonline/Desktop/TestInput2.txt","TestInput.txt");
//          Service.readFileLocation();
////        CustomerDAO customerDAO=new CustomerDAO();
////        customerDAO.fillDataInCustomerTable("D:/Onedrive/OneDrive - nucleusonline/Desktop/TestInput.txt");
//    }
//}
