package brd_n;

public class Enums {

    public enum RecordStatus{
        N,
        M,
        D,
        A,
        R;
    }
    public enum Flag{
        A,
        I;
    }
}
