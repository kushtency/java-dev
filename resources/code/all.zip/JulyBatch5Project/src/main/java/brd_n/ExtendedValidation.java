//package brd_n;
//
//import data_Validation.Data_Validation_Class;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//public class ExtendedValidation extends Data_Validation_Class {
//    private static final Logger logger = LogManager.getLogger(ExtendedValidation.class);
//    public static boolean isValid(String data){
//        return true;
//    }
//}
