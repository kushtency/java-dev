//package brd_n;
//
//import data_Validation.Data_Validation_Class;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//
//import java.sql.Connection;
//import java.sql.Date;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.List;
//public class CustomerDAO {
//    private static final Logger logger = LogManager.getLogger(CustomerDAO.class);
//    public static Connection connection= JDBCconnection.getConnection();
//    PreparedStatement preparedStatement= null;
//    public List<Customer>  validateAndFillData(String path) {
//
//        List<Customer> customerList = new ArrayList<>();
//        List<String> data = new ArrayList<>();
//        data = ReadingFile.read(path);
//        for (String d : data) {
//        int count = 0;
//            String[] strings = d.split("~", 16);
//            Customer c = new Customer();
//
//                //setting customer code-------------------------------------------------------------------------
//            if (!strings[0].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[0].trim(), 10)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[0].trim(), "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[0].trim(), ')')) {
//                            c.setCustomerCode(strings[0].trim());
//                            count++;
//                        } else {
//                            logger.info("Customer Code contains Special Characters");
//                        }
//                    } else {
//                        logger.info("customer code Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("customer code Data length exceeds");
//            }
//            else {
//                logger.info("Customer code was mandatory to fill");
//
//            }
//
//            //setting customer Name------------------------------------------------------------------------------
//            if (!strings[1].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[1], 30)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[1], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[1], '@')) {
//                            c.setCustomerName(strings[1]);
//                            count++;
//                        } else {
//                            logger.info("Customer Name contains Special Characters");
//                        }
//                    } else {
//                        logger.info("Customer Name Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("Customer name Data length exceeds");
//            }
//            else {
//                    logger.info("Customer Name was mandatory to fill");
//
//            }
//
////                            c.setCustomerName(strings[1]);
//
//            //setting customer address1----------------------------------------------------------------------
//            if (!strings[2].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[2], 100)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[2], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[2], '@')) {
//                            c.setCustomerAddress1(strings[2]);
//                            count++;
//                        } else {
//                            logger.info("Address1 contains Special Characters");
//                        }
//                    } else {
//                        logger.info("Address1 Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("Address1 Data length exceeds");
//            }
//            else {
//                logger.info("Customer address was mandatory to fill");
//
//            }
////                c.setCustomerAddress1(strings[2]);
//
//            // setting address 2------------------------------------------------------------------------------
//
//            if (!strings[3].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[3], 100)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[3], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[3], '@')) {
//                            c.setCustomerAddress2(strings[3]);
//
//                        } else {
//                            logger.info("Address2 contains Special Characters");
//                            break;
//                        }
//                    } else {
//                        logger.info("Address2 Datatype doesnot match");
//                        break;
//                    }
//                }
//                else{
//                    logger.info("Address2 Data length exceeds");
//                    break;}
//            }
//
//
////                c.setCustomerAddress2(strings[3]);
//
//            // setting pincode--------------------------------------------------------------------
//
//            if (!strings[4].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[4], 6)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[4], "integer")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[4], '@')) {
//                            c.setCustomerPinCode(Integer.parseInt(strings[4]));
//                            count++;
//                        } else {
//                            logger.info("Pincode contains Special Characters");
//                        }
//                    } else {
//                        logger.info("Pincode Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("Pincode Data length exceeds");
//            }
//            else {
//                logger.info("pincode was mandatory to fill");
//
//            }
////                c.setCustomerPinCode(Integer.parseInt(strings[4]));
//
////          setting email address--------------------------------------------------------------------------------
//            if (!strings[5].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[5], 100)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[5], "string")) {
//                        if (Data_Validation_Class.validate_email_validation(strings[5])) {
//                            c.setEmailAddress(strings[5]);
//                            count++;
//                        } else {
//                            logger.info("email is not validated");
//                        }
//                    } else {
//                        logger.info("Email Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("Email Data length exceeds");
//            }
//            else {
//                logger.info("email was mandatory to fill");
//
//            }
//
////                c.setEmailAddress(strings[5]);
//
////                Setting contact number-------------------------------------------------------------------------
//            if (!strings[6].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[6], 20)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[6], "integer")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[6], '@')) {
//                            c.setContactNumber(Long.parseLong(strings[6]));
//
//                        } else {
//                            logger.info("Contact number contains Special Characters");
//                            break;
//                        }
//                    } else {
//                        logger.info("Contact number Datatype doesnot match");
//                        break;
//                    }
//                }
//                else{
//                    logger.info("contact number Data length exceeds");
//                    break;
//                }
//            }
//
//
//
////            c.setContactNumber(Long.parseLong(strings[6]));
//            //setting primary contact person-----------------------------------
//            if (!strings[7].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[7], 100)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[7], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[7], '@')) {
//                            c.setPrimaryContactPerson(strings[7]);
//                            count++;
//                        } else {
//                            logger.info("Contact Person contains Special Characters");
//                        }
//                    } else {
//                        logger.info("Contact Person Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("Contact Person Data length exceeds");
//            }
//            else {
//                logger.info("primary contact person was mandatory to fill");
//
//            }
//
////            c.setPrimaryContactPerson(strings[7]);
//
//            // Setting record status enum------------------------------------------------------------------
//            if (!strings[8].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[8], 1)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[8], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[8], '@')) {
//                            c.setStatus(Enums.RecordStatus.valueOf(strings[8]));
//                            count++;
//                        } else {
//                            logger.info("Record status enum contains Special Characters");
//                        }
//                    } else {
//                        logger.info("Record status enum doesnot match");
//                    }
//                }
//                else
//                    logger.info("Record status Data length exceeds");
//            }
//            else {
//                logger.info("record was mandatory to fill");
//
//            }
//
////                c.setStatus(Enums.RecordStatus.valueOf(strings[8]));
//
//            // setting flag enum--------------------------------------------------------------------------------
//
//            if (!strings[9].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[9], 10)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[9], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[9], '@')) {
//                            c.setFlag(Enums.Flag.valueOf(strings[9]));
//                            count++;
//                        } else {
//                            logger.info("Flag contains Special Characters");
//                        }
//                    } else {
//                        logger.info("flag Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("flag Data length exceeds");
//            }
//            else {
//                logger.info("flag was mandatory to fill");
//
//            }
////                c.setFlag(Enums.Flag.valueOf(strings[9]));
//
//
////                if (strings[12].isEmpty()){
////                    logger.info("hello");
////                }
//
////            logger.info(count);
////        c.setCreateDate(Date.parse(strings[9]));
//
//            //setting create date
//
//
//
//                try {
//                    if (strings[10] != null) {
//                        c.setCreateDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[10]));
//                        count++;
//                    }
//                    if (!strings[12].isEmpty()) {
//                        c.setModifiedDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[12]));
//                    }
//                    if (!strings[14].isEmpty()) {
//                        c.setAuthorizedDate(new SimpleDateFormat("dd/MMM/yyyy").parse(strings[14]));
//                    }
//                } catch (ParseException e) {
//                    throw new RuntimeException(e);
//                }
////                c.setCreatedBy(strings[11]);
////                c.setModifiedBy(strings[13]);
////                c.setAuthorizeddBy(strings[15]);
//
//                //setting created by
//            if (!strings[11].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[11], 30)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[11], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[11], '@')) {
//                            c.setCreatedBy(strings[11]);
//                            count++;
//                        } else {
//                            logger.info("created by contains Special Characters");
//                        }
//                    } else {
//                        logger.info("created by Datatype doesnot match");
//                    }
//                }
//                else
//                    logger.info("created by Data length exceeds");
//            }
//            else {
//                logger.info("created by was mandatory to fill");
//
//            }
//
//
//            // setting modified by
//            if (!strings[13].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[13], 30)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[13], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[13], '@')) {
//                            c.setModifiedBy(strings[13]);
//
//                        } else {
//                            logger.info("It contains Special Characters");
//                            break;
//                        }
//                    } else {
//                        logger.info("Datatype doesnot match");
//                        break;
//                    }
//                }
//                else{
//                    logger.info("Data length");
//                break;}
//            }
//
//
//            // setting authorized by
//            if (!strings[15].isEmpty()) {
//                if (Data_Validation_Class.data_length_validation(strings[15], 30)) {
//                    if (Data_Validation_Class.data_Type_Validation(strings[15], "string")) {
//                        if (Data_Validation_Class.special_Characters_validation(strings[15], '@')) {
//                            c.setModifiedBy(strings[15]);
//
//                        } else {
//                            logger.info("It contains Special Characters");
//                            break;
//                        }
//                    } else {
//                        logger.info("Datatype doesnot match");
//                        break;
//                    }
//                }
//                else{
//                    logger.info("Data length");
//                    break;
//                }
//            }
//
//
//
//            if(count==10){
//                customerList.add(c);}
//
//            }
//
//            for (int i = 0; i < customerList.size(); i++) {
//                logger.info(customerList.get(i));
//            }
////        logger.info(customerList.get(0));
//
//
//            return customerList;
//        }
//        public void fillDataInCustomerTable (String path) {
//            CustomerDAO customerDAO = new CustomerDAO();
//            List<Customer> customerList = customerDAO.validateAndFillData(path);
//            int counter=0;
//            for (Customer c: customerList) {
//                java.util.Date utilDate = new java.util.Date();
//                Date sqlDate = new Date(utilDate.getTime());
//                try {
//                    preparedStatement = connection.prepareStatement("insert into customer_brd2_17166 values (sequence_customerId.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
//                    preparedStatement.setString(1, c.getCustomerCode());
//                    preparedStatement.setString(2, c.getCustomerName());
//                    preparedStatement.setString(3, c.getCustomerAddress1());
//                    preparedStatement.setString(4, c.getCustomerAddress2());
//                    preparedStatement.setInt(5, c.getCustomerPinCode());
//                    preparedStatement.setString(6, c.getEmailAddress());
//                    preparedStatement.setLong(7, c.getContactNumber());
//                    preparedStatement.setString(8, c.getPrimaryContactPerson());
//
//                    preparedStatement.setString(9, String.valueOf(c.getStatus()));
//                    preparedStatement.setString(10, String.valueOf(c.getFlag()));
//                    if (c.getCreateDate() != null) {
//                        preparedStatement.setDate(11, (new Date(c.getCreateDate().getTime())));
//                    } else {
//                        preparedStatement.setDate(11, null);
//                    }
//                    preparedStatement.setString(12, c.getCreatedBy());
//                    if (c.getModifiedDate() != null) {
//                        preparedStatement.setDate(13, (new Date(c.getModifiedDate().getTime())));
//                    } else {
//                        preparedStatement.setDate(13, null);
//                    }
//                    preparedStatement.setString(14, c.getModifiedBy());
//                    if (c.getAuthorizedDate() != null) {
//                        preparedStatement.setDate(15, new Date(c.getAuthorizedDate().getTime()));
//                    } else {
//                        preparedStatement.setDate(15, null);
//                    }
//                    preparedStatement.setString(16, c.getAuthorizeddBy());
//                    preparedStatement.execute();
//
//                } catch (SQLException e) {
//                    logger.info("Primary Key should be one");
//                    continue;
//                }finally {
//                    try {
//                        preparedStatement.close();
//                    } catch (SQLException e) {
//                        throw new RuntimeException(e);
//                    }
//                }
//
//            }
//        }
//    }
//
