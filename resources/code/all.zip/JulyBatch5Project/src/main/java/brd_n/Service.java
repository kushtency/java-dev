//package brd_n;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.sql.*;
//import java.util.Properties;
//public class Service {
//    public static Connection connection= JDBCconnection.getConnection();
//    public static synchronized void addFileLocationAndFileName(String path,String filename){
//        PreparedStatement preparedStatement= null;
//        try {
//            preparedStatement = connection.prepareStatement("insert into file_location_17166 values(?,?,?)");
//            preparedStatement.setString(1,path);
//            preparedStatement.setString(2,filename);
//            int lastIndexOfdot=filename.lastIndexOf('.');
//            String ext=filename.substring(lastIndexOfdot+1,filename.length());
//            if(ext.equals("txt")){
//            preparedStatement.setString(3,null);}
//            else
//                preparedStatement.setString(3,"F");
//            preparedStatement.execute();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//        finally {
//            try {
//                preparedStatement.close();
//            } catch (SQLException e) {
//                throw new RuntimeException(e);
//            }
//
//        }
//    }
//
//
//    public static void readFileLocation(){
//        CustomerDAO customerDAO=new CustomerDAO();
//        Statement statement= null;
//        try (FileInputStream fileInputStream=new FileInputStream("src/main/resources/database-config.properties");
//        ){
//            Properties properties=new Properties();
//            properties.load(fileInputStream);
//            statement = connection.createStatement();
//            ResultSet resultSet=statement.executeQuery("select * from "+properties.getProperty("filetable"));
//            while (resultSet.next()){
//
//                if(resultSet.getString(3)==null){
//                    customerDAO.fillDataInCustomerTable(resultSet.getString(1));
//                }
//            }
////                customerDAO.fillDataInCustomerTable("D:/Onedrive/OneDrive - nucleusonline/Desktop/TestInput.txt");
////                customerDAO.fillDataInCustomerTable("D:/Onedrive/OneDrive - nucleusonline/Desktop/TextInput2.txt");
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//
//    }
//}
