package day7_exceptions;

public class LoanNotApprovedException extends Throwable {
    public LoanNotApprovedException(String s) {
            super(s);

    }
}
