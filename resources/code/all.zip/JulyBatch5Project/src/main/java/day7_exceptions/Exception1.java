package day7_exceptions;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.zip.CheckedInputStream;

public class Exception1 {
//    public void method1() throws ArrayIndexOutOfBoundsException {
//        int[] arrint = new int[3];
//        Arrays.fill(arrint, 1);
//        System.out.println(arrint[3]);
//}

    //c
//    public void  no_handled()  {
//            throw new NullPointerException("exception here");
//    }

//    public void same_handled()  {
//        try {
//            throw new ArithmeticException("Arithmetic exception here");
//        }
//        catch (Exception e){
//            System.out.println("Handled exception in same " + e);
//        }
//    }


//    public void throwException() throws ArrayIndexOutOfBoundsException  {
//            throw new ArrayIndexOutOfBoundsException("exception here");
//    }
//        public  void othermethod_checked(int[] arr, int i){
//            if (i > arr.length) {
//                try {
//                    throwException();
//                } catch (Exception e) {
//                    System.out.println("Array Index is Out Of Bounds" + e);
//                }
//            }
//            else {
//                System.out.println(arr[i]);
//            }
//        }

    public void bar() throws FileNotFoundException{
        throw new FileNotFoundException("demo.txt");
    }
    public void foo() {
        try {
            bar();
        }
        catch (FileNotFoundException e){
            System.out.println("File not found exception");
        }
    }


    public static void main(String[] args)  {
        Exception1 e1 = new Exception1();


//        int[] arrint = new int[3];
//        Arrays.fill(arrint, 1);
//        e1.othermethod_checked(arrint, 4);

//         e1.no_handled(); //atruntime


        e1.foo();
    }

}