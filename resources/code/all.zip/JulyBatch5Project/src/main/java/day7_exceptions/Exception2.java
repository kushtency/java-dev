package day7_exceptions;
public class Exception2 {
        private double maxEligibleAmount = 100000; //assume
        private double maxEligibleDBR = 40;
        private double maxEligibleEMI = 5000; //assume
        private boolean checkGeneralConditions(double loan_amount, double dbr, double emi) {
            return (loan_amount <= maxEligibleAmount && dbr <= maxEligibleDBR && emi <= maxEligibleEMI);
        }
        public void checkLoanEligibility(String loanType, double loan_amount, double dbr, double emi, double ltv, int age,
                                         int max_tenure, double ug_course_fees, double pg_course_fees)
                throws LoanNotApprovedException
                {
            boolean eligibilityCriteriaMet = false;
            if ("Home Loan".equals(loanType)) {
                eligibilityCriteriaMet = checkGeneralConditions(loan_amount, dbr, emi)
                        && ltv <= 90
                        && age <= 60;
            } else if ("Consumer Vehicle Loan".equals(loanType)) {
                eligibilityCriteriaMet = checkGeneralConditions(loan_amount, dbr, emi)
                        && ltv <= 80
                        && max_tenure <= 7;
            } else if ("Education Loan".equals(loanType)) {
                eligibilityCriteriaMet = checkGeneralConditions(loan_amount, dbr, emi)
                        && age > 18
                        && (ug_course_fees <= 1000000 ||
                        pg_course_fees <= 2000000);
            } else {
                System.out.println("not a loan type");;
            }

            if (!eligibilityCriteriaMet) {
                throw new LoanNotApprovedException("Loan_criteria not met");
            } else {
                System.out.println("Loan approved :)");
            }}
        public static void main(String[] args) {
            Exception2 example = new Exception2();

            try {
                String loanType = "Home Loan";
//                double amount = 80000;
//                double dbr = 0.35;
//                double emi = 4000;
                example.checkLoanEligibility("Home Loan", 8000, 30, 3000, 60, 70,
                        6, 100000, 0 );
            } catch (LoanNotApprovedException e) {
                System.out.println("Loan not approved:(...." + e);
            }
        }
    }

