package day12;
import java.util.HashSet;
import java.util.Iterator;
public class EmployeeHashset {
    public static void main(String[] args) {
        HashSet<Employee> employeeSet = new HashSet<Employee>();
        employeeSet.add(new Employee(1, "A", 45000));
        employeeSet.add(new Employee(7, "B", 35000));
        employeeSet.add(new Employee(1, "A", 45000));
        employeeSet.add(new Employee(5, "D", 55000));
        employeeSet.add(new Employee(2, "P", 75000));
        System.out.println(employeeSet.size());

        Iterator<Employee> itr = employeeSet.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }
    }
}