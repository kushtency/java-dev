package day12;
import java.util.HashSet;
public class HashsetEx {

    public static void main(String[] args) {
        HashSet<String> hset = new HashSet<String>();
        hset.add("Pear");
        hset.add("Banana");
        hset.add("Tangerine");
        hset.add("Strawberry");
        hset.add("Blackberry");

        for (String elem:hset) {
            System.out.println(elem);
        }

//        System.out.println(hset.size());

//        hset.remove("Strawberry");
//        hset.remove("Blackberry");

        hset.clear();

        System.out.println("after removing all...");
        for (String elem:hset) {
            System.out.println(elem);
        }

        System.out.println(hset.isEmpty());
    }
}
