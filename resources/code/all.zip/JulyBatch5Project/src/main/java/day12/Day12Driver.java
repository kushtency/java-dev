package day12;
import java.util.*;

public class Day12Driver {
    public static void main(String[] args) {
        ArrayList<Employee> employeelist = new ArrayList<>();
        employeelist.add(new Employee(4, "Alex", 12000));
        employeelist.add(new Employee(2, "Sansa", 1200));
        employeelist.add(new Employee(3, "Robb", 13000));
        for(Employee elem: employeelist){
            System.out.println(elem);
        }
//        employeelist.remove(2); //robb
//        System.out.println("After removing");
//        for(int i = 0; i < employeelist.size(); i++){
//            System.out.println(employeelist.get(i));
//        }

//        Iterator<Employee> itr = employeelist.iterator();
//           while (itr.hasNext()){
//               System.out.println(itr.next());
//        }

        //backward print
//        ListIterator<Employee> listIterator = employeelist.listIterator(employeelist.size());
//        while (listIterator.hasPrevious()) {
//            System.out.println(listIterator.previous());
//        }

        //remove with less salary
//        System.out.println("Employee with salary less than 10000 will be removed");
//        Iterator<Employee> salaryIterator = employeelist.iterator();
//        while (salaryIterator.hasNext()) {
//            if (salaryIterator.next().getSalary() < 10000) {
//                salaryIterator.remove();
//            }
//        }
//                Iterator<Employee> itr = employeelist.iterator();
//            while (itr.hasNext()){
//               System.out.println(itr.next());
//        }

//        Collections.sort(employeelist);
//        System.out.println("After sorting");
//        Iterator<Employee> itr = employeelist.iterator();
//            while (itr.hasNext()){
//               System.out.println(itr.next());
//        }


//        //4-a--by anonymous class
         Comparator<Employee> comp = new Comparator<Employee>() {
            @Override
            public int compare(Employee emp1, Employee emp2) {
                return Double.compare(emp1.getSalary(), emp2.getSalary());
            }
        };
        Collections.sort(employeelist,comp);
        System.out.println("After sorting");
        Iterator<Employee> itr = employeelist.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }

        Comparator<Employee> comp2 = (emp1, emp2) ->  Double.compare(emp1.getSalary(), emp2.getSalary());
        System.out.println("after labmda");
        Collections.sort(employeelist, comp);
        Iterator<Employee> itr2 = employeelist.iterator();
        while (itr2.hasNext()){
            System.out.println(itr2.next());
        }

    }
}
