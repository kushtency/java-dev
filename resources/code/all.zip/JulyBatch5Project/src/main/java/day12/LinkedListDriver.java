package day12;

import java.util.*;

public class LinkedListDriver {
    public static void main(String[] args) {

        List<Employee> employeell = new LinkedList<>();

        employeell.add(new Employee(4, "Alex", 167000));
        employeell.add(new Employee(2, "Sansa", 1200));
        employeell.add(new Employee(3, "Robb", 13000));

        Comparator<Employee> comp = new Comparator<Employee>() {
            @Override
            public int compare(Employee emp1, Employee emp2) {
                return Double.compare(emp1.getSalary(), emp2.getSalary());
            }
        };
        Collections.sort(employeell,comp);
        System.out.println("After anonymous class sorting");
        Iterator<Employee> itr = employeell.iterator();
        while (itr.hasNext()){
            System.out.println(itr.next());
        }

        Comparator<Employee> comp2 = (emp1, emp2) ->  Double.compare(emp1.getSalary(), emp2.getSalary());
        System.out.println("after lambda sorting");
        Collections.sort(employeell, comp);
        Iterator<Employee> itr2 = employeell.iterator();
        while (itr2.hasNext()){
            System.out.println(itr2.next());
        }


    }

}
