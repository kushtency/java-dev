package batch5.day2;
import java.lang.Math;
import org.example.Main;

import javax.xml.parsers.SAXParser;
import java.util.Arrays;
import java.util.Scanner;
public class fundamental {
    public static void main(String[] args) {
//        installment_amt(10000, 20, 5, 12);
//        elig_loan_amt(1000 , 1000, 0.01f, 36);
        p_i_component(100000, 5, 2, 12);

//    ltv_cal(80000, 4000);
//        Scanner sc = new Scanner(System.in);
//        int a = sc.nextInt();
//        int sum = 0;
//        if (a<10) {
//            do{
//                sum = sum + a;
//                a--;
//            }while (a >= 1);
//            while (a >= 1){
//                sum = sum + a;
//                a--;
//            }
//            System.out.println(sum);
//        }
//        else{
//            System.out.println("Enter smaller number");
//        }
//        int[] studentmarks = {1,2,3,4,5};
//        int [] arr=new int[];
//        for(int i = 0; i<5;i++){
//            System.out.println(i);
//        }


//        checkPassFail(70);
//        PrintDayInWord(8);
//        IncomeTaxCalculator(41234);
//        oddevenprime(7);

//        pascal_tri(4);
//        dbr_cal(10000,20000);
    }

//    public static void checkPassFail(int marks) {
//        if (marks >= 50) {
//            System.out.println("Pass");
//        } else
//            System.out.println("Fail");
//        System.out.println("done");
//    }

    public static String checkPassFail(int marks) {
        if (marks >= 50) {
            return "Pass";
        } else
            return "Fail";
    }
    //2
    public static String PrintDayInWord(int day) {
//        if (day == 1){
//            System.out.println("Monday");
//        }
//        else if (day ==2) {
//            System.out.println("Tuesday");
//        }
//        else if (day ==3) {
//            System.out.println("Wednesdayday");
//        }
//        else if (day ==4) {
//            System.out.println("Thursday");
//        }
//        else if (day ==5) {
//            System.out.println("Friday");
//        }
//        else if (day ==6) {
//            System.out.println("Saturday");
//        }
//        else if (day ==7) {
//            System.out.println("Sunday");
//        }
//        else {
//                System.out.println("Not a valid day");
//            }
//    }
        switch (day) {
            case 1:
                return ("Monday");
            case 2:
                return ("Tuesday");
            case 3:
                return("Wednesday");
            case 4:
                return("Thursday");
            case 5:
                return("Friday");
            case 6:
                return("Saturday");
            case 7:
                return("Sunday");

            default:
                return("Not a valid day");
        }
    }

//static method ko call krne ke object banne ki need ni
//byte 1 byte
//short 2 byte
//int 4 byte
//        long 8 byte
//int a, b, c should be avoided
// int memory // in mb
//float, double, char, boolean


//int intvar = 10;
//long longvar = intvar;
//
//ascii
//int var = ;
//char ch = (char) var;

//float floatvar = 1.2F;


//int x = 25;
//conversio from int to byte;
//byte bytevar = (byte)x;
//cyle of int...0-12
// byte b2


    //3;
    public static String IncomeTaxCalculator(long salary) {
        int count = 0;
        float rate = 0;
        double result = 0;
        while (count < 4 && salary >= 20000) {
            result += (20000 * (rate / 100));
            rate += 10;
            salary -= 20000;
            ++count;
        }
        result += salary * (rate / 100);
//        System.out.println("The income tax payable is: " + String.format("%.2f", result));
        return String.format("%.2f", result);
    }


//4
    public static String oddevenprime(int num) {
        if (num % 2 == 0) {
//            System.out.println(num + " is EVEN");
            return "EVEN";
        } else {
            boolean end = false;
            for (int i = 2; i <= num / 2; i++) {
                if (num % i == 0) {
                    end = true;
                    break;
                }
            }
            if (end == false) {
//                    System.out.println(num + " is Odd prime");
                return "Odd Prime";
            } else
//                    System.out.println(num + " is ODD non PRIME");
                return "ODD non PRIME";
        }
    }


    public static int factorial(int numm) {
        if (numm == 0) {
            return 1;
        }
        return numm * factorial(numm - 1);
    }

    //5
    public static boolean pascal_tri(int n) {
        if (n ==0){
            return false;
        }
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n - i; j++) {

                System.out.print("  ");
            }
            for (int j = 0; j <= i; j++) {

                System.out.print("   " + factorial(i) / (factorial(i - j) * factorial(j)));
            }
            System.out.println();
        }
        return true;
    }




    public static long ltv_cal(long loan_amt, long prop_val) {
        long ltv = (loan_amt / prop_val);
        if (ltv <= 80) {
//            System.out.println("LTV is " + ltv);
            return ltv;
        } else {
            System.out.println("LTV can be maximum 80%");
            return 0;
        }
    }


    public static String dbr_cal(int expenses, int monthly_income) {
        int dbr = (expenses / monthly_income) * 100;
        if (dbr <= 20) {
            return "approved";
//            System.out.println("at expenses " + expenses + " and monthly income " + monthly_income + " Loan application is approved");
        } else {
            if (dbr > 20 && dbr <= 40) {
                return "under consideration";
//                System.out.println("at expenses " + expenses + " and monthly income " + monthly_income + " under consideration");
            } else
                return "rejected";
//                System.out.println("at expenses " + expenses + " and monthly income " + monthly_income + " Loan application is rejected");
        }
    }

    //8
    public static double elig_loan_amt(int monthly_sal,int expenses, float monthly_rate, int tenure) {
        if (tenure > 7){
            System.out.println("Tenure can not be more than 7 years.");
        }
        int dbr = (monthly_sal/expenses)*100;
        double emi = 0.5*(monthly_sal- 0.2*(dbr));
        double max_loan = (emi * ((Math.pow(1 + monthly_rate, tenure)) - 1)) /
                (monthly_rate * (Math.pow(1 + monthly_rate, tenure)));
//        System.out.println("Maximum loan amount is " + max_loan);
        return max_loan;
    }
//    E * (( 1 + R) ^t) -1 )/ (R * (( 1 + R) ^t)

    //9
    public static double installment_amt(int princ, int intrst, int t_count, int no_of_ins) {
        int rv = 0;
        double x;
        double numer = princ * (intrst / t_count) - ((rv * (intrst / t_count)) / Math.pow(1 + (intrst / t_count), no_of_ins));
        double den = (1 - (1 / (1 + (intrst / t_count))));
        x = numer / den;
//        System.out.println("Installemnt amount is " + x);
        return x;
    }

    //    10
    public static void p_i_component(double princ, double intrst,
                                     double t_count, int  no_of_ins) {
        int i = 0;
        double opn = princ;
        double intrst_comp;
        double princ_comp;
        double ins_amt;
        double princ_end;
        double[] In = new double[no_of_ins];
        double[] Pn = new double[no_of_ins];
        double[] OPN_1 = new double[no_of_ins];
        int rv = 0;
        while (i < no_of_ins) {
            intrst_comp = ((princ*i) / ((intrst / 100) * 0.083));
            //System.out.println(intrst_comp);
            In[i]  = intrst_comp;
            double numer = (princ * (intrst / t_count) - ((rv * (intrst / t_count)) / Math.pow(1 + (intrst / t_count), no_of_ins)));
            double den =( (1 - (1 / (1 + (intrst / t_count)))));
            ins_amt = numer / den;
            princ_comp = ins_amt - intrst_comp;
            Pn[i] = princ_comp;
            princ_end  = princ - princ_comp;
            OPN_1[i] = princ_end;
            i=i+1;
        }

        for(int j=0;j<no_of_ins;j++) {
            Scanner sc = new Scanner(System.in);
            int intallm = sc.nextInt();
            System.out.print(In[intallm]+" "+Pn[intallm]+" "+OPN_1[intallm]);
            System.out.println();
        }


    }


}

