//package brd;
//import org.apache.logging.log4j.LogManager;
//import validate.DataValidation;
//import org.apache.logging.log4j.Logger;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import java.util.regex.Pattern;
//public class Validation {
//        public static Logger logger = LogManager.getLogger("FileLogger");
////File extension validation
//        public static boolean isValidFile(String file){
//            if(file.endsWith(".txt"))
//
//                return true;
//
//            return false;
//
//        }
//
////Customer data Validation
//
//        public static boolean validateData(String [] data) {
//
//            String customerCode = data[0];
//
//            String customerName = data[1];
//
//            String address1 = data[2];
//
//            String Address2 = data[3];
//
//            int pincode = Integer.parseInt(data[4]);
//
//            String email = data[5];
//
//            String contactno = data[6];
//
//            String primaryContactPerson = data[7];
//
//            char recordStatus = data[8].charAt(0);
//
//            char activeInactiveFlag = data[9].charAt(0);
//
//            Date createDate = null;
//
//            if (!data[10].equals("")) {
//
//                SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy"); // 14/AUG/2023
//
//                try {
//
//                    createDate = sdf.parse(data[10]);
//
//                } catch (ParseException e) {
//
//                    throw new RuntimeException(e);
//
//                }
//
//            }
//
//
//            String createdBy = data[11];
//
//
//            Date modifiedDate = null;
//
//            if (!data[12].equals("")) {
//
//                SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
//
//                try {
//
//                    modifiedDate = sdf.parse(data[12]);
//
//                } catch (ParseException e) {
//
//                    throw new RuntimeException(e);
//
//                }
//
//            }
//
//
//            String modifiedBy = data[13];
//
//
//            Date authorizedDate = null;
//
//            if (!data[14].equals("")) {
//
//                SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
//
//                try {
//
//                    authorizedDate = sdf.parse(data[14]);
//
//                } catch (ParseException e) {
//
//                    throw new RuntimeException(e);
//
//                }
//
//            }
//
//
//            String authorizedBy = data[15];
//
//
//            if (!validateCustomerCode(customerCode)){
//                logger.info("Invalid customer code.");
//
//                return false;
//
//            }
//
//            if (!validateCustomerName(customerName)){
//                logger.info("Customer name can only contain a-z, A-Z, and 0-9 and length less than 30.");
//
//                return false;
//
//            }
//
//            if (!validateCustomerAddress(customerAddress1)){
//                logger.info("Enter valid customerAddress.");
//
//                return false;
//
//            }
//
//            if (!validateCustomerAddress(customerAddress2)){
//                logger.info("Enter valid customerAddress.");
//
//                return false;
//
//            }
//
//            if (!validateCustomerPinCode(customerPinCode)){
//                logger.info("Pin code should be exactly 6 characters long.");
//
//                return false;
//
//            }
//
//            if (!validateEmailAddress(emailAddress)){
//                logger.info("Invalid email address format.");
//
//                return false;
//
//            }
//
//            if (!validateContactNumber(contactNumber)){
//                logger.info("Invalid contact number.");
//
//                return false;
//
//            }
//
//            if (!validatePrimaryContactPerson(primaryContactPerson)){
//                logger.info("Invalid primaryContactPerson.");
//
//                return false;
//
//            }
//
//            if (!validateRecordStatus(recordStatus)){
//                logger.info("Invalid record status.");
//
//                return false;
//
//            }
//
//            if (!validateActiveInactiveFlag(activeInactiveFlag)){
//                logger.info("Invalid active/inactive flag.");
//
//                return false;
//
//            }
//
//
//            return true;
//
//        }
//
//        public static boolean validateCustomerCode(String customerCode){
//
//            return(DataValidation.dataTypeValidation(customerCode, String.class) && DataValidation.dataLength(customerCode, 10));
//
//        }
//
//        public static boolean validateCustomerName(String customerName){
//
//            return(DataValidation.dataTypeValidation(customerName, String.class) && DataValidation.dataLength(customerName, 30)
//
//                    && Pattern.matches("^[a-zA-Z0-9\\s]+$", customerName));
//
//        }
//
//
//        public static boolean validateCustomerAddress(String customerAddress){
//
//            return(DataValidation.dataTypeValidation(customerAddress, String.class) && DataValidation.dataLength(customerAddress, 100));
//
//        }
//
//
//        public static boolean validateCustomerPinCode(int customerPinCode) {
//
//            String pinCodeString = String.valueOf(customerPinCode);
//
//            return (DataValidation.dataTypeValidation(customerPinCode, String.class) && DataValidation.dataLength(customerPinCode, 6));
//
//        }
//
//
//        public static boolean validateEmailAddress(String emailAddress) {
//
//            return (DataValidation.dataTypeValidation(emailAddress, String.class) && DataValidation.dataLength(emailAddress, 100))
//
//                    && Pattern.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", (String) emailAddress);
//
//        }
//
//        public static boolean validateContactNumber(String contactNumber) {
//
//            return (DataValidation.dataTypeValidation(contactNumber, String.class) && DataValidation.dataLength(contactNumber, 20));
//
//        }
//
//
//        public static boolean validatePrimaryContactPerson(String primaryContactPerson) {
//
//            return (DataValidation.dataTypeValidation(primaryContactPerson, String.class) && DataValidation.dataLength(primaryContactPerson, 100));
//
//        }
//
//
//        public static boolean validateRecordStatus(char recordStatus) {
//
//            if (recordStatus == 'N' || recordStatus == 'M' || recordStatus == 'D' ||
//
//                    recordStatus == 'A' || recordStatus == 'R') {
//
//                return true;
//
//            } else {
//
//                return false;
//
//            }
//
//        }
//
//
//        public static boolean validateActiveInactiveFlag(char activeInactiveFlag) {
//
//            if (activeInactiveFlag == 'A' || activeInactiveFlag == 'I') {
//
//                return true;
//
//            } else {
//
//                return false;
//
//            }
//
//        }
//
//
//    }
//}
