package day3_assi;
import java.time.LocalDate;
import java.time.Period;

public class Customer {
    // new variable addded
    final String companyName;
    public static int count = 0;
    public int customerID ;
    public static int IDGenerate = 1;
    public String customerName;

    public LocalDate dateOfBirth;
    private String contactNumber;
    private String email;
    private double monthlyIncome;
    private String profession;
    private double totalMonthlyExpenses;
    private double maxEligibleLoanAmount;
    public int age;
//    private String companyName ;
    public int calculateAge(LocalDate dateOfBirth) {
        LocalDate currentDate = LocalDate.now();
        if ((dateOfBirth != null) && (currentDate != null)) {
            age =  Period.between(dateOfBirth, currentDate).getYears();
            return Period.between(dateOfBirth, currentDate).getYears();
        }
        return Period.between(dateOfBirth, currentDate).getYears();

    }
    public double calDBR(){
        double dbr = (totalMonthlyExpenses/monthlyIncome);
        return dbr;
    }
    public double calMaxEligibleEMI(){
        double dbr = calDBR();
        double emi = 0.5 * (monthlyIncome - (0.2 * dbr));
        return emi;
    }

    public void calEligibleLoanAmount(double monthly_rate, double tenure){
        double emi = calMaxEligibleEMI();
        double max_loan = (emi * ((Math.pow(1 + monthly_rate, tenure)) - 1)) /
                (monthly_rate * (Math.pow(1 + monthly_rate, tenure)));
        System.out.println("Maximum loan amount is " + max_loan);
    }

    public Customer(String companyName, int customerID, String customerName){
        this(companyName);
        this.customerID  = customerID;
        this.customerName = customerName;
    }
    public Customer(String companyName, int customerID, String customerName, double monthlyIncome,LocalDate dateOfBirth){
        this(companyName);
        this.customerID  = customerID;
        this.customerName = customerName;
        this.monthlyIncome = monthlyIncome;
//        this.dateOfBirth = LocalDate.parse(dateOfBirth);
        this.dateOfBirth = dateOfBirth;
    }


    public Customer(String companyName){
        this.companyName = companyName;
        count++;
        this.customerID = IDGenerate++;
    }



    public static int display(){
        return count;
    }

    @Override
    public String toString() {
        return "Customer{" +
                "companyName='" + getCompanyName()+ '\'' +
                ", customerID=" + getCustomerID() +
                ", customerName='" + getCustomerName() + '\'' +
                "salary" + '}';
    }

    public String getCompanyName() {
        return companyName;
    }

    public int getCustomerID() {
        return customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public double getMonthlyIncome() {
        return monthlyIncome;
    }

    public void setMonthlyIncome(double monthlyIncome) {
        this.monthlyIncome = monthlyIncome;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }


//    public Customer(int customerID){
//            this.customerID = IDGenerate++;
//    }


}
