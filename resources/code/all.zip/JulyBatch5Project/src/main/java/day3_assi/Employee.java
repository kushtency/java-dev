package day3_assi;
public class Employee {
    private int ID ;
    private static Employee emp;
    private static  int inst_count = 1;
    private String FirstName;
    private String LastName;
    private int Salary;

//    private Employee(){
//        inst_count++;
//    }
private Employee(int ID, String FirstName, String LastName, int Salary) {
    this.ID = ID;
    this.FirstName = FirstName;
    this.LastName = LastName;
    this.Salary = Salary;
    inst_count++;

}

    public static Employee getInstance(int ID, String FirstName, String LastName, int Salary){
        if (inst_count > 1){
            return emp;
        }
//        System.out.println("ins_count " + inst_count);
        emp = new Employee(ID, FirstName, LastName,  Salary);
        return  emp;
    }


    public int getID() {
        return ID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }
    public int getSalary() {
        return Salary;
    }
    public int getAnnualSalary (){
        return (Salary * 12);
    }

    public int raiseSalary (int prcnt){
        return Salary=  (Salary + (Salary * prcnt)/100);
    }
    public String  getName (){
        return (FirstName + LastName);
    }

    public String toString(){
        return ("Employee [id = " + ID + " name = " + FirstName + LastName + " salary = " + Salary);
    }

    public void setSalary(int salary) {
        Salary = salary;
    }
}
