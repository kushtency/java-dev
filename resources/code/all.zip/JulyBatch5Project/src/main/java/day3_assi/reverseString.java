package day3_assi;
import java.util.Scanner;
public class reverseString {
       // buffer---
        public String reverseBuffer(String s) {
            StringBuffer buffrstring = new StringBuffer(s);
            return buffrstring.reverse().toString();
        }
        // builder------
        public String reverseBuilder(String s) {
            StringBuilder builString = new StringBuilder();
            for (int i = s.length() - 1; i >= 0; i--) {
                builString.append(s.charAt(i));
            }
            return builString.toString();
        }
        // recursion
        public static String reversebyRecursion(String s) {
            if (s.length() <= 1) {
                return s;
            }
            return reversebyRecursion(s.substring(1)) + s.charAt(0);
        }


    }

