package day3_assi;

public class s_s1_s2 {
    String s;
    String s1;
    String s2;

    public String replace(String s,String s1, String s2){
        String ans= s.replace(s1,s2);
        return ans;
    }

}
