package day3_assi;

public class LoanProduct {

}
