package day3_assi;

public class Student {
    private String studentID;
    private String StudentName;

    private int creditPoints;
//    a---
    public Student(String studentID, String StudentName){
        if (studentID.length() < 3){
            System.out.println("Invalid length");
        }
        else
            this.studentID = studentID;

        if(StudentName.length() < 4) {
            System.out.println("Invalid length");
        }
        else
            this.StudentName = StudentName;
    }
//  b---
    public void getLoginName(){
        System.out.println(StudentName.substring(0,4) + studentID.substring(0,3));
    }
//    --c--
    public String changeStudentName(String newName){
        this.StudentName = newName;
        return StudentName;
    }

//    --d--
    public String getStudentID(){
        return studentID;
    }
    public String getStudentName(){
        return StudentName;
    }

//    --e--
    public void addCredits(int toadd){
        creditPoints = creditPoints + toadd;
    }

//    --f--
    public int getCreditPoints(){
        return creditPoints;
    }




}
