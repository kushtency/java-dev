package day3_assi;

import java.util.Scanner;


public class Testing {
        public static void main(String[] args) {
//            // Test constructor and toString()
//            Employee e1 = new Employee(8, "Amit", "Jain", 2500);
//            System.out.println(e1); // toString();
//            // Test Setters and Getters
//            e1.setSalary(999);
//            System.out.println(e1); // toString();
//            System.out.println("id is: " + e1.getID());
//            System.out.println("firstname is: " + e1.getFirstName());
//            System.out.println("lastname is: " + e1.getLastName());
//            System.out.println("salary is: " + e1.getSalary());
//            System.out.println("name is: " + e1.getName());
//            System.out.println("annual salary is: " + e1.getAnnualSalary()); // Test
//            // Test raiseSalary()
//            System.out.println(e1.raiseSalary(10));
//            System.out.println(e1);
//        }
//    }

    //    public static void main(String[] args) {
//        // Test constructor and toString()
//        Account a1 = new Account("A101", "Sharma", 88);
//        System.out.println(a1); // toString();
//        Account a2 = new Account(111, "Kumar"); // default balance
//        System.out.println(a2);
//        // Test Getters
//        System.out.println("ID: " + a1.getId());
//        System.out.println("Name: " + a1.getName());
//        System.out.println("Balance: " + a1.getBalance());
//        // Test credit() and debit()
//        a1.credit(100);
//        System.out.println(a1);
//        a1.debit(50);
//        System.out.println(a1);
//        a1.debit(500); // debit() error
//        System.out.println(a1);
//        // Test transfer()
//        a1.transferTo(a2, 100); // toString()
//        System.out.println(a1);
//        System.out.println(a2);
//    }


//    public static void main(String[] args) {
//        Student stud = new Student("1111", "krish");
//        System.out.println(stud.getStudentName());
//        System.out.println(stud.getStudentID());
//        stud.addCredits(100);
//        stud.addCredits(500);
//        System.out.println(stud.getCreditPoints());
//
//        Student stud1 = new Student("1122", "krishna");
//        System.out.println(stud1.getStudentName());
//        System.out.println(stud1.getStudentID());
//        stud1.addCredits(100);
//        stud1.addCredits(500);
//        System.out.println(stud1.getCreditPoints());
//
//        Student stud2 = new Student("1133", "krishey");
//        System.out.println(stud2.getStudentName());
//        System.out.println(stud2.getStudentID());
//        stud2.addCredits(100);
//        stud2.addCredits(100);
//        System.out.println(stud2.getCreditPoints());
//
//        Student stud3 = new Student("1144", "krishi");
//        System.out.println(stud3.getStudentName());
//        System.out.println(stud3.getStudentID());
//        stud3.addCredits(100);
//        stud3.addCredits(50);
//        System.out.println(stud3.getCreditPoints());

        Customer c1 = new Customer("nucleus" , 11, "abc");
        Customer c2= new Customer("tcs", 12, "def");
                System.out.println(c1.companyName); // the name assigned to c1


//                c1.companyName = "TCS";    // this is giving compilation error because company name is delared final and we are
//                trying to modify it














//        c2.customerName = "Amit";
//        Customer c3= new Customer();
//        System.out.println((Customer.display()));
//        System.out.println("Customer id of c3 is " + c3.customerID);

           //9---



//        loanagreement l1 = new loanagreement();
//        loanagreement l2 = new loanagreement();
//        loanagreement l3 = new loanagreement();
//        System.out.println("loan agreement id of l1 is " + l1.getLoanAgreementId());
//        System.out.println("loan agreement id of l2 is " + l2.getLoanAgreementId());
//        System.out.println("loan agreement id of l3 is " + l3.getLoanAgreementId());


//        Employee emp = Employee.getInstance(11,"Amit", "Gag", 12000);
//        Employee emp1 = Employee.getInstance(12,"Ami", "Garg", 12000);
//        Employee emp2= Employee.getInstance(13,"Amam", "Garg", 12000);
//        Employee emp3 = Employee.getInstance(14,"Amn", "Garg", 12000);
//        System.out.println(emp3);
//        System.out.println(emp2);
//        System.out.println(emp1);

//          PrintNumber p = new PrintNumber();
//          p.print((short)20);
//          p.print((int )20);
//          p.print((long)20);
//          p.print((byte)20);
//          p.print((String) "ABC");
//          p.print((float)20.0f);



//        System.out.println(c1.calMaxEligibleEMI(int customerID, String customerName));

//               Scanner sc = new Scanner(System.in);
//                User[] users = new User[10];
//
//                for(int i= 0; i<10; i++){
//                        users[i] = new User();
//                        System.out.println("enter user" + (i+1) + " name");
//                        String n = sc.next();
//                        System.out.println("enter user" + (i+1) + " age");
//                        int a = sc.nextInt();
//                        System.out.println("enter user" + (i+1) + " add");
//                        String add = sc.next();
//                        users[i].setInfo(n,a,add);
//                }
//                for( int j=0; j<10;j++){
//                        System.out.println(users[j].toString());
//                }


//                Scanner sc = new Scanner(System.in);
//                String s = sc.next();
//                String s1 = sc.next();
//                String s2 = sc.next();
//                s_s1_s2 string  = new s_s1_s2();
//                System.out.println( string.replace(s, s1, s2));

//
//                reverseString strin  = new reverseString();
//                Scanner scanner = new Scanner(System.in);
//                System.out.print("Enter string ");
//                String s = scanner.next();
//                String rev_s = strin.reverseBuffer(s);
//                System.out.println("Reversed- Stringbuffer: " + rev_s);
//                String rev_s1 = strin.reverseBuilder(s);
//                System.out.println("Reversed- Stringbuilder " + rev_s);
//                String rev_s2 = strin.reversebyRecursion(s);
//                System.out.println("Reversed- recursion " + rev_s2);
//
  }
}
