package day3_assi;
public class User {
    String  name ;
    int age;
    String address;

    public User() {
        this.name = "unknown";
        this.age = 0;
        this.address = "not available";
    }

    public void setInfo( String  name ,int age){
        this.name = name;
        this.age= age;
}
    public void setInfo( String  name ,int age, String address){
        this.name = name;
        this.age= age;
        this.address = address;
    }
    public String toString(){
       return ("User name is " + name+ "  ,age " + age + " and address is " + address );
    }


}
