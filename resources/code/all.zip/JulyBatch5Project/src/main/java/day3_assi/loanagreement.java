package day3_assi;
import java.time.Duration;
import java.time.LocalDate;
public class loanagreement {
    private int loanAgreementId;
    public static int idGenrator = 1;
    private double loanAmount;
    private int tenure;
    private double roi;
    private double emipermonth;
    private LocalDate loanDisbursalDate;
    private loanStatus status;
    public enum loanStatus{
        PENDING,
        ACTIVE,
        APPROVED};
    public loanagreement(int loanAgreementId, double loanAmount, loanStatus Status) {
        this.loanAgreementId = loanAgreementId;
        this.loanAmount = loanAmount;
        this.status = Status;
    }
    public void setLoanAgreementId(int loanAgreementId) {
        this.loanAgreementId = loanAgreementId;
    }
    public double getLoanAmount() {
        return loanAmount;
    }
    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }
    public loanStatus getStatus() {
        return status;
    }

    private int repaymentFreq;
//    --calcul emi

    public loanagreement(){

    }

    public int getLoanAgreementId() {
        this.loanAgreementId = idGenrator++;
        return loanAgreementId;
    }

    public double calEMI(){
        roi = (roi/100)*0.083;
        tenure = tenure*12;
        emipermonth = loanAmount*roi * Math.pow((roi
        +1), tenure)/(Math.pow((roi+1), tenure) -1);
        return emipermonth;
    }
    public loanagreement(double roi, int tenure, double loanAmount, double emipermonth){
        this.roi = roi;
        this.tenure = tenure;
        this.loanAmount = loanAmount;
        this.emipermonth = emipermonth;
    }
//    generat-repaymentschedule
    public void generateRepaymentSchedule(){
        System.out.println("Agreement ID " + loanAgreementId);
        System.out.println("Loan Amount " + loanAmount);
        System.out.println("tenure " + tenure/12);
        System.out.println("ROI is " + roi*1200);
//        System.out.println("Loan status " + loanStatus.valueOf());
        System.out.println("EMI IS " + emipermonth);
        System.out.println("Loan disbrsal date is " + loanDisbursalDate);
        System.out.println("Repayment freq is " + repaymentFreq);
    }
    public double calculateLatepenalty(LocalDate currentDate, LocalDate loanDisbursalDate){
        Duration duration = Duration.between(currentDate, loanDisbursalDate);
        long diff = Math.abs(duration.toDays());
        return diff*1000;
    }
    public double calculateLoanToValueRatio(double value, double loanAmount){
        return loanAmount/value;
    }


}
