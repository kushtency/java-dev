package day3_assi;
public class Account {
    String id ;
    String name ;
    float balance ;
    int accountNumber;
    String accountType;
//    a----
    public Account(){
        this.name = "0";
        this.id = "NA";
        this.balance = 0.0f;
    }
//    --(d----c called from b)
    public Account(String id, String name, float balance, int accountNumber, String accountType){
       this(id, name, balance);
        this.accountType = accountType;
        this.accountNumber = accountNumber;
    }

//    c-----
     Account(String id, String name, float balance) {
         this.name = id;
         this.id = name;
         this.balance = balance;
    }

    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public float getBalance() {
        return balance;
    }
    public float credit (int amount){
        return (balance+= amount);
    }
    public float debit (int amount){
        if(amount<=balance){
            return (balance = balance-amount);
        }
        else
            System.out.println("Amount exceeded balance");
            return balance;
    }
    public float transferTo (Account a2, int amount) {
        if(amount<=balance){
           a2.balance += amount;
           balance = balance - amount;
        }
        else
            System.out.println("Amount exceeded balance");
        return balance;
    }

    public String toString(){
        return ("Account[id = " + id + "name  = " + name + "balance =" + balance);
    }




}
