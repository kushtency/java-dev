package day3_assi;
public class PrintNumber {
    public byte print(byte data){
        System.out.println("Byte data type");
        return data;
    }
    public short print(short data){
        System.out.println("short data type");
        return data;
    }
    public int print(int data){
        System.out.println("Int data type");
        return data;
    }
    public long print(long data){
        System.out.println("long data type");
        return data;
    }
    public float print(float data){
        System.out.println("float data type");
        return data;
    }
    public double print(double data){
        System.out.println("double data type");
        return data;

    }
    public String print(String data){
        System.out.println("String data type");
        return data;
    }
}
