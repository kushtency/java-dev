package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;
public class EmployeeDAOImp implements EmployeDAO {
    Connection connection=null;
    @Override
    public void saveEmployee(Employee employee) {
        try {
            connection = ConnectionFactory.getConnection();
//            Statement statement=connection.createStatement();
//            Scanner scanner=new Scanner(System.in);
//            System.out.println("enter employee id(int): ");
//            int id= scanner.nextInt();
//            System.out.println("enter employee name");
//            String name= scanner.next();
//            System.out.println("enter employee dob");
//            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
//            Date dob= sdf.parse(scanner.next());
//            System.out.println("enter employee add");
//            String add= scanner.next();
//            statement.executeUpdate("insert into Employee_jdbc_17155 values("+id+",'"+name+ "','" +dob +"','"+add+ "')");

            PreparedStatement preparedStatement=connection.prepareStatement("insert into Employee_jdbc_17155 values(?,?,?,?)");
            preparedStatement.setInt(1,employee.getId());
            preparedStatement.setString(2, employee.getName());
            preparedStatement.setString(3, employee.getAdd());
            preparedStatement.setDate(4,employee.getDob());
            preparedStatement.executeUpdate();
//            preparedStatement.close();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
