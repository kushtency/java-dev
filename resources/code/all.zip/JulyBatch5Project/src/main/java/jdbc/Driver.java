package jdbc;

import java.sql.Date;
import java.time.LocalDate;

public class Driver {
    public static void main(String[] args) {
        Employee employee = new Employee(12, "Alex", Date.valueOf(LocalDate.now()), "mzn");
        EmployeeDAOImp employeeDAOImp = new EmployeeDAOImp();
        employeeDAOImp.saveEmployee(employee);
    }
}
