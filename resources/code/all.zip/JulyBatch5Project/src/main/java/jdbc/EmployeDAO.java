package jdbc;

public interface EmployeDAO {
    void saveEmployee(Employee employee) throws RuntimeException;

}
