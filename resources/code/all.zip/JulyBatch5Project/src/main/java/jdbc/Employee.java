package jdbc;

import java.sql.Date;

public class Employee {
    private int id;
    private String name;
    private java.sql.Date dob;
    private String add;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public Employee(int id, String name, Date dob, String add) {
        this.id = id;
        this.name = name;
        this.dob = dob;
        this.add = add;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }
}
