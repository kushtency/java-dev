package day1011designpattern;

public class SingletonDriver {
    public static void main(String[] args) {
//        EagerInsSingleton eagerInsSingleton = EagerInsSingleton.getInstance();
//        System.out.println(eagerInsSingleton);

        LazyInsSingleton lazyInsSingleton = LazyInsSingleton.getInstance();
        System.out.println(lazyInsSingleton);

        LazyInsSingleton lazyInsSingleton1 = LazyInsSingleton.getInstance();
        System.out.println(lazyInsSingleton1);
        if(lazyInsSingleton == lazyInsSingleton1){
            System.out.println("true");
        }
        
//
//        EnumSingleton enumSingleton1 = EnumSingleton.INSTANCE;
//        enumSingleton1.setVar(5);
//        EnumSingleton enumSingleton2 = EnumSingleton.INSTANCE;
//        enumSingleton2.setVar(6);
//        System.out.println(enumSingleton1.getVar());
    }
}
