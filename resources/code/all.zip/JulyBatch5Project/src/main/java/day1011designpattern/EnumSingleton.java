package day1011designpattern;

public enum EnumSingleton {
    INSTANCE;
    int var;
    public int getVar() {
        return var;
    }
    public void setVar(int var) {
        this.var = var;
    }
    @Override
    public String toString() {
        return "EnumSingleton{" +
                "var=" + var +
                '}';
    }
}
