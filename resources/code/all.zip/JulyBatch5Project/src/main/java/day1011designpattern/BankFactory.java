package day1011designpattern;

import day6inheri_comps.Bank;
import day6inheri_comps.Maker;
import day6inheri_comps.Operator;

public class BankFactory {
    private static Bank bank;
    static Maker getMakerInstance(){
        return new Bank();
    }
    static Operator getOperatorInstance(){
        return new Bank();
    }

}
