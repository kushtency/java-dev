package day1011designpattern;

import day6inheri_comps.Customer;
import day6inheri_comps.Maker;
import day6inheri_comps.Operator;

public class FactoryDriver {
    public static void main(String[] args) {
        Maker maker = BankFactory.getMakerInstance();
        maker.registerCustomer(new Customer("nucleus", 1, "Alex", 120000));
        Operator operator = BankFactory.getOperatorInstance();
        operator.printAllCustomers();
    }
}
