package day1011designpattern;

public class LazyInsSingleton {
    private static LazyInsSingleton obj ;
    public static LazyInsSingleton getInstance(){
        if(obj == null)
        obj =  new LazyInsSingleton();
        return obj;
    }

    @Override
    public String toString() {
        return "LazyInsSingleton class here...";
    }
}
