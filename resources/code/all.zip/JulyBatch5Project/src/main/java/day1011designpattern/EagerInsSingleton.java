package day1011designpattern;
public class EagerInsSingleton {

    private static EagerInsSingleton obj  = new EagerInsSingleton();
    public static EagerInsSingleton getInstance(){
        return obj;
    }

    @Override
    public String toString() {
        return "EagerInsSingleton class here...";
    }
}
