package day16;
public class LargestDivisorCount {
    public int divisorCount(int num) {
        int count = 0;
        for (int i = 2; i <= num / 2; i++) {
            if (num % i == 0) {
                count++;
            }
        }
        return count;
    }
}
