package day16;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.atomic.AtomicInteger;

public class Driver {
    public static Logger logger = LogManager.getLogger("ConsoleLogger");
    public static void main(String[] args) {
        AtomicInteger largestDiv = new AtomicInteger(1);
        AtomicInteger largestcount = new AtomicInteger(1);
        LargestDivisorCount ldc = new LargestDivisorCount();
        Thread thread1 = new Thread(() -> {
            long startTime = System.currentTimeMillis();
            for (int i = 1; i < 10000; i++) {
                int count = ldc.divisorCount(i);
                if (count > largestcount.get()) {
                    largestcount.set(count);
                    largestDiv.set(i);
                }
            }
            logger.info(largestDiv);
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            System.out.println("Thread Execution Time in miliseconds --" + executionTime);
        });
        thread1.start();
    }
}
