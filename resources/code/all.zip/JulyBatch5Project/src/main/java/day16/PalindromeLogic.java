package day16;

import java.util.ArrayList;
import java.util.Collections;

public class PalindromeLogic {
    ArrayList<Integer> arr = new ArrayList<>();

    void Palindromlogic(int num) {
        int palin = 0;
        int rem;
        int temp = num;
        while (num > 0) {
            rem = num % 10;
            palin = palin * 10 + rem;
            num /= 10;
        }
        if (temp == palin) {
            arr.add(temp);
//            System.out.println("palindrome number is: " + palin + " " + Thread.currentThread().getName());
        }
    }

    int maximum_method(ArrayList arr) {
        int maximum = 0;
        for (int i = 1; i < arr.size(); i++) {
            int num= (int) arr.get(i);
            if (maximum < num) {
                maximum = num;
            }
        }
        return maximum;
    }

}



