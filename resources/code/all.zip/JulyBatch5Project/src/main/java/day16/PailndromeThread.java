package day16;

public class PailndromeThread {
    public static void main(String[] args) {
        PalindromeLogic logic = new PalindromeLogic();
        Thread thread1 = new Thread(() -> {
            for (int num = 1; num < 2000; num++) {
                logic.Palindromlogic(num);
            }});
        Thread thread2 = new Thread(() -> {
            for (int num = 2000; num < 4000; num++) {
                logic.Palindromlogic(num);
            }});
        Thread thread3 = new Thread(() -> {
            for (int num = 4000; num < 6000; num++) {
                logic.Palindromlogic(num);
            }});
        thread1.start();
        thread2.start();
        thread3.start();
        try {
            thread1.join();
            thread2.join();
            thread3.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println(logic.maximum_method(logic.arr));
    }

}
