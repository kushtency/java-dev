package day16;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public class ExecutorDivisor
{
    public static Logger logger = LogManager.getLogger("ConsoleLogger");
    public static void main(String[] args) {
        AtomicInteger largestDiv1 = new AtomicInteger(1);
        AtomicInteger largestcount1 = new AtomicInteger(1);
        AtomicInteger largestDiv2 = new AtomicInteger(1);
        AtomicInteger largestcount2 = new AtomicInteger(1);
        AtomicInteger largestDiv3 = new AtomicInteger(1);
        AtomicInteger largestcount3 = new AtomicInteger(1);
        LargestDivisorCount ldc = new LargestDivisorCount();
        ExecutorService service = Executors.newFixedThreadPool(3);
        long startTime = System.currentTimeMillis();
        service.submit(()->{
            for (int i = 1; i < 3000; i++) {
                int count = ldc.divisorCount(i);
                if (count > largestcount1.get()) {
                    largestcount1.set(count);
                    largestDiv1.set(i);
                }
            }
            logger.info("Thread1 " + largestDiv1);
        });
        service.submit(()->{
            for (int i = 3000; i < 6000; i++) {
                int count = ldc.divisorCount(i);
                if (count > largestcount2.get()) {
                    largestcount2.set(count);
                    largestDiv2.set(i);
                }
            }
            logger.info("Thread2 " + largestDiv2);
        });
        service.submit(()->{
            for (int i = 6000; i < 10000; i++) {
                int count = ldc.divisorCount(i);
                if (count > largestcount3.get()) {
                    largestcount3.set(count);
                    largestDiv3.set(i);
                }
            }
            logger.info("Thread3 " + largestDiv3);

            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            System.out.println("Thread Execution Time in miliseconds --" + executionTime);


            if (largestcount1.get() > largestcount2.get()) {
                if (largestcount1.get() > largestcount3.get()) {
                    logger.info(largestDiv1.get() + " is the number with maximum divisors");
                }
            }
            else if (largestcount3.get() > largestcount2.get()) {
                logger.info(largestDiv3.get() + " is the number with maximum divisors");
            }
            else {
                logger.info(largestDiv2.get() + " is the number with maximum divisors");
            }

        });
       service.shutdown();

    }
}
