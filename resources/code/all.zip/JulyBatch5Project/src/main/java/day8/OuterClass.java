package day8;

public class OuterClass {
    interface  ArrayIntertor{
        Object next();
        boolean hasNext();
    }
    class Intert implements ArrayIntertor{
        @Override
        public  Object next(){
            return null;
        }
        @Override
        public boolean hasNext(){
            return true;
        }

    }
}
