package day8;

import pack1.MyClass;

public class TestClass  extends MyClass{


    public static void main(String[] args) {

        TestClass t = new TestClass();
        System.out.println(t.protected_method(7));


    }
}
