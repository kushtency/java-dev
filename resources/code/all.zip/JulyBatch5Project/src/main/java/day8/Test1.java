package day8;

public class Test1 {
    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
//        OuterClass.ArrayIntertor inter = new OuterClass.ArrayIntertor();
//        OuterClass.ArrayIntertor a = outer;

    }

}
