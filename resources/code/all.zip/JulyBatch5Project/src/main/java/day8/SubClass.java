package day8;

import pack1.MyClass;

public class SubClass  extends MyClass {
    public static void main(String[] args) {

        SubClass s = new SubClass();

        System.out.println(s.protected_method(6));
        System.out.println(s.public_method("abcd"));
//        System.out.println(s.default_method("dfgh")); //not accessible
    }

}
