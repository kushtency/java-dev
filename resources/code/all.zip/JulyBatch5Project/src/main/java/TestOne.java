import java.io.File;
import java.io.FileWriter;

//public class TestOne implements Runnable {
//    public static void main (String[] args) throws Exception {
//        Thread t = new Thread(new TestOne());
//
//        System.out.print("Started");
//        t.start();
//        t.join();
//        System.out.print("Complete");
//    }
//    public void run() {
//        for (int i = 0; i < 4; i++) {
//            System.out.print(i);
//        }
//    }
//}
public class TestOne {
    public static void main(String... args) throws Exception {
        File file = new File("test.txt");
        System.out.println(file.exists());
        FileWriter fw = new FileWriter(file);
        System.out.println(file.exists());
    }
}