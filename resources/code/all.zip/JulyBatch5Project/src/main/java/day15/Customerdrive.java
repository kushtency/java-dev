package day15;
public class Customerdrive {
    int flag = (int)(Math.random()*3);
    synchronized void Adrive(){
        if(flag==0){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("A driving");
        flag=0;
        notifyAll();
    }
    synchronized void Bdrive(){
        if(flag==1)
        {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        flag=1;
        System.out.println("B driving");
        notifyAll();
    }
    synchronized void Cdrive(){
        if(flag==2)
        {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        flag=2;
        System.out.println("C driving");
        notifyAll();
    }
}


