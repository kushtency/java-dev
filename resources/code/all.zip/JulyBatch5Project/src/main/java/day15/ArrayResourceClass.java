package day15;
public class ArrayResourceClass {
    int[] arr_res = {1, 2, 3, 4, 5,6,7,8,9,10};
    public int[] getArr_res() {
        return arr_res;
    }
    synchronized int increament(int[] arr) {
        try {
            wait();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < arr.length; i++) {
            System.out.print( (arr[i] + 1) + " ");
        }
        System.out.println();
        return 0;
    }



}
