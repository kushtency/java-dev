package day15;
public class AlternativeListDriver {
    public static void main(String[] args) {
        AlternativeList alternativelist = new AlternativeList();
        alternativelist.data();
        Thread thread1 = new Thread(()->
        {
            for (int i = 0; i < alternativelist.list1.size(); i++){
                 alternativelist.getList1Index(i);
        }});
        Thread thread2 = new Thread(()->
        {
            for (int i = 0; i < alternativelist.list2.size(); i++){
                alternativelist.getList2index(i);
            }});

        thread1.start();
        thread2.start();
    }
}
