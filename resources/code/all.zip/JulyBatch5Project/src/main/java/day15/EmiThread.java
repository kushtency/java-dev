package day15;

import day3_assi.loanagreement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class EmiThread {
    public static List<loanagreement> getList(){
        Random random = new Random();
        List<loanagreement> loanagreementList = new ArrayList<>();
        for (int i = 0; i < 1000; i++) {
            loanagreementList.add(new loanagreement(10, 12, random.nextDouble() * 100000, 2000 ));
        }
        return loanagreementList;
    }
    public static void main(String[] args) {
        getList().parallelStream().forEach(agreement -> {
            double emi = agreement.calEMI();
            System.out.println(emi);
        });
        List<Thread> threads = new ArrayList<>();
        for (loanagreement agreement : getList()) {
            Thread thread = new Thread(() -> {
                double emi = agreement.calEMI();
                System.out.println(emi);
            });
            threads.add(thread);
            thread.start();
        }
        for (Thread thread : threads) {
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
