package day15;
public class HelloBye {
    boolean flag = false;
    synchronized void sayHello(){  //will execute while flag is false
        if(flag){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("hello");
        flag=true;
        notify();

    }
    synchronized void sayBye(){
        if(!flag)
        {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("Bye..");
        flag=false;
        notify();
    }
}
