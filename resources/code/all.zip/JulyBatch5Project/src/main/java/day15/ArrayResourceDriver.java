package day15;

public class ArrayResourceDriver {
    public static void main(String[] args) {
        ArrayResourceClass arr_object = new ArrayResourceClass();
        Thread t1 = new Thread(()->
        {
            arr_object.increament(arr_object.arr_res);
        });
        Thread t2 = new Thread(()->
        {
            arr_object.increament(arr_object.arr_res);
        });
        t1.start();
        t2.start();
        System.out.println("currently running -->" + Thread.currentThread().getName());
    }
}
