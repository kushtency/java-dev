package day15;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Helloworld extends Thread{
    public static Logger logger = LogManager.getLogger("ConsoleLogger");
    @Override
    public synchronized void run() {
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            logger.info("Hello World");
        }
    }

}
