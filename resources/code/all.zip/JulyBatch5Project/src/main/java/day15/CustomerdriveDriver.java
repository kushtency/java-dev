package day15;

public class CustomerdriveDriver {
    public static void main(String[] args) {
        CustomerActiveDrive activeDrive   = new CustomerActiveDrive();
        Thread thread1 = new Thread( new CustomerName("A-customer"));
        Thread thread2 = new Thread( new CustomerName("B-customer"));
        Thread thread3 = new Thread( new CustomerName("C-customer"));
        thread1.start();
        thread2.start();
        thread3.start();
    }
}
