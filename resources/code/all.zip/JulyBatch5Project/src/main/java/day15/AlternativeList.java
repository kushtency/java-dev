package day15;
import java.util.ArrayList;
import java.util.List;
public class AlternativeList {
    boolean flag = false;
    static List<Integer> list1 = new ArrayList<>();
    static List<String> list2 = new ArrayList<>();
    public synchronized void getList1Index(int i) {
        if (flag) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        notify();
        System.out.print( list1.get(i)+ " ");
        flag = true;
    }
    public synchronized void getList2index(int i) {   //list 2 index retrieve method
        if (!flag) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
        System.out.print( (String) list2.get(i) + "  ");
        flag = false;
        notify();
    }
    public synchronized void data() {
        list1.add(1);
        list1.add(2);
        list1.add(3);
        list1.add(4);
        list2.add("a");
        list2.add("b");
        list2.add("c");
        list2.add("d");
    }
}
