package day15;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Thread5 {
    public static void main(String[] args) {
        Logger logger = LogManager.getLogger("ConsoleLogger");
        Thread thread1 = new Thread(() -> {
                    for (int i = 1; i <= 10; i++) {
                        logger.info("<" + Thread.currentThread().getName() + "> - " + i);
                    }
                });
        Thread thread2 = new Thread(
                () -> {
                    for (int i = 1; i <= 10; i++) {
                        logger.info("<" + Thread.currentThread().getName() + "> - " + i);
                    }
                });

        Thread thread3 = new Thread(
                () -> {
                    for (int i = 1; i <= 10; i++) {
                        logger.info("<" + Thread.currentThread().getName() + "> - " + i);
                    }
                });

        Thread thread4 = new Thread(
                () -> {
                    for (int i = 1; i <= 10; i++) {
                        logger.info("<" + Thread.currentThread().getName() + "> - " + i);
                    }
                });

        Thread thread5 = new Thread(
                () -> {
                    for (int i = 1; i <= 10; i++) {
                        logger.info("<" + Thread.currentThread().getName() + "> - " + i);
                    }
                });

        thread1.setPriority(10);
        thread1.start();
        thread2.start();
        thread3.start();
        thread4.start();
        thread5.start();
}

}
