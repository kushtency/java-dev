package day15;

public class StaticResource {
    static int var = 1;

}
