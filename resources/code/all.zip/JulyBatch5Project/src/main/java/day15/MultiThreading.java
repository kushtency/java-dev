package day15;
public class MultiThreading {
    public static void main(String[] args) throws InterruptedException {
//        Thread1 thread1 = new Thread1();
//        thread1.start();
//
//        Thread2 threadrunnable = new Thread2();
//        Thread thread2 = new Thread(threadrunnable);
//        thread2.start();


//        Helloworld helloworldthread = new Helloworld();
//        helloworldthread.start();
//        Bye byethread = new Bye();
//        byethread.start();

        //6--
        Thread t1 = new Thread( ()->
        { for(int i = 0;i<5;i++){
            System.out.println(Thread.currentThread().getName());
        }
        });


        Thread t2 = new Thread( ()->
        { for(int i = 0;i<5;i++){
            System.out.println(Thread.currentThread().getName());

        }
        });

        Thread t3 = new Thread( ()->
        { for(int i = 0;i<5;i++){
            System.out.println(Thread.currentThread().getName());
        }
        });

        Thread t4 = new Thread( ()->
        { for(int i = 0;i<5;i++){
            System.out.println(Thread.currentThread().getName());
        }
        });

        t1.start();
        try {
            t1.join();
        }catch (InterruptedException i)
        {
            i.printStackTrace();
        }

        t2.start();
        try {
            t2.join();
        }catch (InterruptedException i)
        {
            i.printStackTrace();
        }

        t3.start();
        try {
            t3.join();
        }catch (InterruptedException i)
        {
            i.printStackTrace();
        }
        t4.start();
        try {
            t4.join();
        }catch (InterruptedException i)
        {
            i.printStackTrace();
        }


    }
}