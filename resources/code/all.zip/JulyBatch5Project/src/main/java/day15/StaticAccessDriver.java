package day15;

public class StaticAccessDriver {
    public static void main(String[] args) {
        StaticResource static_resource_obj = new StaticResource();
        Thread t1 = new Thread(() -> {

            int increased = static_resource_obj.var;
            increased = increased + 1;
            System.out.println(increased);
        });

        Thread t2 = new Thread(() -> {

            int increased = static_resource_obj.var;
            increased = increased + 1;
            System.out.println(increased);
        });
        t1.start();
        t2.start();
    }
}