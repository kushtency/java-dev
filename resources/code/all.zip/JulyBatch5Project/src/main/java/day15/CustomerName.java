package day15;
public class CustomerName implements Runnable {
    private String customername ;
//    private CustomerActiveDrive active;
    public String getCustomername() {
        return customername;
    }
    public CustomerName(String customername) {
        this.customername = customername;
    }

    public void run(){
        CustomerActiveDrive c =new CustomerActiveDrive();
        c.activeDrive(customername);
    }
}
