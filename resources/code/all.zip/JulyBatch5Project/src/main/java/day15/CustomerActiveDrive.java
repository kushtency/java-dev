package day15;
public class CustomerActiveDrive {
    int flag = 0;
    public synchronized void activeDrive(String customername){
            while (flag > 0) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace(); } }
            flag++;
            System.out.println(customername + " is driving");
            flag--;
           notifyAll();
    }
}
