import batch5.day2.fundamental;
import day3_assi.loanagreement;
import day6inheri_comps.Customer;
import day6inheri_comps.DataValidation;
import org.junit.Test;

import java.time.LocalDate;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class Testcases {
//    fundamental fundamental = new fundamental();
//    @Test
//    public void checkPassFailTest(){
//        assertEquals("Fail", batch5.day2.fundamental.checkPassFail(0));
//    }
//    @Test
//    public void printDayTest(){
//        assertEquals("Tuesday", fundamental.PrintDayInWord(2));
//    }
//
//    @Test
//    public void IncomeTaxCalculatorTest(){
//        assertEquals(2000, batch5.day2.fundamental.IncomeTaxCalculator(50000));
//    }
//
//    @Test
//    public void oddevenprimeTest(){
//        assertEquals("EVEN", batch5.day2.fundamental.oddevenprime(1000));
//    }
//
//    @Test
//    public void pascal_triTest() {
//        assertTrue("true", batch5.day2.fundamental.pascal_tri(5));
//    }
//    @Test
//    public void dbr_calTest(){
//        assertEquals("approved", batch5.day2.fundamental.dbr_cal(10000, 20000));
//    }
//    @Test
//    public void ltv_calTest(){
//        assertEquals(12, batch5.day2.fundamental.ltv_cal(120000,20000));
//    }
//
//    @Test
//    public void elig_loan_amtTest(){
//        assertEquals(2217.777, batch5.day2.fundamental.elig_loan_amt(10000, 10000, 2, 2));
//    }
//
//    @Test
//    public void installment_amt(){
//        assertEquals(1600000.0, batch5.day2.fundamental.installment_amt(100000, 2000, 120, 6));
//    }
//

    //data validation
//    DataValidation dv = new DataValidation();
//    @Test
//    public void dataTypeTest(){
//        assertTrue("true", dv.DataTypeValidation("spring", String.class));
//    }
//
//    @Test
//    public void datalength(){
//        assertTrue("okay", dv.DataLength("as a lion", 10));
//    }
//
//    @Test
//    public void character(){
//        assertTrue("@ is not allowed", dv.SpecialCharacters("as a lion", "@"));
//    }
//
//    @Test
//    public void ValueInDomain(){
//        String[] validValues = {"a","b", "c"};
//                assertTrue("ture", dv.ValueInDomain("a", validValues));
//    }
//
//    @Test
//    public void isFormatValid(){
//        assertTrue("give correct format", dv.isFormatValid("13-01-1990", "dd-MM-yyyy"));
//    }
//
//    @Test
//    public void emailValTest(){
//        assertTrue("give coorect email", dv.validateEmail("avnijjj@gmail.com"));
//    }

    //customer
//    Customer customer = new Customer();
//    @Test
//    public void dbrTest(){
//        assertEquals(0.6, customer.calDBR(12000, 20000));
//    }
//
//    @Test
//    public void calEligibleLoanAmountTest() {
//       assertEquals(999.9494355542936, customer.calEligibleLoanAmount(100000, 20000, 10, 6));
//    }
//
//    @Test
//    public void calMaxEligibleEMITest(){
//        assertEquals(299999.998, customer.calMaxEligibleEMI(12000, 600000));
//    }


    loanagreement loanag = new loanagreement();
    @Test
    public void calEMITest(){
        assertEquals(12,  loanag.calEMI());
    }

    @Test
    public void calculateLatepenaltyTest() {
        assertEquals(120,loanag.calculateLatepenalty
                (LocalDate.of(1990, 12, 12), LocalDate.of(1999, 12,12)));
    }

    @Test
    public void calculateLoanToValueRatioTest(){
        assertEquals(10.0, loanag.calculateLoanToValueRatio(12000, 120000));
    }
}
