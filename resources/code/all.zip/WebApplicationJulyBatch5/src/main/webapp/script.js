function showCustomerInfo() {
document.getElementById("customerInfo").style.display = "block";
document.getElementById("loanInfo").style.display = "none";
}
function showLoanInfo() {
document.getElementById("customerInfo").style.display = "none";
document.getElementById("loanInfo").style.display = "block";
}
function validateForm(){
// validating mendatory fields
if(document.getElementById("gender").value == ""){
alert("Gender must be filled!");
return false;
}
if(document.getElementById("fname").value == ""){
alert("First name must be filled!");
return false;
}
if(document.getElementById("lname").value == ""){
alert("Last name must be filled!");
return false;
}
if(document.getElementById("fullname").value == ""){
alert("fullname must be filled!");
return false;
}
if(document.getElementById("dob").value == ""){
alert("DOB must be filled!");
return false;
}
if(document.getElementById("occupation").value == ""){
alert("Occupation must be filled!");
return false;
}
if(document.getElementById("org-name").value == ""){
alert("Organization name must be filled!");
return false;
}
// validating format of date of birth
var dateOfBirth = document.getElementById("DOB").value;
var pattern = /^\d{2}-\d{2}-\d{4}$/;
if(!pattern.test(dateOfBirth)){
alert("Date of birth should be in the format of DD-MM-YYYY!");
return false;
}
// checking house no
var houseNo = document.getElementById("houseno").value;
if(isNaN(houseNo)){
alert("House number must be a number!")
return false;
}
// checking first and last name
var fname = document.getElementById("fname").value;
var lname = document.getElementById("lname").value;
var namePattern = /^[a-zA-Z]{3,}$/
if(!namePattern.test(fname)){
alert("First name must only contain alphabets and must contain minimum 3
characters!");
return false;
}
if(!namePattern.test(lname)){
alert("Last name must only contain alphabets and must contain minimum 3
characters!");
return false;
}
// work experience
var experience = document.getElementById("experience").value;
if(experience < 0 || experience != 0){
alert("Work experience must be greater than 0 years!");
return false;
}
return true;
}
var countryData = {
INDIA: {
UP: ["Hathras", "Aligarh","Ghaziabad"],
MP: ["Indore", "Bhopal", "Ujjain" ],
AndhraPradesh: ["Tirupati", "Anantpur","Vijaywada"]
},
Canada: {
Ontario: ["Toronto", "Ottawa","Windsor"],
Quebec: ["Montreal", "Quebec City","Rosemere"],
Alberta: ["Calgary", "Edmonton", "Lethbridge"]
},
Australia: {
NewSouthWales: ["Sydney", "Newcastle","Coffs harbor"],
Victoria: ["Melbourne", "Geelong", "Bendigo"],
Queensland: ["Brisbane", "Gold Coast", "Cairns"]
}
};
function updateStates() {
var country = document.getElementById("country").value;
var stateDropdown = document.getElementById("state");
var cityDropdown = document.getElementById("city");
stateDropdown.innerHTML = "";
cityDropdown.innerHTML = "";
if (country in countryData) {
var states = Object.keys(countryData[country]);
for (var i = 0; i < states.length; i++) {
var option = document.createElement("option");
option.value = states[i];
option.text = states[i];
stateDropdown.add(option);
}
}
}
function updateCities() {
var country = document.getElementById("country").value;
var state = document.getElementById("state").value;
var cityDropdown = document.getElementById("city");
cityDropdown.innerHTML = "";
if (country in countryData && state in countryData[country]) {
var cities = countryData[country][state];
for (var i = 0; i < cities.length; i++) {
var option = document.createElement("option");
option.value = cities[i];
option.text = cities[i];
cityDropdown.add(option);
}
}
}
