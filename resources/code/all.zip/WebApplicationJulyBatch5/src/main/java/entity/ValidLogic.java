package entity;

public class ValidLogic {
    public static boolean emailVaildation(String email) { // validating email
        boolean checkAtTheRate = false;
//  check @
        boolean checkDot = false;
// check .
        boolean checkSpace = false;
// check space
        for (int i = 0; i < email.length(); ++i) {
            char ch = email.charAt(i);
            if (ch == '@') {
                checkAtTheRate = true;
            } else if (ch == '.') {
                checkDot = true;
            } else if (ch == ' ') {
                checkSpace = true;
            }
        }

        if (!checkDot || !checkAtTheRate || checkSpace) {
            System.out.println("Email provided invalid! add @ or .  or remove space from email....\n");
            return false;
        }
        return true;
    }

        public static boolean alphabatesValidation(String str) {
            for (int i = 0; i < str.length(); ++i) {
                if (str.charAt(i) == ' ')
                    continue;
                if (str.charAt(i) < 'A' || (str.charAt(1) > 'Z' && str.charAt(1) < 'a') || str.charAt(1) > 'z')
                    return false;
            }
            return true;
        }

        public static boolean positveValueValidation(double value)
        {
            return value>0;
        }
    
}
