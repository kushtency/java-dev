package entity;
public class IsValid {
    public static boolean isValidMethod(Loan loan) {

        if (!ValidLogic.alphabatesValidation(loan.getName())) {
            System.out.println("application aname");
            return false;
        } else if (!ValidLogic.alphabatesValidation(loan.getOrganization())) {
            System.out.println("organaizaiont name");
            return false;
        } else if (!ValidLogic.alphabatesValidation(loan.getDesignation())) {
            System.out.println("designation..");
            return false;
        } else if (!ValidLogic.emailVaildation(loan.getEmail())) {
            System.out.println("email id");
            return false;
        } else if (!ValidLogic.positveValueValidation(loan.getLoantenure())) {
            System.out.println("tenure");
            return false;
        }
        else
            return ValidLogic.positveValueValidation(loan.getMonthlysalary());
    }
}
