package entity;
public class Loan {
    private String name;
    private String email;
    private int contactno;
    private String loantype;
    private int loantenure;
    private String loanreason;
    private String organization;
    private String designation;
    private int monthlysalary;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getContactno() {
        return contactno;
    }

    public void setContactno(int contactno) {
        this.contactno = contactno;
    }

    public String getLoantype() {
        return loantype;
    }

    public void setLoantype(String loantype) {
        this.loantype = loantype;
    }

    public int getLoantenure() {
        return loantenure;
    }

    public void setLoantenure(int loantenure) {
        this.loantenure = loantenure;
    }

    public String getLoanreason() {
        return loanreason;
    }

    public void setLoanreason(String loanreason) {
        this.loanreason = loanreason;
    }

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getMonthlysalary() {
        return monthlysalary;
    }

    public void setMonthlysalary(int monthlysalary) {
        this.monthlysalary = monthlysalary;
    }

    @Override
    public String toString() {
        return "Loan{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", contactno=" + contactno +
                ", loantype='" + loantype + '\'' +
                ", loantenure=" + loantenure +
                ", loanreason='" + loanreason + '\'' +
                ", organization='" + organization + '\'' +
                ", designation='" + designation + '\'' +
                ", monthlysalary=" + monthlysalary +
                '}';
    }
}

