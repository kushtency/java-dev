package dao;

import entity.Loan;

public interface LoanDAO {
    public int saveloan(Loan laon);

}
