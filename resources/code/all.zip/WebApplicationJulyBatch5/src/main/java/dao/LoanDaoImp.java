package dao;

import entity.Customer;
import entity.Loan;

import java.sql.*;

public class LoanDaoImp implements LoanDAO{
//    public static
    @Override
    public int saveloan(Loan loan) {
        int id;
        try (Connection connection=ConnectionFactory.getConnection();){
            PreparedStatement preparedStatement=connection.prepareStatement("insert into loan_application_details_17155 values(loan_application_number_17155.nextval,?,?,?,?,?,?,?,?,?)");
            preparedStatement.setString(1,loan.getName());
            preparedStatement.setString(2, loan.getEmail());
            preparedStatement.setInt(3, loan.getContactno());
            preparedStatement.setString(4,loan.getLoantype());
            preparedStatement.setInt(5,loan.getLoantenure());
            preparedStatement.setString(6,loan.getLoanreason());
            preparedStatement.setString(7,loan.getOrganization());
            preparedStatement.setString(8,loan.getDesignation());
            preparedStatement.setInt(9,loan.getMonthlysalary());

            preparedStatement.executeUpdate();
            id = getloanapplicationnumber(loan.getEmail());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    return id;
    }
    public int getloanapplicationnumber(String email) throws SQLException {
        Connection connection= null;
        try {
            connection = ConnectionFactory.getConnection();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        Statement statement = connection.createStatement();
        int id = 0;
        ResultSet rs = statement.executeQuery("select * from loan_application_details_17155 where email = '" + email + "'");
        while (rs.next()) {
            return rs.getInt(1);
        }
        return id;
        }
    }


