package dao;
import entity.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
public class CustDaoImp implements CustomerDao {
    Connection connection=null;
    @Override
    public void saveCustomer(Customer customer) {
        try {
            PreparedStatement preparedStatement=connection.prepareStatement("insert into Employee_jdbc_17155 values(?,?,?,?)");
            preparedStatement.setInt(1,customer.getCid());
//            preparedStatement.setString(2, customer.getCname());
//            preparedStatement.setString(3, customer.get());
//            preparedStatement.setDate(4,customer.getDob());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}
