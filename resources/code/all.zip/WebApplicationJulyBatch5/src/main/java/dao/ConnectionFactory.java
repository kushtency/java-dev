package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.LogManager;
import java.util.logging.Logger;
    public class ConnectionFactory {
        public static Logger logger = LogManager.getLogManager().getLogger("ConsoleLogger");
        public static Connection getConnection() throws ClassNotFoundException, SQLException {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection connection= DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1535:nsbt19C","training","training");
            return connection;
    }

}
