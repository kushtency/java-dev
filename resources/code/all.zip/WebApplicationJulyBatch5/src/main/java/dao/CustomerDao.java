package dao;

import entity.Customer;

public interface CustomerDao {
    public void saveCustomer(Customer customer);
}
