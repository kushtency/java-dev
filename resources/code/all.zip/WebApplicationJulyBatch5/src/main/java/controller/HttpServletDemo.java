package controller;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.logging.Logger;
//@WebServlet(urlPatterns = "/submit")
@WebServlet(urlPatterns = "/greetTime")

public class HttpServletDemo extends HttpServlet {
    Logger logger = Logger.getLogger("ConsoleManager");
//    int count = 0;
//    int instancevariable = 0;
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        int localvariable = 0;
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        instancevariable++;
//        localvariable++;
//
////        out.write("hello world!! from http servlet GET method  " + "<br>");
//        out.write("instance variable: " + instancevariable + " and localvariable is: " + localvariable);
//
//    }
//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        out.write("Helloworld!!");
//    }

    //4
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        String name = req.getParameter("username");
//
//        Date currentTime = new Date();
//        SimpleDateFormat sdf = new SimpleDateFormat("hh");
//
//        int hour = Integer.parseInt(sdf.format(currentTime));
//
//        String greeting;
//
//        if (hour >= 0 && hour < 12) {
//            greeting = "Good morning";
//        } else if (hour >= 12 && hour < 17) {
//            greeting = "Good afternoon";
//        } else if (hour >= 17 && hour < 21) {
//            greeting = "Good evening";
//        } else {
//            greeting = "Good night";
//        }
//        out.write(greeting + "!" + name);
//    }

    //5
//    private int initCount = 0;
//    private int destroyCount = 0;
//    public void init(){
//        initCount++;
//        logger.info("init method count: " + initCount);
//    }
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        out.write("doget method init count : " + initCount);
//        out.write("doget method destroy count : " + destroyCount);
//        logger.info("doget method init count : " + initCount);
//        logger.info("doget method destroy count : " + destroyCount);
//    }
//    public void destroy(){
//        destroyCount++;
//        logger.info("destroy method count: " + destroyCount);
//    }

    //6
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        Enumeration<String> headers=req.getHeaderNames();
//        while(headers.hasMoreElements())
//        {
//            String header=headers.nextElement();
//            String value=req.getHeader(header);
//            out.write("header name:  "+header+"  value is:  "+value +"<br>");
//        }
//    }

//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        out.write("here is doGet method");
//        out.write("Name is " + req.getParameter("cname")+"<br>");
//        out.write("Date of brith is " + req.getParameter("cdob")+"<br>");
//        out.write("email address is " + req.getParameter("cemail")+"<br>");
//        out.write("contact number is " + req.getParameter("ccontactno")+"<br>");
//        out.write("monthly salary is " + req.getParameter("cmonthlysalary")+"<br>");
//        out.write("gender is " + req.getParameter("cgender").charAt(0)+"<br>");
//        out.write("Hobbies are " + Arrays.toString(req.getParameterValues("chobbies"))+"<br>");
//        out.write("location is " + req.getParameter("clocation")+"<br>");
//    }
//
//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        out.write("here is doPost method");
//        out.write("Name is " + req.getParameter("cname")+"<br>");
//        out.write("Date of brith is " + req.getParameter("cdob")+"<br>");
//        out.write("email address is " + req.getParameter("cemail")+"<br>");
//        out.write("contact number is " + req.getParameter("ccontactno")+"<br>");
//        out.write("monthly salary is " + req.getParameter("cmonthlysalary")+"<br>");
//        out.write("gender is " + req.getParameter("cgender").charAt(0)+"<br>");
//        out.write("Hobbies are " + Arrays.toString(req.getParameterValues("chobbies"))+"<br>");
//        out.write("location is " + req.getParameter("clocation")+"<br>");
//    }

    //8
//    @Override
//    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        resp.setContentType("text/html");
//        PrintWriter out = resp.getWriter();
//        if(req.getHeader("user-agent").contains("Chrome"))
//        {
//            Enumeration<String> headers=req.getHeaderNames();
//        while(headers.hasMoreElements())
//            {
//                String header=headers.nextElement();
//                String value=req.getHeader(header);
//                out.write("header name:  "+header+"  value is:  "+value +"<br>");
//            }
//        }
//        else {
//            out.write(" the application is best suited for Google Chrome");
//        }
////        out.write(req.getHeader("user-agent"));
//    }

    private int count = 0;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        resp.setIntHeader("refresh", 4);
        LocalDateTime currentDateTime = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String formattedDateTime = currentDateTime.format(formatter);
        out.write("current time: " + formattedDateTime );
    }

}
