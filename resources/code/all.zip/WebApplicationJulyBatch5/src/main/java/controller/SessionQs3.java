package controller;
//3 and 4
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
@WebServlet(urlPatterns = "/keepsign")

public class SessionQs3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        PrintWriter out = resp.getWriter();
        resp.setContentType("text/html");
        String isKeep = req.getParameter("keepmesignedin");
        out.write(isKeep);
        if (isKeep != null) {
            Cookie cookie = new Cookie("cookieuser", req.getParameter("uname"));
            resp.addCookie(cookie);
            cookie.setMaxAge(60);
        }
            Cookie[] cookies = req.getCookies();

        if (cookies!= null) {
            out.println(("<table><tr><th>cookie name</th><th>cookie value</th>"));
            for (Cookie cookie : cookies) {
                out.println(("<tr><td>" + cookie.getName() + "</td><td>" + cookie.getValue()) + "</td></tr></table>");
            }
        }
        else{
            out.println("No cookie");
        }


//        for(Cookie cookie: cookies){
//            if(cookie.getName().equalsIgnoreCase("cookieuser")){
//                Cookie cookie1 = new Cookie("cookieuser1", req.getParameter("uname"));
//                resp.addCookie(cookie1);
//                cookie.setMaxAge(0);
//            }
//        }

        }
    }
