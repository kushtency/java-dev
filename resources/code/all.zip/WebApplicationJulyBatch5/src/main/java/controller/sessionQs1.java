package controller;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.ServletException;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/session1.html")
public class sessionQs1 extends HttpServlet {
    int count = 0;
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        PrintWriter out = resp.getWriter();
        out.write("session creation time is :" + session.getCreationTime());
        out.write("session last accessed time is :" + session.getLastAccessedTime());
        out.print("session id : " +  session.getId() + " count is : " + count++);

    }
}