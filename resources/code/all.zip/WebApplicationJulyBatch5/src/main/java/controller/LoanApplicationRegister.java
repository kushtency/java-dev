package controller;

import dao.LoanDAO;
import dao.LoanDaoImp;
import entity.IsValid;
import entity.Loan;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = "/LoanApplicationRegister")
public class LoanApplicationRegister extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Loan loan=new Loan();
        loan.setName(req.getParameter("name"));
        loan.setEmail(req.getParameter("email"));
        loan.setContactno(Integer.parseInt(req.getParameter("contactno")));
        loan.setLoantype(req.getParameter("loan"));
        loan.setLoantenure(Integer.parseInt(req.getParameter("loantenure")));
        loan.setLoanreason(req.getParameter("loanreason"));
        loan.setOrganization(req.getParameter("organization"));
        loan.setDesignation(req.getParameter("designation"));
        loan.setMonthlysalary(Integer.parseInt(req.getParameter("monthlysalary")));
        PrintWriter out = resp.getWriter();
        LoanDAO loandao = new LoanDaoImp();
        int i = loandao.saveloan(loan);
        out.println(i);

        if (IsValid.isValidMethod (loan)) {
            if (loandao.saveloan(loan)>0) {
                out.write("Data inserted Successfully..");
            }
            else {
                out.write("Data not inserted...");
            }
        }
        else
        {
            resp.sendRedirect("error.html");
        }
//        try {
//
//            loandao.checkApplicationId ( applicationNo: 10);
//
//        } catch (ApplicationNumberException e) { throw new RuntimeException(e);









        }
}
