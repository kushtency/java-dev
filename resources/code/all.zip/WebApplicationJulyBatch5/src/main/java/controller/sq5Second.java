package controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns="/fifth",initParams = {
        @WebInitParam(name="userName",value="Avni"),
        @WebInitParam(name="passcode",value="avni34567@")
})
public class sq5Second extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");

        PrintWriter out = resp.getWriter();
        out.write("config parameter : " + getServletConfig().getInitParameter("userName") + "<br>");
        out.write("context parameter : " + getServletContext().getInitParameter("adminAvni"));
    }
}
