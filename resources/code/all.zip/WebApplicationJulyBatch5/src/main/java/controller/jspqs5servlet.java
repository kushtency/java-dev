package controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/pages")
public class jspqs5servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String pagenumber = req.getParameter("pagenumber");

        RequestDispatcher dispatcher3 = null;
        if (pagenumber != null && !pagenumber.isEmpty()) {
            int page = Integer.parseInt(pagenumber);

            switch (page) {
                case 1:
                    RequestDispatcher dispatcher = req.getRequestDispatcher("AboutUs.jsp");
                    dispatcher.forward(req, resp);
                case 2:
                    RequestDispatcher dispatcher1 = req.getRequestDispatcher("ContactUs.jsp");
                    dispatcher1.forward(req, resp);
                default:
                    dispatcher3 = req.getRequestDispatcher("error.jsp");
                    dispatcher3.forward(req, resp);
            }
        } else {
            dispatcher3.forward(req, resp);
        }
    }
}
