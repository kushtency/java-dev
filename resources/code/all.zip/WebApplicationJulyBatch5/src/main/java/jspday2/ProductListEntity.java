package jspday2;

import java.util.ArrayList;

public class ProductListEntity {
    private ArrayList<ProductEntity> productEntities = null;

    public ArrayList<ProductEntity> getProductEntities() {
        return productEntities;
    }

    public void setProductEntities(ArrayList<ProductEntity> productEntities) {
        this.productEntities = productEntities;
    }
}
